# محمد الحموري 3.0.0

هذا الإصدار يقسم المشروع إلى نواة مساعد مستقلة وواجهة مستخدم مستقلة. راجع `SYSTEM_CORE_ARCHITECTURE_AR.md`.

- `app-debug.apk`: الواجهة التي تظهر للمستخدم.
- `core-debug.apk`: نواة VoiceInteraction والأوامر والاستماع.
- لا تعتبر النواة System/Privileged فعلية حتى تدمج في النظام/ROM.
- "يا حموري" في هذه المرحلة Software Hotword، وليس DSP Hotword.

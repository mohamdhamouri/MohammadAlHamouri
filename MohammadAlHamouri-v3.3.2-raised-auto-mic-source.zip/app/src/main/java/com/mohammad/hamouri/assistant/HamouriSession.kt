package com.mohammad.hamouri.assistant

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.service.voice.VoiceInteractionSession
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.mohammad.hamouri.MainActivity

/** Compact, Gemini-inspired assistant input bar shown over the current screen. */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    companion object { private const val TAG = "HamouriAssistant" }

    private var root: LinearLayout? = null
    private var promptInput: EditText? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var inlineListening = false

    override fun onCreate() {
        super.onCreate()
        setUiEnabled(true)
        Log.i(TAG, "Compact assistant bar created")
    }

    override fun onCreateContentView(): View {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(25, 25, 27), dp(38).toFloat())
            elevation = dp(14).toFloat()
        }

        // Left-side voice activity shortcut, similar to the voice waveform control.
        val voiceMode = TextView(context).apply {
            text = "Ⅱ〰"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "التحدث إلى محمد الحموري"
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { openMainActivity(listen = true) }
        }
        panel.addView(voiceMode, LinearLayout.LayoutParams(dp(38), dp(54)))

        val mic = TextView(context).apply {
            text = "🎤"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "الميكروفون"
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { startInlineListening() }
        }
        panel.addView(mic, LinearLayout.LayoutParams(dp(42), dp(54)))

        promptInput = EditText(context).apply {
            hint = "اسأل محمد الحموري"
            setHintTextColor(Color.rgb(235, 235, 238))
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            textDirection = View.TEXT_DIRECTION_RTL
            setSingleLine(false)
            minLines = 1
            maxLines = 2
            background = null
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(8), dp(2), dp(8), dp(2))
            setOnEditorActionListener { _, actionId, event ->
                val sendAction = actionId == EditorInfo.IME_ACTION_SEND ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP)
                if (sendAction) {
                    submitPrompt()
                    true
                } else false
            }
        }
        panel.addView(promptInput, LinearLayout.LayoutParams(0, dp(58), 1f))

        val send = TextView(context).apply {
            text = "➤"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "إرسال السؤال إلى محمد الحموري"
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { submitPrompt() }
        }
        panel.addView(send, LinearLayout.LayoutParams(dp(38), dp(54)))

        val add = TextView(context).apply {
            text = "+"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "فتح المساعد"
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { openMainActivity(listen = false) }
        }
        panel.addView(add, LinearLayout.LayoutParams(dp(44), dp(54)))

        root = panel
        return panel
    }

    private fun submitPrompt() {
        val prompt = promptInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isNotEmpty()) openMainActivity(listen = false, command = prompt)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i(TAG, "Assistant input bar shown; flags=$showFlags")
        root?.visibility = View.VISIBLE
        window?.window?.let { actualWindow ->
            actualWindow.setBackgroundDrawableResource(android.R.color.transparent)
            actualWindow.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attributes = actualWindow.attributes
            attributes.width = WindowManager.LayoutParams.MATCH_PARENT
            attributes.height = WindowManager.LayoutParams.WRAP_CONTENT
            attributes.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            attributes.dimAmount = 0.08f
            attributes.y = dp(250) // Raise the assistant bar well above the navigation area.
            actualWindow.attributes = attributes
            actualWindow.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        // Begin listening automatically when the system assistant button opens this session.
        promptInput?.postDelayed({ startInlineListening() }, 350L)
    }

    override fun onHide() {
        root?.visibility = View.GONE
        stopInlineListening()
        super.onHide()
    }

    private fun startInlineListening() {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            promptInput?.hint = "اسمح باستخدام الميكروفون من إعدادات التطبيق"
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            promptInput?.hint = "التعرف الصوتي غير متاح؛ اكتب سؤالك هنا"
            return
        }
        try {
            stopInlineListening()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    inlineListening = true
                    promptInput?.hint = "أنا أستمع إليك..."
                }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { inlineListening = false }
                override fun onError(error: Int) {
                    inlineListening = false
                    if (promptInput?.text.isNullOrBlank()) promptInput?.hint = "اسأل محمد الحموري"
                    Log.w(TAG, "Inline speech recognition error=$error")
                }
                override fun onResults(results: Bundle?) {
                    inlineListening = false
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        promptInput?.setText(spoken)
                        promptInput?.setSelection(spoken.length)
                    }
                    promptInput?.hint = "اسأل محمد الحموري"
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val spoken = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        promptInput?.setText(spoken)
                        promptInput?.setSelection(spoken.length)
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer.startListening(speechIntent)
        } catch (e: Exception) {
            inlineListening = false
            Log.e(TAG, "Could not start inline speech recognition", e)
            promptInput?.hint = "اكتب سؤالك أو اضغط الميكروفون مجددًا"
        }
    }

    private fun stopInlineListening() {
        try { speechRecognizer?.cancel() } catch (_: Exception) { }
        try { speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        inlineListening = false
    }

    private fun openMainActivity(listen: Boolean, command: String? = null) {
        val assistantIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, listen)
            if (!command.isNullOrBlank()) putExtra("hamouri_voice_command", command)
        }
        try {
            startAssistantActivity(assistantIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start assistant activity", e)
            try { context.startActivity(assistantIntent) }
            catch (second: Exception) { Log.e(TAG, "Fallback activity launch failed", second) }
        }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(48, 48, 52))
    }
}

package com.mohammad.hamouri.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.widget.Toast
import com.mohammad.hamouri.MainActivity

/** Android system-assistant bridge for Android 11+. */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    private var launched = false

    override fun onCreate() {
        super.onCreate()
        setUiEnabled(false)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        if (launched) return
        launched = true

        Toast.makeText(context, "محمد الحموري: تم تشغيل المساعد", Toast.LENGTH_SHORT).show()

        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }

        try {
            startAssistantActivity(intent)
        } catch (_: Throwable) {
            try {
                startVoiceActivity(intent)
            } catch (_: Throwable) {
                try {
                    context.startActivity(intent)
                } catch (_: Throwable) {
                    Toast.makeText(context, "تعذر فتح واجهة محمد الحموري", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onHide() {
        launched = false
        super.onHide()
    }
}

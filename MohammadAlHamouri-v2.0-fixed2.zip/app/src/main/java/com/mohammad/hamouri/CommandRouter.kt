package com.mohammad.hamouri

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.util.Locale

class CommandRouter(private val context: Context) {
    fun execute(raw: String): CommandResult {
        val clean = normalize(raw)
        if (clean.isBlank()) return CommandResult("لم أسمع أمرًا واضحًا.")
        when {
            clean.contains("افتح الاعدادات") || clean.contains("افتح الإعدادات") ->
                return launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
            clean.contains("افتح الكاميرا") || clean.contains("شغل الكاميرا") || clean.contains("شغّل الكاميرا") ->
                return launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
            clean.contains("افتح الهاتف") || clean.contains("افتح الاتصال") || clean.contains("افتح الاتصالات") ->
                return launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        }
        val number = Regex("(?:اتصل|اتصلي)\\s*(?:بـ|ب|بالرقم)?\\s*([+0-9][+0-9()\\- ]{4,})").find(raw)?.groupValues?.get(1)?.trim()
        if (!number.isNullOrBlank()) return dial(number)
        val appName = Regex("(?:افتح|شغل|شغّل)\\s+(.+)").find(raw)?.groupValues?.get(1)?.trim()
        if (!appName.isNullOrBlank()) {
            val launch = findLaunchIntent(appName)
            if (launch != null) return launch(launch, "حسنًا، فتحت $appName.")
        }
        return CommandResult("", false)
    }

    fun executeTool(call: AiToolCall): CommandResult = when (call.name) {
        "open_settings" -> launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
        "open_camera" -> launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
        "open_dialer" -> launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        "dial_number" -> dial(call.arguments.optString("number"))
        "open_app" -> {
            val name = call.arguments.optString("name").trim()
            val intent = findLaunchIntent(name)
            if (intent != null) launch(intent, "حسنًا، فتحت $name.") else CommandResult("لم أجد تطبيقًا باسم $name.", true)
        }
        else -> CommandResult("الأداة المطلوبة غير متاحة على هذا الإصدار.", true)
    }

    private fun dial(number: String): CommandResult {
        if (number.isBlank()) return CommandResult("لم أجد رقمًا صالحًا للاتصال.", true)
        return CommandResult("سأفتح شاشة الاتصال بالرقم $number. اضغط زر الاتصال لإجراء المكالمة.", true,
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
    }

    private fun normalize(value: String): String = HamouriWakePhrase.strip(value).lowercase(Locale("ar"))

    private fun launch(intent: Intent, message: String): CommandResult = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CommandResult(message, true)
    } catch (_: Exception) { CommandResult("تعذر تنفيذ هذا الإجراء على جهازك.", true) }

    private fun findLaunchIntent(requested: String): Intent? {
        val pm = context.packageManager
        val normalized = requested.lowercase(Locale("ar")).replace(" ", "")
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase(Locale("ar")).replace(" ", "")
            label == normalized || label.contains(normalized) || normalized.contains(label)
        } ?: return null
        return pm.getLaunchIntentForPackage(match.packageName)
    }
}

data class CommandResult(val response: String, val actionPerformed: Boolean = false, val pendingIntent: Intent? = null)

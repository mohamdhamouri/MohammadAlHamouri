package com.mohammad.hamouri

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class HamouriGeminiClient(private val apiKey: String) {
    private val main = Handler(Looper.getMainLooper())
    private val model = "gemini-2.5-flash"
    fun ask(prompt: String, callback: (Result<String>) -> Unit) {
        Thread {
            try {
                if (apiKey.isBlank()) error("لم يتم إدخال مفتاح Gemini API.")
                val body = JSONObject().put("contents", JSONArray().put(JSONObject()
                    .put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "أنت محمد الحموري، مساعد عربي ودود. أجب بالعربية ما لم يطلب المستخدم غير ذلك.\n\n$prompt")))))
                val c = (URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json"); setRequestProperty("x-goog-api-key", apiKey)
                }
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code !in 200..299) error(parseError(response))
                val parts = JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: error("رد Gemini غير متوقع")
                val text = buildString { for (i in 0 until parts.length()) { val t = parts.optJSONObject(i)?.optString("text", "") ?: ""; if (t.isNotBlank()) { if (isNotEmpty()) append("\n"); append(t) } } }
                if (text.isBlank()) error("لم يرجع Gemini نصًا")
                main.post { callback(Result.success(text)) }
            } catch (e: Exception) { main.post { callback(Result.failure(e)) } }
        }.start()
    }
    private fun parseError(s: String) = try { JSONObject(s).optJSONObject("error")?.optString("message") ?: s.take(300) } catch (_: Exception) { s.take(300) }
}

# محمد الحموري v3.4.7 — wake diagnostics, chat history, bilingual app launch

This source update is based on the available v3.4.5/v3.4.6 project files and preserves the existing Compose interface as much as possible.

## Included
- Wake-word listener diagnostics with Arabic normalization (including tashkeel removal), partial/final result checks, and retry after recognizer errors.
- Conversation archive list accessible from the top bar. Starting a new conversation archives the current transcript; choosing an archived entry restores it.
- More flexible Arabic/English application-name aliases (WhatsApp/واتساب, Facebook/فيسبوك, YouTube/يوتيوب, Chrome/كروم, and others), plus matching against launcher labels and package names.
- Launcher intent visibility query for Android 11 package visibility.

## Build
Push this project to a GitHub repository and run **Actions → Build محمد الحموري 3.4.7 → Run workflow**. Download the `MohammadAlHamouri-v3.4.7-APK` artifact after the workflow succeeds.

## Important limitations
Wake phrase recognition uses Android's ordinary speech-recognition provider, not a dedicated always-on low-power hotword engine. It may pause, fail to recognize a phrase, or be restricted by the device's Android/XOS background policies. The archive currently saves a conversation when starting a new one; it does not yet autosave a title database independently of the transcript. This source ZIP has not been compiled or tested on the user's phone in this environment.

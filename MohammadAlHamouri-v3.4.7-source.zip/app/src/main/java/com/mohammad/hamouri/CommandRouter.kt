package com.mohammad.hamouri

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.os.PowerManager
import android.view.WindowManager
import java.util.Locale

/** Local phone commands are handled here before anything is sent to Gemini. */
object CommandRouter {
    data class Result(val handled: Boolean, val message: String = "")

    fun identityResponse(raw: String): String? {
        val q = normalize(raw)
        val exact = setOf(
            "من انت", "من أنت", "مين انت", "مين أنت",
            "عرفني بنفسك", "عرف نفسك", "ما اسمك", "شو اسمك",
            "ايش اسمك", "اسمك ايش", "من هو محمد الحموري",
            "من هو محمد الحموري؟", "من انت يا حموري", "من أنت يا حموري"
        )
        if (exact.any { normalize(it) == q }) {
            return "أنا محمد الحموري، مساعدك الرقمي الخاص. أنا هنا لخدمتك ومساعدتك في الأسئلة والمهام والتحكم بالهاتف وفق الصلاحيات التي تمنحني إياها."
        }
        return if (q.contains("من انت") || q.contains("من أنت") || q.contains("عرف نفسك")) {
            "أنا محمد الحموري، مساعدك الرقمي الخاص. أنا هنا لخدمتك."
        } else null
    }

    fun handle(context: Context, raw: String): Result {
        val q = normalize(raw)
        if (q.isBlank()) return Result(false)

        return when {
            containsAny(q, "اقفل الشاشة", "اغلق الشاشة", "أغلق الشاشة", "قفل الشاشة", "سكر الشاشة", "سكر الشاشه") ->
                lockScreen(context)
            containsAny(q, "افتح قفل الشاشة", "افتح الشاشة", "شغل الشاشة", "شغّل الشاشة", "ايقظ الشاشة", "أيقظ الشاشة", "افتح الشاشه") ->
                wakeScreen(context)
            containsAny(q, "شغل المصباح", "شغّل المصباح", "افتح المصباح", "شغل الفلاش", "شغّل الفلاش", "افتح الفلاش") ->
                setTorch(context, true)
            containsAny(q, "طفي المصباح", "اطفئ المصباح", "أطفئ المصباح", "اغلق المصباح", "أغلق المصباح", "طفي الفلاش", "اطفئ الفلاش", "أطفئ الفلاش") ->
                setTorch(context, false)
            containsAny(q, "افتح الهاتف", "فتح الهاتف", "افتح تطبيق الهاتف", "افتح الاتصال", "افتح المسجل") ->
                openDialer(context)
            q.startsWith("اتصل بـ ") || q.startsWith("اتصل ب ") || q.startsWith("اتصل على ") || q.startsWith("اتصل ") ->
                callContact(context, q)
            q.startsWith("افتح ") || q.startsWith("شغل ") || q.startsWith("شغّل ") ->
                openApp(context, q.substringAfter(' ').trim())
            else -> Result(false)
        }
    }

    private fun lockScreen(context: Context): Result {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, HamouriDeviceAdminReceiver::class.java)
        if (!dpm.isAdminActive(admin)) {
            return Result(true, "أحتاج تفعيل صلاحية مسؤول الجهاز من إعدادات محمد الحموري حتى أستطيع قفل الشاشة.")
        }
        dpm.lockNow()
        return Result(true, "تم قفل الشاشة.")
    }

    private fun wakeScreen(context: Context): Result {
        val intent = Intent(context, WakeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        context.startActivity(intent)
        return Result(true, "تم تشغيل الشاشة. إذا كان عليها رمز حماية، يجب إدخاله يدويًا.")
    }

    private fun setTorch(context: Context, enabled: Boolean): Result {
        val camera = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return try {
            val id = camera.cameraIdList.firstOrNull { id ->
                camera.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Result(true, "لا يوجد فلاش يمكن التحكم به على هذا الهاتف.")
            camera.setTorchMode(id, enabled)
            Result(true, if (enabled) "تم تشغيل المصباح." else "تم إطفاء المصباح.")
        } catch (_: SecurityException) {
            Result(true, "لا أملك صلاحية التحكم بالمصباح حاليًا.")
        } catch (e: Exception) {
            Result(true, "تعذر التحكم بالمصباح: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun openDialer(context: Context): Result {
        return try {
            context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result(true, "تم فتح تطبيق الهاتف.")
        } catch (_: Exception) {
            Result(true, "تعذر فتح تطبيق الهاتف.")
        }
    }

    private fun callContact(context: Context, normalized: String): Result {
        if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return Result(true, "أحتاج إذن الاتصال حتى أستطيع إجراء المكالمة مباشرة.")
        }
        val name = normalized
            .removePrefix("اتصل بـ ")
            .removePrefix("اتصل ب ")
            .removePrefix("اتصل على ")
            .removePrefix("اتصل ")
            .trim()
        if (name.isBlank()) return Result(true, "اذكر اسم الشخص الذي تريد الاتصال به.")

        val phone = findContact(context, name)
            ?: return Result(true, "لم أجد جهة اتصال باسم $name.")
        return try {
            context.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result(true, "جاري الاتصال بـ $name.")
        } catch (_: Exception) {
            Result(true, "تعذر إجراء الاتصال.")
        }
    }

    private fun findContact(context: Context, requested: String): String? {
        val wanted = normalize(requested)
        val aliases = mapOf(
            "ماما" to listOf("ماما", "أمي", "امي", "mother", "mom"),
            "بابا" to listOf("بابا", "أبي", "ابي", "father", "dad"),
            "اخوي" to listOf("اخوي", "أخي", "اخي", "brother"),
            "اختي" to listOf("اختي", "أختي", "sister")
        )
        val candidates = aliases[wanted].orEmpty() + wanted
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val display = normalize(cursor.getString(nameIndex) ?: "")
                if (candidates.any { candidate -> display == normalize(candidate) || display.contains(normalize(candidate)) }) {
                    return cursor.getString(numberIndex)
                }
            }
        }
        return null
    }

    private fun openApp(context: Context, requested: String): Result {
        var wanted = normalize(requested)
            .replace(Regex("^(التطبيق|تطبيق)\\s+"), "")
            .replace(Regex("[؟?!.,،؛:]+$"), "")
            .trim()
        if (wanted.isBlank()) return Result(true, "اذكر اسم التطبيق الذي تريد فتحه.")

        // Cross-language aliases: spoken Arabic names should match English launcher labels,
        // and common English names should also resolve when the label is localized.
        val aliasGroups = listOf(
            listOf("واتساب", "whatsapp", "whats app"),
            listOf("فيسبوك", "facebook", "fb"),
            listOf("انستغرام", "انستقرام", "انستجرام", "instagram", "insta"),
            listOf("يوتيوب", "youtube"),
            listOf("تيك توك", "tiktok", "tik tok"),
            listOf("تلغرام", "تليجرام", "تيليجرام", "telegram"),
            listOf("كروم", "جوجل كروم", "google chrome", "chrome"),
            listOf("جيميل", "gmail", "جي ميل"),
            listOf("خرائط جوجل", "خرائط", "google maps", "maps"),
            listOf("جوجل", "google"),
            listOf("متجر بلاي", "بلاي ستور", "google play", "play store"),
            listOf("سناب شات", "سناب", "snapchat"),
            listOf("ماسنجر", "messenger"),
            listOf("تيليجرام", "telegram"),
            listOf("سبوتيفاي", "spotify"),
            listOf("زوم", "zoom"),
            listOf("تيمز", "مايكروسوفت تيمز", "microsoft teams", "teams")
        )
        val aliases = aliasGroups.firstOrNull { group -> group.any { normalize(it) == wanted || wanted.contains(normalize(it)) } }
            ?.map(::normalize).orEmpty()
        val candidates = (listOf(wanted) + aliases).distinct()
        val pm = context.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL
        )
        fun score(label: String, packageName: String): Int {
            val normalizedLabel = normalize(label)
            val normalizedPackage = normalize(packageName.substringAfterLast('.').replace('.', ' '))
            return when {
                candidates.any { it == normalizedLabel || it == normalizedPackage } -> 100
                candidates.any { normalizedLabel.contains(it) || it.contains(normalizedLabel) } -> 70
                candidates.any { normalizedPackage.contains(it) || it.contains(normalizedPackage) } -> 60
                else -> 0
            }
        }
        val match = apps.map { info ->
            val label = info.loadLabel(pm).toString()
            Triple(info, label, score(label, info.activityInfo.packageName))
        }.filter { it.third > 0 }.maxByOrNull { it.third }

        if (match != null) {
            val launch = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return Result(true, "تم فتح ${match.second}.")
            }
        }
        return Result(true, "لم أجد تطبيقًا مطابقًا لـ «$requested». جرّب نطق الاسم بالإنجليزية أو اذكر الاسم الظاهر تحت أيقونته.")
    }

    private fun containsAny(q: String, vararg values: String): Boolean = values.any { q.contains(normalize(it)) }

    fun normalize(value: String): String {
        return value.lowercase(Locale("ar", "JO"))
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ة", "ه")
            .replace("ى", "ي")
            .replace("ؤ", "و")
            .replace("ئ", "ي")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}

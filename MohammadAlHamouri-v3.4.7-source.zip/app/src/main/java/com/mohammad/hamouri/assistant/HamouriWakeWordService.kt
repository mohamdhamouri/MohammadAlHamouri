package com.mohammad.hamouri.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.mohammad.hamouri.R
import java.util.Locale

/**
 * Experimental always-listening wake phrase detector. It uses the device's ordinary
 * speech recognizer, not a low-power hardware hotword engine; availability depends on
 * the device/provider and Android background microphone rules.
 */
class HamouriWakeWordService : Service() {
    companion object {
        const val ACTION_START = "com.mohammad.hamouri.action.START_WAKE_WORD"
        const val ACTION_STOP = "com.mohammad.hamouri.action.STOP_WAKE_WORD"
        private const val TAG = "HamouriWakeWord"
        private const val CHANNEL_ID = "hamouri_wake_word"
        private const val NOTIFICATION_ID = 3401
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var triggered = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecognition()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Microphone permission is not granted; stopping wake-word service")
            stopSelf()
            return START_NOT_STICKY
        }
        beginListening()
        return START_STICKY
    }

    private fun beginListening() {
        if (listening || triggered) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "No speech recognition provider available")
            handler.postDelayed({ beginListening() }, 5000)
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { listening = false }
                    override fun onError(error: Int) {
                        listening = false
                        Log.d(TAG, "Recognizer error=$error; retrying")
                        scheduleRestart()
                    }
                    override fun onResults(results: android.os.Bundle?) {
                        listening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        Log.i(TAG, "Final recognition candidates: ${matches.joinToString(" | ")}")
                        if (matches.any { containsWakePhrase(it) }) {
                            triggerWake("final: ${matches.joinToString(" | ")}")
                        } else {
                            updateNotification("سمعت: ${matches.firstOrNull().orEmpty().take(70)} — قل حموري")
                            scheduleRestart()
                        }
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        Log.d(TAG, "Partial recognition candidates: ${matches.joinToString(" | ")}")
                        if (matches.any { containsWakePhrase(it) }) {
                            triggerWake("partial: ${matches.joinToString(" | ")}")
                        }
                    }
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                sr.startListening(speechIntent)
                listening = true
            }
        } catch (e: Exception) {
            listening = false
            Log.e(TAG, "Could not start recognizer", e)
            scheduleRestart()
        }
    }

    private fun normalizeArabic(text: String): String {
        return text.lowercase(Locale.forLanguageTag("ar-JO"))
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ى", "ي").replace("ـ", " ")
            .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
            .replace(Regex("[،,.!?؛:؟\\-]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }

    private fun containsWakePhrase(text: String): Boolean {
        val normalized = normalizeArabic(text)
        // Accept the phrase as a standalone token, with optional يا, and allow
        // recognizers that return a short sentence around the wake phrase.
        val tokens = normalized.split(' ').filter { it.isNotBlank() }
        val wakeTokens = setOf("حموري", "الحموري", "حمودي")
        return tokens.any { it in wakeTokens } ||
            tokens.windowed(2).any { it[0] == "يا" && it[1] in wakeTokens }
    }

    private fun triggerWake(reason: String) {
        if (triggered) return
        triggered = true
        Log.i(TAG, "Wake phrase detected; attempting to show assistant. $reason")
        updateNotification("تم اكتشاف كلمة الاستدعاء؛ جارٍ فتح المساعد")
        stopRecognition()
        try {
            val wake = Intent(this, com.mohammad.hamouri.WakeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(wake)
            HamouriVoiceInteractionService.showWakeSession()
        } catch (e: Exception) {
            Log.e(TAG, "Wake phrase detected but showing assistant failed", e)
            updateNotification("تم سماع كلمة الاستدعاء لكن تعذّر فتح الواجهة")
        }
        handler.postDelayed({ triggered = false; updateNotification(null); beginListening() }, 5000)
    }

    private fun updateNotification(status: String?) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun scheduleRestart() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ beginListening() }, 900)
    }

    private fun stopRecognition() {
        listening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "استماع كلمة حموري", NotificationManager.IMPORTANCE_LOW)
            channel.description = "إشعار دائم عند تفعيل الاستماع لكلمة حموري"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String? = null): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, com.mohammad.hamouri.MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID).setContentTitle("محمد الحموري يستمع لكلمة الاستدعاء")
                .setContentText(status ?: "قل: حموري أو يا حموري").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("محمد الحموري يستمع لكلمة الاستدعاء")
                .setContentText(status ?: "قل: حموري أو يا حموري").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending).setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopRecognition()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

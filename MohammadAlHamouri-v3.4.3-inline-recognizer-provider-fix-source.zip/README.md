# محمد الحموري 3.2.2 — فحص خدمة التعرف الصوتي

- إضافة `<queries>` لخدمة `android.speech.RecognitionService` لمعالجة قيود ظهور الحزم في Android 11 وما بعده.
- إذا تعذر بدء SpeechRecognizer، يعرض التطبيق هل يستطيع Android اكتشاف مزود خدمة التعرف الصوتي.
- إضافة اختصار إلى إعدادات خدمة/إدخال الصوت.
- الإبقاء على مسار VoiceInteractionService الحالي دون استخدام واجهات نظام مخفية.

ارفع محتويات هذا المشروع إلى مستودع GitHub وشغّل Actions لبناء APK.


## 3.2.5 assistant registration-only patch
This release adds the Android RecognitionService declaration and voice-interaction XML reference to improve visibility in Android assistant selection. MainActivity.kt and all internal microphone UI/recognition code are preserved byte-for-byte from 3.2.2. The added RecognitionService does not acquire or use the microphone.


## الإصدار 3.2.6 — تشخيص استدعاء المساعد
- تسجيل أحداث خدمة المساعد والجلسة في Logcat تحت الوسم `HamouriAssistant`.
- إظهار واجهة احتياطية عند استدعاء جلسة المساعد، وتسجيل أي استثناء عند تعذر فتح `MainActivity`.
- تصحيح صلاحية ربط خدمة التعرف الصوتي إلى `BIND_SPEECH_RECOGNITION`.
- تم تحديث رقم الإصدار إلى 3.2.6. لم يتم تأكيد البناء أو الاختبار على جهاز فعلي ضمن هذه الحزمة.


## الإصدار 3.2.8 — تشخيص مرئي لاستدعاء المساعد
- إضافة رسائل Toast مؤقتة عند جاهزية VoiceInteractionService، وإنشاء جلسة المساعد، واستدعاء onShow.
- الهدف هو تحديد ما إذا كان Android يصل إلى الخدمة والجلسة عند الضغط على زر المساعد.
- هذا إصدار تشخيصي؛ لم يُبنَ أو يُختبر على جهاز فعلي بعد.


## الإصدار 3.2.8
تم تحديث أسماء الخدمات في `voice_interaction_service.xml` إلى أسماء الفئات الكاملة (`com.mohammad.hamouri...`) لتجنب فشل تحليل أسماء مكونات الجلسة وخدمة التعرف الصوتي. هذا إصلاح مرشح يحتاج إلى بناء APK واختباره على الجهاز؛ ولا يثبت وحده أن كل قيود جهاز Infinix قد حُلّت.


## v3.3.2 assistant bar updates
- Raised the assistant overlay from the bottom edge.
- Starts Arabic speech recognition automatically when the assistant session is shown, when microphone permission and a recognition provider are available.
- Shows partial/final recognized words in the prompt field.
- Added a send arrow that forwards typed or recognized text to the existing MainActivity command/chat flow.

Build status: source changes are prepared but must be verified by GitHub Actions on the target project.


## Version 3.4.0 assistant overlay update
- Narrower, slightly raised centered assistant panel with a lighter dark background.
- Blue circular voice control; voice recognition starts automatically when the assistant session is shown.
- Removed waveform shortcut and added application settings shortcut.
- Up-arrow send control appears when text is entered. Text commands are handled inside the assistant overlay using local command routing and the saved Gemini API key.
- Plus button opens Android document picker. Existing microphone permissions were intentionally left unchanged.
\n\n## v3.4.2 microphone-session fix\n- Explicitly prefers an installed external SpeechRecognizer provider rather than accidentally selecting the app's own fallback RecognitionService.\n- Recognized speech is submitted automatically after final results.\n- Speech recognition errors provide a useful hint in the inline assistant.\n- Existing RECORD_AUDIO permission declarations and permission flow are preserved.\n
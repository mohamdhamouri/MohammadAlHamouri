package com.mohammad.hamouri.assistant

import android.Manifest
import android.content.Intent
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.service.voice.VoiceInteractionSession
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.provider.Settings
import android.net.Uri
import android.widget.TextView
import com.mohammad.hamouri.MainActivity

/** Compact, Gemini-inspired assistant input bar shown over the current screen. */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    companion object { private const val TAG = "HamouriAssistant" }

    private var root: LinearLayout? = null
    private var promptInput: EditText? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var inlineListening = false
    private var micButton: TextView? = null
    private var sendButton: TextView? = null
    private var responseView: TextView? = null
    private var inlineTts: TextToSpeech? = null
    private var ttsReady = false
    private var showGeneration = 0

    override fun onCreate() {
        super.onCreate()
        setUiEnabled(true)
        inlineTts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) inlineTts?.language = Locale("ar", "JO")
        }
        Log.i(TAG, "Compact assistant bar created")
    }

    override fun onCreateContentView(): View {
        val shell = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(43, 43, 46), dp(32).toFloat())
            elevation = dp(14).toFloat()
        }
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        promptInput = EditText(context).apply {
            hint = "اسأل محمد الحموري"
            setHintTextColor(Color.rgb(235, 235, 238))
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            textDirection = View.TEXT_DIRECTION_RTL
            setSingleLine(false)
            minLines = 1
            maxLines = 2
            background = null
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(8), dp(2), dp(8), dp(2))
            setOnEditorActionListener { _, actionId, event ->
                val sendAction = actionId == EditorInfo.IME_ACTION_SEND ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP)
                if (sendAction) {
                    submitPrompt()
                    true
                } else false
            }
        }
        panel.addView(promptInput, LinearLayout.LayoutParams(0, dp(48), 1f))

        val send = TextView(context).apply {
            text = "↑"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(66, 133, 244), dp(28).toFloat())
            contentDescription = "إرسال السؤال إلى محمد الحموري"
            setOnClickListener { submitPrompt() }
        }
        sendButton = send
        send.visibility = View.GONE
        panel.addView(send, LinearLayout.LayoutParams(dp(46), dp(46)))

        val add = TextView(context).apply {
            text = "+"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "إضافة صورة أو ملف"
            setOnClickListener { openPicker() }
        }
        panel.addView(add, LinearLayout.LayoutParams(dp(38), dp(46)))

        val mic = TextView(context).apply {
            text = "🎙"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(66, 133, 244), dp(30).toFloat())
            contentDescription = "الميكروفون؛ اضغط لإيقاف الاستماع أو استئنافه"
            setOnClickListener { if (inlineListening) stopInlineListening() else startInlineListening() }
        }
        micButton = mic
        panel.addView(mic, LinearLayout.LayoutParams(dp(48), dp(48)))

        val settings = TextView(context).apply {
            text = "⚙"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "إعدادات تطبيق محمد الحموري"
            setOnClickListener {
                try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { Log.e(TAG, "Could not open app settings", e) }
            }
        }
        panel.addView(settings, LinearLayout.LayoutParams(dp(36), dp(46)))
        shell.addView(panel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        responseView = TextView(context).apply {
            setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.END
            textDirection = View.TEXT_DIRECTION_RTL; visibility = View.GONE
            setPadding(dp(10), dp(8), dp(10), dp(4))
        }
        shell.addView(responseView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        promptInput?.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val hasText = !s.isNullOrBlank()
                sendButton?.visibility = if (hasText) View.VISIBLE else View.GONE
                micButton?.visibility = if (hasText) View.GONE else View.VISIBLE
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        root = shell
        return shell
    }

    private fun submitPrompt() {
        val prompt = promptInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) { startInlineListening(); return }
        stopInlineListening()
        showResponse("جارٍ المعالجة…")
        Thread {
            val answer = try {
                val local = com.mohammad.hamouri.CommandRouter.handle(context, prompt)
                if (local.handled) local.message else {
                    val identity = com.mohammad.hamouri.CommandRouter.identityResponse(prompt)
                    if (identity != null) identity else {
                        val key = context.getSharedPreferences("hamouri", android.content.Context.MODE_PRIVATE).getString("gemini_key", "").orEmpty()
                        com.mohammad.hamouri.GeminiApi.generate(key, listOf(com.mohammad.hamouri.GeminiApi.Turn(prompt, true))).getOrElse { "تعذر الحصول على إجابة: ${it.message ?: "خطأ غير معروف"}" }
                    }
                }
            } catch (e: Exception) { "حدث خطأ أثناء معالجة الطلب: ${e.message ?: "خطأ غير معروف"}" }
            root?.post {
                showResponse(answer)
                if (ttsReady && !answer.startsWith("جارٍ")) {
                    inlineTts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "hamouri_inline_answer")
                }
            }
        }.start()
    }

    private fun showResponse(text: String) {
        responseView?.text = text
        responseView?.visibility = View.VISIBLE
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf", "text/*"))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { context.startActivity(intent) } catch (e: Exception) { showResponse("تعذر فتح منتقي الملفات.") }
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i(TAG, "Assistant input bar shown; flags=$showFlags")
        // Each invocation of the system assistant starts a fresh inline session.
        showGeneration++
        promptInput?.setText("")
        promptInput?.hint = "اسأل محمد الحموري"
        responseView?.text = ""
        responseView?.visibility = View.GONE
        sendButton?.visibility = View.GONE
        micButton?.visibility = View.VISIBLE
        stopInlineListening()
        root?.visibility = View.VISIBLE
        window?.window?.let { actualWindow ->
            actualWindow.setBackgroundDrawableResource(android.R.color.transparent)
            actualWindow.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attributes = actualWindow.attributes
            attributes.width = (context.resources.displayMetrics.widthPixels * 0.92f).toInt()
            attributes.height = WindowManager.LayoutParams.WRAP_CONTENT
            attributes.gravity = Gravity.CENTER
            attributes.dimAmount = 0.06f
            attributes.y = -dp(20)
            actualWindow.attributes = attributes
            actualWindow.setLayout(attributes.width, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        // Begin listening automatically when the system assistant button opens this session.
        val generation = showGeneration
        promptInput?.postDelayed({
            if (generation == showGeneration && root?.visibility == View.VISIBLE) startInlineListening()
        }, 500L)
    }

    override fun onHide() {
        showGeneration++
        root?.visibility = View.GONE
        stopInlineListening()
        try { inlineTts?.stop() } catch (_: Exception) {}
        super.onHide()
    }

    private fun startInlineListening() {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            promptInput?.hint = "اسمح باستخدام الميكروفون من إعدادات التطبيق"
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            promptInput?.hint = "التعرف الصوتي غير متاح؛ اكتب سؤالك هنا"
            return
        }
        try {
            stopInlineListening()

            // Match the working in-app microphone: explicitly select an external
            // recognition provider so Android 11 does not route recognition to
            // this app's compatibility HamouriRecognitionService (which returns ERROR_CLIENT).
            val speechProvider = try {
                context.packageManager.queryIntentServices(
                    Intent("android.speech.RecognitionService"),
                    PackageManager.MATCH_DEFAULT_ONLY
                ).mapNotNull { it.serviceInfo }
                    .filter { it.packageName != context.packageName }
                    .sortedWith(compareBy<android.content.pm.ServiceInfo> {
                        if (it.packageName == "com.google.android.googlequicksearchbox" ||
                            it.packageName == "com.google.android.tts") 0 else 1
                    })
                    .firstOrNull()
            } catch (_: Exception) { null }

            val recognizer = if (speechProvider != null) {
                SpeechRecognizer.createSpeechRecognizer(
                    context,
                    ComponentName(speechProvider.packageName, speechProvider.name)
                )
            } else {
                SpeechRecognizer.createSpeechRecognizer(context)
            }
            speechRecognizer = recognizer
            // Reflect the tap immediately; don't wait for onReadyForSpeech,
            // which may never arrive when a provider rejects the request.
            inlineListening = true
            promptInput?.hint = "أنا أستمع إليك..."
            micButton?.text = "⏹"
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    inlineListening = true
                    promptInput?.hint = "أنا أستمع إليك..."
                    micButton?.text = "⏹"
                }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { inlineListening = false }
                override fun onError(error: Int) {
                    inlineListening = false
                    micButton?.text = "🎙"
                    if (promptInput?.text.isNullOrBlank()) {
                        promptInput?.hint = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "تعذر الوصول إلى الميكروفون"
                            SpeechRecognizer.ERROR_CLIENT -> "تعذر بدء التعرف الصوتي؛ تحقق من خدمة Google"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "خدمة التعرف الصوتي لا تملك إذن الميكروفون"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تحقق من اتصال الإنترنت"
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم أسمعك؛ اضغط الميكروفون وحاول مجددًا"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة الصوت مشغولة؛ حاول بعد لحظة"
                            else -> "تعذر الاستماع (رمز $error)"
                        }
                    } else {
                        promptInput?.hint = "اسأل محمد الحموري"
                    }
                    Log.w(TAG, "Inline speech recognition error=$error")
                }
                override fun onResults(results: Bundle?) {
                    inlineListening = false
                    micButton?.text = "🎙"
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        promptInput?.setText(spoken)
                        promptInput?.setSelection(spoken.length)
                    }
                    promptInput?.hint = "اسأل محمد الحموري"
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val spoken = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        promptInput?.setText(spoken)
                        promptInput?.setSelection(spoken.length)
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer.startListening(speechIntent)
        } catch (e: Exception) {
            inlineListening = false
            Log.e(TAG, "Could not start inline speech recognition", e)
            promptInput?.hint = "اكتب سؤالك أو اضغط الميكروفون مجددًا"
        }
    }

    private fun stopInlineListening() {
        try { speechRecognizer?.cancel() } catch (_: Exception) { }
        try { speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        inlineListening = false
        micButton?.text = "🎙"
    }

    override fun onDestroy() {
        stopInlineListening()
        try { inlineTts?.stop() } catch (_: Exception) {}
        inlineTts?.shutdown()
        inlineTts = null
        super.onDestroy()
    }

    private fun openMainActivity(listen: Boolean, command: String? = null) {
        val assistantIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, listen)
            if (!command.isNullOrBlank()) putExtra("hamouri_voice_command", command)
        }
        try {
            startAssistantActivity(assistantIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start assistant activity", e)
            try { context.startActivity(assistantIntent) }
            catch (second: Exception) { Log.e(TAG, "Fallback activity launch failed", second) }
        }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(61, 61, 65))
    }
}

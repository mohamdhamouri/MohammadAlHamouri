package com.mohammad.hamouri

import android.app.admin.DeviceAdminReceiver

class HamouriDeviceAdminReceiver : DeviceAdminReceiver()

package com.mohammad.hamouri

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.service.voice.VoiceInteractionService
import androidx.core.content.ContextCompat

/**
 * Global Android assistant entry point.
 *
 * Important: Android's AlwaysOnHotwordDetector and the corresponding
 * createAlwaysOnHotwordDetector() API are @SystemApi/hidden APIs and require
 * MANAGE_HOTWORD_DETECTION on current Android releases. They are not available
 * to an ordinary third-party APK, so referencing them directly makes a normal
 * Gradle build fail with "Unresolved reference".
 *
 * We therefore keep the supported public VoiceInteractionService path here and
 * use HamouriHotwordService as the software fallback for "يا حموري".
 */
class HamouriVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        startHotwordListenerIfAllowed()
    }

    override fun onShutdown() {
        stopService(Intent(this, HamouriHotwordService::class.java))
        super.onShutdown()
    }

    override fun onLaunchVoiceAssistFromKeyguard() {
        // Let the normal VoiceInteractionSession handle the assistant invocation.
        super.onLaunchVoiceAssistFromKeyguard()
    }

    private fun startHotwordListenerIfAllowed() {
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, HamouriHotwordService::class.java)
            )
        } catch (_: Exception) {
            // MainActivity will retry after the microphone permission is granted.
        }
    }
}

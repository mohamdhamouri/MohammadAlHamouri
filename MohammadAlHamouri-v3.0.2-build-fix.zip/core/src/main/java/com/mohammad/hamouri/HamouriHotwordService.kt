package com.mohammad.hamouri

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Software wake-phrase listener for "يا حموري" / "حموري".
 * It runs as a microphone foreground service while the user has selected
 * محمد الحموري as the device assistant and granted microphone permission.
 */
class HamouriHotwordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var paused = false
    private var oneShotCommand = false
    private var oneShotAttempts = 0

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false; scheduleListen(250) }
        override fun onError(error: Int) {
            listening = false
            if (oneShotCommand && !paused) {
                if (oneShotAttempts < 3) {
                    oneShotAttempts++
                    scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 900 else 500)
                } else {
                    oneShotCommand = false
                    oneShotAttempts = 0
                    speakThenListen("لم أسمع الأمر. تفضل.")
                }
            } else if (!paused) {
                scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 450)
            }
        }
        override fun onResults(results: Bundle?) {
            listening = false
            val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            if (oneShotCommand) {
                val command = texts.firstOrNull()?.trim().orEmpty()
                oneShotCommand = false
                oneShotAttempts = 0
                handleDirectCommand(command)
            } else {
                val command = texts.firstNotNullOfOrNull { wakeCommand(it) }
                if (command != null) handleWakeCommand(command)
                else scheduleListen(250)
            }
        }
        override fun onPartialResults(partialResults: Bundle?) {
            // We wait for final results so the same sentence is not executed twice.
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            scheduleListen(300)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (action == ACTION_LISTEN_COMMAND) openMainForMicrophonePermission()
            return START_STICKY
        }
        when (action) {
            ACTION_PAUSE -> {
                pauseListening()
                return START_STICKY
            }
            ACTION_RESUME -> {
                oneShotCommand = false
                oneShotAttempts = 0
                paused = false
                scheduleListen(500)
                return START_STICKY
            }
            ACTION_LISTEN_COMMAND -> {
                oneShotCommand = true
                oneShotAttempts = 0
                paused = false
                handler.removeCallbacksAndMessages(null)
                listening = false
                try { recognizer?.cancel() } catch (_: Exception) {}
                if (recognizer == null && SpeechRecognizer.isRecognitionAvailable(this)) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
                }
                scheduleListen(350)
                return START_STICKY
            }
        }
        if (recognizer == null && SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            scheduleListen(300)
        }
        return START_STICKY
    }

    private fun pauseListening() {
        paused = true
        handler.removeCallbacksAndMessages(null)
        listening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    private fun scheduleListen(delay: Long) {
        if (paused || listening || recognizer == null) return
        handler.postDelayed({ startListen() }, delay)
    }

    private fun startListen() {
        if (paused || listening || recognizer == null) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            scheduleListen(1000)
        }
    }

    private fun wakeCommand(text: String): String? {
        if (!HamouriWakePhrase.isInvocation(text)) return null
        return HamouriWakePhrase.strip(text)
    }

    private fun handleDirectCommand(command: String) {
        paused = true
        if (command.isBlank()) {
            speakThenListen("لم أسمع الأمر. تفضل.")
            return
        }
        executeCommand(command)
    }

    private fun handleWakeCommand(command: String) {
        paused = true
        executeCommand(command)
    }

    private fun executeCommand(command: String) {
        val router = CommandRouter(this)
        if (command.isBlank()) {
            speakThenListen("نعم، أنا حموري. تفضل.")
            return
        }
        val result = router.execute(command)
        result.pendingIntent?.let { pending ->
            try { startActivity(pending.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
        if (result.requestContactsPermission || result.requestCallPermission || result.requestCameraPermission) {
            openMainForPermission(result.requestContactsPermission, result.requestCallPermission, result.requestCameraPermission, command)
        } else if (!result.actionPerformed) {
            // Non-local requests are handed to the full Gemini chat UI.
            openMainForText(command)
        }
        paused = false
        scheduleListen(900)
    }

    private fun openMainForMicrophonePermission() {
        val intent = Intent(this, HamouriCoreSetupActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(HamouriCoreSetupActivity.EXTRA_MICROPHONE, true)
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    private fun openMainForPermission(contacts: Boolean, calls: Boolean, camera: Boolean, command: String) {
        val intent = Intent(this, HamouriCoreSetupActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(HamouriCoreSetupActivity.EXTRA_CONTACTS, contacts)
            putExtra(HamouriCoreSetupActivity.EXTRA_CALLS, calls)
            putExtra(HamouriCoreSetupActivity.EXTRA_CAMERA, camera)
            putExtra(HamouriCoreSetupActivity.EXTRA_COMMAND, command)
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    private fun openMainForText(text: String) {
        val intent = Intent().setClassName(
            HamouriCoreSetupActivity.USER_APP_PACKAGE,
            HamouriCoreSetupActivity.USER_APP_ACTIVITY
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(HamouriCoreSetupActivity.EXTRA_VOICE_TEXT, text)
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    private fun speakThenListen(text: String) {
        lateinit var tts: android.speech.tts.TextToSpeech
        tts = android.speech.tts.TextToSpeech(this) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                tts.language = Locale("ar")
                tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        tts.shutdown()
                        paused = false
                        scheduleListen(250)
                    }
                    override fun onError(utteranceId: String?) {
                        tts.shutdown()
                        paused = false
                        scheduleListen(250)
                    }
                })
                tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "hamouri-wake")
            } else {
                tts.shutdown()
                paused = false
                scheduleListen(250)
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "حموري - الاستماع الصوتي", NotificationManager.IMPORTANCE_LOW).apply {
                description = "الاستماع لعبارة يا حموري لتشغيل الأوامر الصوتية"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val openIntent = Intent().setClassName(
            HamouriCoreSetupActivity.USER_APP_PACKAGE,
            HamouriCoreSetupActivity.USER_APP_ACTIVITY
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val open = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("محمد الحموري")
                .setContentText("استماع لعبارة «يا حموري»")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("محمد الحموري")
                .setContentText("استماع لعبارة «يا حموري»")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        paused = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "hamouri_hotword"
        private const val NOTIFICATION_ID = 2026
        const val ACTION_PAUSE = "com.mohammad.hamouri.PAUSE_HOTWORD"
        const val ACTION_RESUME = "com.mohammad.hamouri.RESUME_HOTWORD"
        const val ACTION_LISTEN_COMMAND = "com.mohammad.hamouri.LISTEN_COMMAND"
    }
}

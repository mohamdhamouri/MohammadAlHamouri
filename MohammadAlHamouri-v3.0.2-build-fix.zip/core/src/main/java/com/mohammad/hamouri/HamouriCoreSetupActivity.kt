package com.mohammad.hamouri

import android.Manifest
import androidx.activity.ComponentActivity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Small permission bridge for the System Core. The visible user app cannot
 * grant permissions to a different package, so the core requests its own
 * microphone/contacts/call/camera permissions here.
 */
class HamouriCoreSetupActivity : ComponentActivity() {
    private var pendingContacts = false
    private var pendingCalls = false
    private var pendingCamera = false
    private var pendingMicrophone = false
    private var pendingCommand: String = ""

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        requestNext()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val label = TextView(this).apply {
            text = "محمد الحموري\n\nجاري تهيئة نواة المساعد…"
            textSize = 18f
            setPadding(48, 80, 48, 48)
        }
        setContentView(label)
        pendingContacts = intent.getBooleanExtra(EXTRA_CONTACTS, false)
        pendingCalls = intent.getBooleanExtra(EXTRA_CALLS, false)
        pendingCamera = intent.getBooleanExtra(EXTRA_CAMERA, false)
        pendingMicrophone = intent.getBooleanExtra(EXTRA_MICROPHONE, false)
        pendingCommand = intent.getStringExtra(EXTRA_COMMAND).orEmpty()
        requestNext()
    }

    private fun requestNext() {
        when {
            pendingMicrophone && !granted(Manifest.permission.RECORD_AUDIO) -> request(Manifest.permission.RECORD_AUDIO)
            pendingContacts && !granted(Manifest.permission.READ_CONTACTS) -> request(Manifest.permission.READ_CONTACTS)
            pendingCalls && !granted(Manifest.permission.CALL_PHONE) -> request(Manifest.permission.CALL_PHONE)
            pendingCamera && !granted(Manifest.permission.CAMERA) -> request(Manifest.permission.CAMERA)
            else -> finishSetup()
        }
    }

    private fun request(permission: String) {
        when (permission) {
            Manifest.permission.RECORD_AUDIO -> pendingMicrophone = false
            Manifest.permission.READ_CONTACTS -> pendingContacts = false
            Manifest.permission.CALL_PHONE -> pendingCalls = false
            Manifest.permission.CAMERA -> pendingCamera = false
        }
        permissionLauncher.launch(permission)
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun finishSetup() {
        if (granted(Manifest.permission.RECORD_AUDIO)) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, HamouriHotwordService::class.java))
            } catch (_: Exception) {}
        }
        if (pendingCommand.isNotBlank()) {
            val ui = Intent().setClassName(
                USER_APP_PACKAGE,
                USER_APP_ACTIVITY
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_VOICE_TEXT, pendingCommand)
            }
            try { startActivity(ui) } catch (_: Exception) {}
        }
        finish()
    }

    companion object {
        const val EXTRA_CONTACTS = "core_permission_contacts"
        const val EXTRA_CALLS = "core_permission_calls"
        const val EXTRA_CAMERA = "core_permission_camera"
        const val EXTRA_MICROPHONE = "core_permission_microphone"
        const val EXTRA_COMMAND = "core_pending_command"
        const val EXTRA_VOICE_TEXT = "hamouri_voice_text"
        const val USER_APP_PACKAGE = "com.mohammad.hamouri"
        const val USER_APP_ACTIVITY = "com.mohammad.hamouri.MainActivity"
    }
}

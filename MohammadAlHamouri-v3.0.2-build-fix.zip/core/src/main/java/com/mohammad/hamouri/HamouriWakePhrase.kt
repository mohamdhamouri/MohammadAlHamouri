package com.mohammad.hamouri

object HamouriWakePhrase {
    private val phrases = listOf("يا حموري", "حموري")

    fun clean(text: String): String = text
        .replace(Regex("[\u064B-\u065F\u0670]"), "")
        .replace('،', ' ')
        .replace(',', ' ')
        .replace('.', ' ')
        .replace('؟', ' ')
        .replace('!', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    fun strip(text: String): String {
        var value = clean(text)
        for (phrase in phrases) {
            if (value.startsWith(phrase, ignoreCase = true)) {
                value = value.removePrefix(phrase).trim()
                break
            }
        }
        return value
    }

    fun isInvocation(text: String): Boolean = phrases.any { phrase ->
        clean(text).startsWith(phrase, ignoreCase = true)
    }
}

package com.mohammad.hamouri

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.min

/**
 * فهم محلي للأوامر العربية قبل إرسالها إلى Gemini.
 * الفكرة: نفهم النية والمعنى، وليس كلمة واحدة محددة فقط.
 * هذا لا يدّعي تغطية كل لهجات العربية، لكنه يوسّع الأوامر الشائعة
 * ويطبّع اختلافات النطق والكتابة ويستخدم مطابقة مرنة لأسماء التطبيقات.
 */
class CommandRouter(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())

    fun execute(raw: String): CommandResult {
        val clean = normalize(raw)
        if (clean.isBlank()) return CommandResult("لم أسمع أمرًا واضحًا.", true)

        // الشاشة والقفل
        if (containsAny(clean,
                "اقفل الشاشة", "قفل الشاشة", "سكر الشاشة", "سكر التلفون", "سكر الهاتف",
                "طفي الشاشة", "اطفي الشاشة", "طفي التلفون", "طفي الهاتف", "نام التلفون",
                "اقفل التلفون", "اقفل الهاتف", "قفل التلفون", "قفل الهاتف")) {
            return lockScreen()
        }
        if (containsAny(clean,
                "افتح الشاشة", "شغل الشاشة", "صحصح الشاشة", "نبه الشاشة", "صحي الشاشة",
                "وقظ الشاشة", "اصحي الشاشة", "صحي التلفون", "شغل التلفون", "شغل الهاتف",
                "افتح التلفون", "افتح الهاتف")) {
            return wakeScreen()
        }

        // الكشاف / الفلاش
        if (containsAny(clean,
                "شغل الكشاف", "شغل الفلاش", "افتح الكشاف", "افتح الفلاش", "ولع الكشاف",
                "ولع الفلاش", "نور الكشاف", "نور الفلاش", "شغل ضو الكاميرا", "شغل ضوء الكاميرا")) {
            return setTorch(true)
        }
        if (containsAny(clean,
                "طفي الكشاف", "اطفي الكشاف", "طفئ الكشاف", "سكر الكشاف", "قفل الكشاف",
                "طفي الفلاش", "اطفي الفلاش", "طفئ الفلاش", "سكر الفلاش", "قفل الفلاش",
                "اطفئ الكشاف", "اطفئ الفلاش")) {
            return setTorch(false)
        }

        // الصوت
        if (containsAny(clean, "ارفع الصوت", "علي الصوت", "اعلي الصوت", "كبر الصوت", "زود الصوت", "زيد الصوت", "خل الصوت عالي", "وطي الصوت")) {
            return if (containsAny(clean, "وطي الصوت")) adjustVolume(AudioManager.ADJUST_LOWER) else adjustVolume(AudioManager.ADJUST_RAISE)
        }
        if (containsAny(clean, "اخفض الصوت", "نزل الصوت", "وطي الصوت", "وطيلي الصوت", "قلل الصوت", "خفف الصوت")) {
            return adjustVolume(AudioManager.ADJUST_LOWER)
        }
        if (containsAny(clean, "كتم الصوت", "اكتم الصوت", "سكت الصوت", "اسكت الصوت", "صامت")) {
            return adjustVolume(AudioManager.ADJUST_MUTE)
        }

        // الإعدادات والاتصال والكاميرا
        if (containsAny(clean, "افتح الاعدادات", "افتح اعدادات الهاتف", "روح للاعدادات", "وديني للاعدادات", "دخلني عالاعدادات", "دخلني على الاعدادات")) {
            return launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
        }
        if (containsAny(clean, "افتح الواي فاي", "افتح الوايفاي", "افتح الواي فاي", "روح للواي فاي", "وديني عالواي فاي", "شغل الواي فاي")) {
            return launch(Intent(Settings.ACTION_WIFI_SETTINGS), "فتحت إعدادات الواي فاي.")
        }
        if (containsAny(clean, "افتح البلوتوث", "روح للبلوتوث", "وديني عالبلوتوث", "شغل البلوتوث")) {
            return launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "فتحت إعدادات البلوتوث.")
        }
        if (containsAny(clean, "افتح بيانات الهاتف", "افتح بيانات الجوال", "افتح بيانات الموبايل", "روح لبيانات الهاتف", "روح لبيانات الجوال")) {
            return launch(Intent(Settings.ACTION_WIRELESS_SETTINGS), "فتحت إعدادات الشبكة.")
        }
        if (containsAny(clean, "افتح الكاميرا", "شغل الكاميرا", "جيب الكاميرا", "هات الكاميرا", "خليني بالكاميرا", "وديني للكاميرا")) {
            return launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
        }
        if (containsAny(clean, "افتح الهاتف", "افتح الاتصال", "افتح الاتصالات", "افتح لوحة الاتصال", "جيب لوحة الاتصال")) {
            return launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        }

        // الاتصال: لهجات وصيغ متعددة، بما فيها "دق على" و"رن على" و"كلم".
        val callTarget = extractCallTarget(clean)
        if (!callTarget.isNullOrBlank()) {
            val number = Regex("[+0-9][+0-9()\\- ]{4,}").find(callTarget)?.value?.trim()
            if (!number.isNullOrBlank()) return dial(number)
            return dialContact(cleanContactTarget(callTarget))
        }

        // فتح التطبيقات: ابحث عن اسم التطبيق في الجملة، وليس بعد كلمة "افتح" فقط.
        val appNames = extractAppNames(clean)
        if (appNames.isNotEmpty()) {
            val unique = appNames.distinct()
            val intents = unique.mapNotNull { name -> findLaunchIntent(name)?.let { name to it } }
            if (intents.isNotEmpty()) {
                launchApps(intents)
                val labels = intents.map { it.first }.joinToString(" و")
                return CommandResult("حسنًا، فتحت $labels.", true)
            }
            return CommandResult("لم أجد التطبيق المطلوب على الهاتف.", true)
        }

        // إذا كانت الجملة تبدو كطلب فتح تطبيق ولكن اسم التطبيق غير معروف، نبحث عن الجزء بعد فعل الفتح.
        if (looksLikeOpenRequest(clean)) {
            val candidate = cleanAppName(extractAfterOpenVerb(clean))
            if (candidate.isNotBlank()) {
                val intent = findLaunchIntent(candidate)
                if (intent != null) return launch(intent, "حسنًا، فتحت $candidate.")
                return CommandResult("لم أجد تطبيقًا باسم $candidate على الهاتف.", true)
            }
        }

        return CommandResult("", false)
    }

    private fun containsAny(text: String, vararg phrases: String): Boolean = phrases.any { text.contains(normalize(it)) }

    private fun extractCallTarget(text: String): String? {
        val patterns = listOf(
            Regex("(?:اتصل|اتصلي|اتصللي|دق|دقلي|دقي|رن|رنلي|رني|كلم|كلمي|كلمني|حاكي|احكي|احكيله|احكيلها|بدي احكي مع|بدي اكلم|ابي اكلم|ابغى اكلم|عايز اكلم|عايزة اكلم|ودي اكلم|ودي احكي مع|خليني اكلم|خلني اكلم|وصلني مع)\\s*(?:ب|بـ|على|عال|علي|مع)?\\s*(.+)$")
        )
        return patterns.firstNotNullOfOrNull { it.find(text)?.groupValues?.getOrNull(1)?.trim() }
    }

    private fun cleanContactTarget(value: String): String {
        return value.trim().trim('.', '،', ',', '؟', '?', '!')
            .replace(Regex("^(لو سمحت|من فضلك|رجاء|يا)\\s+"), "")
            .trim()
    }

    private fun extractAppNames(text: String): List<String> {
        val openWords = listOf(
            "افتح", "شغل", "شغلي", "شغله", "شغللي", "دخلني", "دخّلني", "دخلني ع", "دخلني على",
            "ودني", "وديني", "روحني", "خذني", "خلني", "خليني", "هات", "جيب", "شغل لي", "افتح لي",
            "افتحلي", "بدي افتح", "بدي اشغل", "ابي افتح", "ابي اشغل", "ابغى افتح", "ابغى اشغل",
            "اريد افتح", "اريد اشغل", "عايز افتح", "عايز اشغل", "عايزة افتح", "ودي افتح", "ودي اشغل"
        )
        if (!openWords.any { text.contains(normalize(it)) }) return emptyList()

        val found = mutableListOf<String>()
        for ((canonical, aliases) in appAliasMap) {
            if (aliases.any { containsAlias(text, it) }) found += canonical
        }
        return found
    }

    private fun containsAlias(text: String, alias: String): Boolean {
        val n = normalize(alias)
        if (text.contains(n)) return true
        // بعض نواتج التعرف الصوتي تكتب الاسم ملتصقًا أو بحذف الهمزات.
        val compact = compactArabic(text)
        val compactAlias = compactArabic(n)
        return compact.contains(compactAlias) || levenshteinNearby(compact, compactAlias)
    }

    private fun looksLikeOpenRequest(text: String): Boolean {
        return listOf("افتح", "شغل", "دخلني", "ودني", "وديني", "روحني", "خلني", "خليني", "هات", "جيب", "بدي افتح", "ابي افتح", "ابغى افتح", "عايز افتح", "عايزة افتح", "ودي افتح")
            .any { text.contains(normalize(it)) }
    }

    private fun extractAfterOpenVerb(text: String): String {
        val words = listOf("بدي افتح", "ابي افتح", "ابغى افتح", "عايز افتح", "عايزة افتح", "ودي افتح", "افتحلي", "افتح لي", "افتح", "شغللي", "شغل لي", "شغلي", "شغل", "دخلني على", "دخلني ع", "دخلني", "وديني", "ودني", "روحني", "خليني", "خلني", "هات", "جيب")
        val found = words.firstOrNull { text.contains(normalize(it)) } ?: return text
        return text.substringAfter(normalize(found), "").trim()
            .replace(Regex("^(تطبيق|التطبيق|برنامج|البرنامج)\\s+"), "")
            .trim()
    }

    private fun lockScreen(): CommandResult {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName("com.mohammad.hamouri.core", "com.mohammad.hamouri.HamouriDeviceAdminReceiver")
        if (!dpm.isAdminActive(admin)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "يسمح هذا الإذن لحموري بقفل الشاشة عند طلب ذلك صوتيًا.")
            }
            return CommandResult("لأتمكن من قفل الشاشة تلقائيًا، فعّل صلاحية إدارة الجهاز مرة واحدة.", true, intent)
        }
        return try {
            dpm.lockNow()
            CommandResult("تم قفل الشاشة.", true)
        } catch (_: Exception) {
            CommandResult("تعذر قفل الشاشة على جهازك.", true)
        }
    }

    private fun wakeScreen(): CommandResult = try {
        val intent = Intent(context, HamouriWakeActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        )
        context.startActivity(intent)
        CommandResult("حسنًا، أيقظت الشاشة. إذا كان عليها PIN أو نمط أو كلمة مرور فلن أتجاوز قفل الأمان.", true)
    } catch (_: Exception) {
        CommandResult("تعذر إيقاظ الشاشة تلقائيًا على جهازك.", true)
    }

    private fun setTorch(on: Boolean): CommandResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult(if (on) "أحتاج إذن الكاميرا لتشغيل الكشاف." else "أحتاج إذن الكاميرا لإطفاء الكشاف.", true, requestCameraPermission = true)
        }
        val manager = context.getSystemService(CameraManager::class.java)
        return try {
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) CommandResult("هذا الجهاز لا يوفّر كشافًا يمكن التحكم به.", true)
            else {
                manager.setTorchMode(cameraId, on)
                CommandResult(if (on) "تم تشغيل الكشاف." else "تم إطفاء الكشاف.", true)
            }
        } catch (_: Exception) {
            CommandResult("تعذر التحكم بالكشاف على جهازك.", true)
        }
    }

    private fun adjustVolume(direction: Int): CommandResult = try {
        val audio = context.getSystemService(AudioManager::class.java)
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        val msg = when (direction) {
            AudioManager.ADJUST_RAISE -> "رفعت الصوت."
            AudioManager.ADJUST_LOWER -> "خفضت الصوت."
            else -> "تم كتم الصوت."
        }
        CommandResult(msg, true)
    } catch (_: Exception) { CommandResult("تعذر التحكم بالصوت.", true) }

    private fun dialContact(target: String): CommandResult {
        if (target.isBlank()) return CommandResult("اذكر اسم جهة الاتصال التي تريد الاتصال بها.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult("أحتاج إذن جهات الاتصال لأبحث عن \"$target\" وأتصل به.", true, requestContactsPermission = true)
        }
        val number = findContactNumber(target)
        return if (number != null) dial(number) else CommandResult("لم أجد جهة اتصال باسم $target. تأكد من اسمها في جهات الاتصال.", true)
    }

    private fun findContactNumber(target: String): String? {
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val wanted = normalize(target)
        context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val display = cursor.getString(1).orEmpty()
                val normalizedDisplay = normalize(display)
                if (normalizedDisplay.contains(wanted) || wanted.contains(normalizedDisplay) || levenshteinNearby(normalizedDisplay, wanted)) {
                    return cursor.getString(0)
                }
            }
        }
        val aliases = when (compactArabic(target)) {
            "ماما", "امي", "الوالده" -> listOf("ماما", "أمي", "امي", "الوالدة", "والدتي", "امي")
            "بابا", "ابي", "الوالد" -> listOf("بابا", "أبي", "ابي", "الوالد", "والدي", "ابوي")
            else -> emptyList()
        }
        for (alias in aliases) {
            val aliasWanted = normalize(alias)
            context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    if (normalize(cursor.getString(1).orEmpty()).contains(aliasWanted)) return cursor.getString(0)
                }
            }
        }
        return null
    }

    fun executeTool(call: AiToolCall): CommandResult = when (call.name) {
        "open_settings" -> launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
        "open_camera" -> launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
        "open_dialer" -> launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        "dial_number" -> dial(call.arguments.optString("number"))
        "open_app" -> {
            val name = call.arguments.optString("name").trim()
            val intent = findLaunchIntent(name)
            if (intent != null) launch(intent, "حسنًا، فتحت $name.") else CommandResult("لم أجد تطبيقًا باسم $name.", true)
        }
        "lock_screen" -> lockScreen()
        "wake_screen" -> wakeScreen()
        "torch_on" -> setTorch(true)
        "torch_off" -> setTorch(false)
        else -> CommandResult("الأداة المطلوبة غير متاحة على هذا الإصدار.", true)
    }

    private fun dial(number: String): CommandResult {
        if (number.isBlank()) return CommandResult("لم أجد رقمًا صالحًا للاتصال.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult("أحتاج إذن المكالمات لأتصل بهذا الرقم تلقائيًا.", true, requestCallPermission = true)
        }
        return CommandResult("حسنًا، سأتصل الآن.", true, Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
    }

    private fun normalize(value: String): String {
        return HamouriWakePhrase.strip(value)
            .lowercase(Locale("ar"))
            .replace(Regex("[ًٌٍَُِّْـ]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و')
            .replace('ة', 'ه')
            .replace(Regex("[؟?!،,.:؛]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun compactArabic(value: String): String = normalize(value).replace(" ", "")

    private fun levenshteinNearby(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        if (a.length < 3 || b.length < 3) return false
        if (kotlin.math.abs(a.length - b.length) > 2) return false
        return levenshtein(a, b) <= min(2, maxOf(a.length, b.length) / 4)
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            for (j in prev.indices) prev[j] = cur[j]
        }
        return prev[b.length]
    }

    private fun launchApps(intents: List<Pair<String, Intent>>) {
        intents.forEachIndexed { index, pair ->
            val delay = index * 650L
            main.postDelayed({
                try { context.startActivity(pair.second.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }, delay)
        }
    }

    private fun launch(intent: Intent, message: String): CommandResult = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CommandResult(message, true)
    } catch (_: Exception) { CommandResult("تعذر تنفيذ هذا الإجراء على جهازك.", true) }

    private fun cleanAppName(value: String): String {
        return normalize(value)
            .replace(Regex("^(تطبيق|التطبيق|برنامج|البرنامج)\\s+"), "")
            .replace(Regex("\\s+(من فضلك|لو سمحت|رجاء)$"), "")
            .trim(' ', '،', ',', '.', '؟', '?')
    }

    /**
     * أسماء يفهمها المستخدم بالعربية حتى لو كان اسم التطبيق الظاهر في الهاتف
     * بالإنجليزية.  نربط الاسم المنطوق بالـ package name أولًا، ثم نستخدم
     * اسم التطبيق المثبت كحل احتياطي.  لذلك "واتساب" لا يحتاج أن يكون label
     * التطبيق عربيًا على الجهاز.
     */
    private val appAliasMap = linkedMapOf(
        "واتساب" to listOf("واتساب", "الواتساب", "وتساب", "الوتساب", "واتس", "الواتس", "واتس اب", "واتساب اب", "whatsapp"),
        "فيسبوك" to listOf("فيسبوك", "الفيسبوك", "فيس بوك", "الفيس بوك", "فيس", "الفيس", "facebook", "facebook lite"),
        "انستغرام" to listOf("انستغرام", "الانستغرام", "انستجرام", "الانستجرام", "انستا", "الانستا", "instagram"),
        "يوتيوب" to listOf("يوتيوب", "اليوتيوب", "يوتوب", "اليـوتيوب", "youtube"),
        "ماسنجر" to listOf("ماسنجر", "الماسنجر", "مسنجر", "المسنجر", "messenger"),
        "تيك توك" to listOf("تيك توك", "التيك توك", "تيكتوك", "التيكتوك", "tiktok", "tik tok"),
        "تلغرام" to listOf("تلغرام", "التلغرام", "تليجرام", "التليجرام", "تيليجرام", "التيليجرام", "telegram"),
        "سناب شات" to listOf("سناب", "السناب", "سناب شات", "السناب شات", "snapchat"),
        "تويتر" to listOf("تويتر", "التويتر", "twitter", "اكس", "الاكس", "x"),
        "خرائط جوجل" to listOf("خرائط جوجل", "خرائط قوقل", "خرائط", "الخرائط", "google maps", "maps"),
        "جوجل" to listOf("جوجل", "قوقل", "google"),
        "كروم" to listOf("كروم", "الكروم", "جوجل كروم", "قوقل كروم", "chrome", "google chrome"),
        "المتصفح" to listOf("المتصفح", "متصفح", "الانترنت", "الإنترنت", "متصفح الانترنت", "browser", "internet"),
        "جيميل" to listOf("جيميل", "الجي ميل", "جي ميل", "gmail", "google mail"),
        "جوجل درايف" to listOf("جوجل درايف", "قوقل درايف", "درايف", "google drive", "drive"),
        "جوجل بلاي" to listOf("جوجل بلاي", "قوقل بلاي", "بلاي ستور", "متجر بلاي", "google play", "play store"),
        "تيليجرام" to listOf("تيليجرام", "التيليجرام", "telegram"),
        "ديسكورد" to listOf("ديسكورد", "الديسكورد", "discord"),
        "نتفلكس" to listOf("نتفلكس", "نتفليكس", "النتفلكس", "netflix"),
        "سبوتيفاي" to listOf("سبوتيفاي", "السبوتيفاي", "spotify"),
        "زووم" to listOf("زووم", "الزووم", "zoom"),
    )

    private fun findLaunchIntent(requested: String): Intent? {
        val pm = context.packageManager
        val normalized = normalize(requested)
        val compact = compactArabic(normalized)

        val packageAliases = mapOf(
            "واتساب" to listOf("com.whatsapp"),
            "فيسبوك" to listOf("com.facebook.katana", "com.facebook.lite"),
            "انستغرام" to listOf("com.instagram.android"),
            "يوتيوب" to listOf("com.google.android.youtube"),
            "ماسنجر" to listOf("com.facebook.orca"),
            "تيك توك" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            "تلغرام" to listOf("org.telegram.messenger"),
            "تيليجرام" to listOf("org.telegram.messenger"),
            "سناب شات" to listOf("com.snapchat.android"),
            "تويتر" to listOf("com.twitter.android"),
            "خرائط جوجل" to listOf("com.google.android.apps.maps"),
            "جوجل" to listOf("com.google.android.googlequicksearchbox"),
            "كروم" to listOf("com.android.chrome", "com.google.android.apps.chrome"),
            "جيميل" to listOf("com.google.android.gm"),
            "جوجل درايف" to listOf("com.google.android.apps.docs"),
            "جوجل بلاي" to listOf("com.android.vending"),
            "ديسكورد" to listOf("com.discord"),
            "نتفلكس" to listOf("com.netflix.mediaclient"),
            "سبوتيفاي" to listOf("com.spotify.music"),
            "زووم" to listOf("us.zoom.videomeetings")
        )

        val canonical = appAliasMap.entries.firstOrNull { (_, aliases) ->
            aliases.any { alias ->
                val a = compactArabic(alias)
                a.length >= 2 && (compact == a || compact.contains(a) || a.contains(compact))
            }
        }?.key ?: normalized
        for (pkg in packageAliases[canonical].orEmpty()) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) return intent
        }

        val candidates = buildList {
            add(compact)
            addAll(appAliasMap[canonical].orEmpty().map { compactArabic(it) })
        }.distinct()

        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { app ->
            val label = compactArabic(pm.getApplicationLabel(app).toString())
            candidates.any { candidate ->
                candidate.length >= 3 && (label == candidate || label.contains(candidate) || candidate.contains(label) || levenshteinNearby(label, candidate))
            }
        } ?: return null
        return pm.getLaunchIntentForPackage(match.packageName)
    }
}

data class CommandResult(
    val response: String,
    val actionPerformed: Boolean = false,
    val pendingIntent: Intent? = null,
    val requestContactsPermission: Boolean = false,
    val requestCallPermission: Boolean = false,
    val requestCameraPermission: Boolean = false
)

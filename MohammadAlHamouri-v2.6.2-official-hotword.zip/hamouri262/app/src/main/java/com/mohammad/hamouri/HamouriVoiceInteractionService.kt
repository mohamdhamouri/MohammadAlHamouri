package com.mohammad.hamouri

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.voice.AlwaysOnHotwordDetector
import android.service.voice.VoiceInteractionService
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * System voice-interaction entry point.
 *
 * v2.6.2 first tries Android's official AlwaysOnHotwordDetector path. This
 * only becomes active when the device exposes an enrolled sound model for
 * the requested phrase/locale. On devices that do not support or enroll the
 * phrase, the existing software SpeechRecognizer service remains the fallback.
 */
class HamouriVoiceInteractionService : VoiceInteractionService() {
    private var hotwordDetector: AlwaysOnHotwordDetector? = null
    private var detectorReady = false

    private val hotwordCallback = object : AlwaysOnHotwordDetector.Callback() {
        override fun onAvailabilityChanged(status: Int) {
            detectorReady = status == AlwaysOnHotwordDetector.STATE_HARDWARE_ENROLLED
            if (!detectorReady) {
                // Software fallback is kept alive by the normal assistant path.
                startSoftwareFallbackIfAllowed()
            }
        }

        override fun onDetected(eventPayload: AlwaysOnHotwordDetector.EventPayload) {
            // Stop the DSP detector before opening a normal recognizer so the
            // two capture paths do not compete for the microphone.
            try { hotwordDetector?.stopRecognition() } catch (_: Exception) {}
            requestOneShotCommand()
            // Re-enable the detector after the command window has had time to
            // finish. If it cannot be restarted, software fallback remains.
            android.os.Handler(mainLooper).postDelayed({ restartDetector() }, 7000)
        }

        override fun onError() {
            detectorReady = false
            startSoftwareFallbackIfAllowed()
        }

        override fun onRecognitionPaused() {}
        override fun onRecognitionResumed() {}
    }

    override fun onReady() {
        super.onReady()
        startOfficialHotwordPath()
        startSoftwareFallbackIfAllowed()
    }

    override fun onShutdown() {
        try { hotwordDetector?.destroy() } catch (_: Exception) {}
        hotwordDetector = null
        detectorReady = false
        stopService(Intent(this, HamouriHotwordService::class.java))
        super.onShutdown()
    }

    private fun startOfficialHotwordPath() {
        if (android.os.Build.VERSION.SDK_INT < 31) return
        try {
            val executor = ContextCompat.getMainExecutor(this)
            hotwordDetector?.destroy()
            hotwordDetector = createAlwaysOnHotwordDetector(
                "يا حموري",
                Locale("ar", "JO"),
                executor,
                hotwordCallback
            )
        } catch (_: Throwable) {
            detectorReady = false
        }
    }

    private fun restartDetector() {
        if (isDestroyedCompat()) return
        if (!detectorReady) startOfficialHotwordPath()
        try { hotwordDetector?.startRecognition(AlwaysOnHotwordDetector.RECOGNITION_FLAG_NONE) } catch (_: Throwable) {
            startOfficialHotwordPath()
        }
    }

    private fun requestOneShotCommand() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, HamouriHotwordService::class.java)
                    .setAction(HamouriHotwordService.ACTION_LISTEN_COMMAND)
            )
        } catch (_: Exception) {
            startSoftwareFallbackIfAllowed()
        }
    }

    private fun startSoftwareFallbackIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, HamouriHotwordService::class.java))
        } catch (_: Exception) {}
    }

    private fun isDestroyedCompat(): Boolean = false
}

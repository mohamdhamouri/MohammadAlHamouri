package com.mohammad.hamouri.assistant

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * RecognitionService exposed to Android's voice-interaction stack.
 * It delegates recognition to another installed recognition engine (normally
 * the phone's Google/Android speech service) instead of recursively calling itself.
 */
class HamouriRecognitionService : RecognitionService() {
    private var recognizer: SpeechRecognizer? = null
    private var callback: Callback? = null

    override fun onStartListening(recognizerIntent: Intent, callback: Callback) {
        this.callback = callback
        val component = findExternalRecognitionService() ?: run {
            callback.error(SpeechRecognizer.ERROR_RECOGNIZER_BUSY)
            return
        }

        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this, component)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = callback.readyForSpeech(params)
                override fun onBeginningOfSpeech() = callback.beginningOfSpeech()
                override fun onRmsChanged(rmsdB: Float) = callback.rmsChanged(rmsdB)
                override fun onBufferReceived(buffer: ByteArray?) { callback.bufferReceived(buffer) }
                override fun onEndOfSpeech() = callback.endOfSpeech()
                override fun onError(error: Int) = finish { callback.error(error) }
                override fun onResults(results: Bundle?) = finish { callback.results(results) }
                override fun onPartialResults(partialResults: Bundle?) = callback.partialResults(partialResults)
                override fun onEvent(eventType: Int, params: Bundle?) = callback.event(eventType, params)
            })
            r.startListening(recognizerIntent)
        } catch (_: Exception) {
            callback.error(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    override fun onCancel(callback: Callback) {
        stopRecognizer()
        this.callback = null
    }

    override fun onStopListening(callback: Callback) {
        try { recognizer?.stopListening() } catch (_: Exception) { }
    }

    override fun onDestroy() {
        stopRecognizer()
        super.onDestroy()
    }

    private fun finish(block: () -> Unit) {
        try { block() } finally {
            stopRecognizer()
            callback = null
        }
    }

    private fun stopRecognizer() {
        try { recognizer?.cancel() } catch (_: Exception) { }
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
    }

    private fun findExternalRecognitionService(): ComponentName? {
        val intent = Intent("android.speech.RecognitionService")
        val services = packageManager.queryIntentServices(intent, PackageManager.MATCH_ALL)
        return services
            .map { it.serviceInfo }
            .firstOrNull { it.packageName != packageName }
            ?.let { ComponentName(it.packageName, it.name) }
    }
}

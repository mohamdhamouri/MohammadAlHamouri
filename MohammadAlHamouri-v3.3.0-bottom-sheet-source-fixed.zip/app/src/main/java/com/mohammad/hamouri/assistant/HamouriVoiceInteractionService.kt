package com.mohammad.hamouri.assistant

import android.service.voice.VoiceInteractionService
import android.util.Log

class HamouriVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.i("HamouriAssistant", "Voice interaction service ready")
    }

    override fun onShutdown() {
        Log.i("HamouriAssistant", "Voice interaction service shutting down")
        super.onShutdown()
    }
}

# محمد الحموري 3.2.2 — فحص خدمة التعرف الصوتي

- إضافة `<queries>` لخدمة `android.speech.RecognitionService` لمعالجة قيود ظهور الحزم في Android 11 وما بعده.
- إذا تعذر بدء SpeechRecognizer، يعرض التطبيق هل يستطيع Android اكتشاف مزود خدمة التعرف الصوتي.
- إضافة اختصار إلى إعدادات خدمة/إدخال الصوت.
- الإبقاء على مسار VoiceInteractionService الحالي دون استخدام واجهات نظام مخفية.

ارفع محتويات هذا المشروع إلى مستودع GitHub وشغّل Actions لبناء APK.


## 3.2.5 assistant registration-only patch
This release adds the Android RecognitionService declaration and voice-interaction XML reference to improve visibility in Android assistant selection. MainActivity.kt and all internal microphone UI/recognition code are preserved byte-for-byte from 3.2.2. The added RecognitionService does not acquire or use the microphone.


## الإصدار 3.2.6 — تشخيص استدعاء المساعد
- تسجيل أحداث خدمة المساعد والجلسة في Logcat تحت الوسم `HamouriAssistant`.
- إظهار واجهة احتياطية عند استدعاء جلسة المساعد، وتسجيل أي استثناء عند تعذر فتح `MainActivity`.
- تصحيح صلاحية ربط خدمة التعرف الصوتي إلى `BIND_SPEECH_RECOGNITION`.
- تم تحديث رقم الإصدار إلى 3.2.6. لم يتم تأكيد البناء أو الاختبار على جهاز فعلي ضمن هذه الحزمة.


## الإصدار 3.2.8 — تشخيص مرئي لاستدعاء المساعد
- إضافة رسائل Toast مؤقتة عند جاهزية VoiceInteractionService، وإنشاء جلسة المساعد، واستدعاء onShow.
- الهدف هو تحديد ما إذا كان Android يصل إلى الخدمة والجلسة عند الضغط على زر المساعد.
- هذا إصدار تشخيصي؛ لم يُبنَ أو يُختبر على جهاز فعلي بعد.


## الإصدار 3.2.8
تم تحديث أسماء الخدمات في `voice_interaction_service.xml` إلى أسماء الفئات الكاملة (`com.mohammad.hamouri...`) لتجنب فشل تحليل أسماء مكونات الجلسة وخدمة التعرف الصوتي. هذا إصلاح مرشح يحتاج إلى بناء APK واختباره على الجهاز؛ ولا يثبت وحده أن كل قيود جهاز Infinix قد حُلّت.

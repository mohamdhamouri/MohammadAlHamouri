package com.mohammad.hamouri

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Locale

class CommandRouter(private val context: Context) {
    fun execute(raw: String): CommandResult {
        val clean = normalize(raw)
        if (clean.isBlank()) return CommandResult("لم أسمع أمرًا واضحًا.", true)

        when {
            clean.contains("اقفل الشاشة") || clean.contains("أقفل الشاشة") || clean.contains("قفل الشاشة") ||
            clean.contains("اقفل الهاتف") || clean.contains("أقفل الهاتف") -> return lockScreen()
            clean.contains("افتح الشاشة") || clean.contains("أفتح الشاشة") || clean.contains("شغل الشاشة") ||
            clean.contains("شغّل الشاشة") || clean.contains("نبه الشاشة") -> return wakeScreen()
            clean.contains("شغل الكشاف") || clean.contains("شغّل الكشاف") || clean.contains("افتح الكشاف") ||
            clean.contains("شغل الفلاش") || clean.contains("شغّل الفلاش") || clean.contains("افتح الفلاش") -> return setTorch(true)
            clean.contains("طفي الكشاف") || clean.contains("طفئ الكشاف") || clean.contains("اطفئ الكشاف") ||
            clean.contains("أطفئ الكشاف") || clean.contains("طفي الفلاش") || clean.contains("أطفئ الفلاش") -> return setTorch(false)
            clean.contains("ارفع الصوت") || clean.contains("علي الصوت") || clean.contains("عل الصوت") -> return adjustVolume(AudioManager.ADJUST_RAISE)
            clean.contains("اخفض الصوت") || clean.contains("وطي الصوت") || clean.contains("وطّي الصوت") -> return adjustVolume(AudioManager.ADJUST_LOWER)
            clean.contains("كتم الصوت") || clean.contains("اكتم الصوت") -> return adjustVolume(AudioManager.ADJUST_MUTE)
            clean.contains("افتح الاعدادات") || clean.contains("افتح الإعدادات") ->
                return launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
            clean.contains("افتح الواي فاي") || clean.contains("افتح wifi") ->
                return launch(Intent(Settings.ACTION_WIFI_SETTINGS), "فتحت إعدادات الواي فاي.")
            clean.contains("افتح البلوتوث") || clean.contains("افتح bluetooth") ->
                return launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "فتحت إعدادات البلوتوث.")
            clean.contains("افتح بيانات الهاتف") || clean.contains("افتح بيانات الجوال") ->
                return launch(Intent(Settings.ACTION_WIRELESS_SETTINGS), "فتحت إعدادات الشبكة.")
            clean.contains("افتح الكاميرا") || clean.contains("شغل الكاميرا") || clean.contains("شغّل الكاميرا") ->
                return launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
            clean.contains("افتح الهاتف") || clean.contains("افتح الاتصال") || clean.contains("افتح الاتصالات") ->
                return launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        }

        val callMatch = Regex("(?:اتصل|اتصلي)\\s*(?:بـ|ب|بالرقم)?\\s*(.+)").find(raw)
        if (callMatch != null) {
            val target = callMatch.groupValues[1].trim().trim('.', '،', ',')
            val number = Regex("[+0-9][+0-9()\\- ]{4,}").find(target)?.value?.trim()
            if (!number.isNullOrBlank()) return dial(number)
            return dialContact(target)
        }

        val appName = Regex("(?:افتح|شغل|شغّل)\\s+(.+)").find(raw)?.groupValues?.get(1)?.trim()
        if (!appName.isNullOrBlank()) {
            val intent = findLaunchIntent(appName)
            if (intent != null) return launch(intent, "حسنًا، فتحت $appName.")
        }
        return CommandResult("", false)
    }

    private fun lockScreen(): CommandResult {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, HamouriDeviceAdminReceiver::class.java)
        if (!dpm.isAdminActive(admin)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "يسمح هذا الإذن لحموري بقفل الشاشة عند قولك: يا حموري اقفل الشاشة.")
            }
            return CommandResult("لأتمكن من قفل الشاشة تلقائيًا، فعّل صلاحية إدارة الجهاز مرة واحدة.", true, intent)
        }
        return try {
            dpm.lockNow()
            CommandResult("تم قفل الشاشة.", true)
        } catch (_: Exception) {
            CommandResult("تعذر قفل الشاشة على جهازك.", true)
        }
    }

    private fun wakeScreen(): CommandResult = try {
        val intent = Intent(context, HamouriWakeActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or
            Intent.FLAG_ACTIVITY_CLEAR_TOP
        )
        context.startActivity(intent)
        CommandResult("حسنًا، أيقظت الشاشة. إذا كان عليها PIN أو نمط أو كلمة مرور فلن أتجاوز قفل الأمان.", true)
    } catch (_: Exception) {
        CommandResult("تعذر إيقاظ الشاشة تلقائيًا على جهازك.", true)
    }

    private fun setTorch(on: Boolean): CommandResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult(
                if (on) "أحتاج إذن الكاميرا لتشغيل الكشاف." else "أحتاج إذن الكاميرا لإطفاء الكشاف.",
                true,
                requestCameraPermission = true
            )
        }
        val manager = context.getSystemService(CameraManager::class.java)
        return try {
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) CommandResult("هذا الجهاز لا يوفّر كشافًا يمكن التحكم به.", true)
            else {
                manager.setTorchMode(cameraId, on)
                CommandResult(if (on) "تم تشغيل الكشاف." else "تم إطفاء الكشاف.", true)
            }
        } catch (_: Exception) {
            CommandResult("تعذر التحكم بالكشاف على جهازك.", true)
        }
    }

    private fun adjustVolume(direction: Int): CommandResult = try {
        val audio = context.getSystemService(AudioManager::class.java)
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        val msg = when (direction) {
            AudioManager.ADJUST_RAISE -> "رفعت الصوت."
            AudioManager.ADJUST_LOWER -> "خفضت الصوت."
            else -> "تم كتم الصوت."
        }
        CommandResult(msg, true)
    } catch (_: Exception) { CommandResult("تعذر التحكم بالصوت.", true) }

    private fun dialContact(target: String): CommandResult {
        if (target.isBlank()) return CommandResult("اذكر اسم جهة الاتصال التي تريد الاتصال بها.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult("أحتاج إذن جهات الاتصال لأبحث عن \"$target\" وأتصل به.", true, requestContactsPermission = true)
        }
        val number = findContactNumber(target)
        return if (number != null) dial(number) else CommandResult("لم أجد جهة اتصال باسم $target. تأكد من اسمها في جهات الاتصال.", true)
    }

    private fun findContactNumber(target: String): String? {
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, selection, arrayOf("%$target%"), null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        val aliases = when (normalize(target).replace(" ", "")) {
            "ماما", "امي", "أمي", "الوالدة" -> listOf("ماما", "أمي", "امي", "الوالدة", "والدتي")
            "بابا", "ابي", "أبي", "الوالد" -> listOf("بابا", "أبي", "ابي", "الوالد", "والدي")
            else -> emptyList()
        }
        for (alias in aliases) {
            context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, selection, arrayOf("%$alias%"), null)?.use { cursor ->
                if (cursor.moveToFirst()) return cursor.getString(0)
            }
        }
        return null
    }

    fun executeTool(call: AiToolCall): CommandResult = when (call.name) {
        "open_settings" -> launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
        "open_camera" -> launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
        "open_dialer" -> launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        "dial_number" -> dial(call.arguments.optString("number"))
        "open_app" -> {
            val name = call.arguments.optString("name").trim()
            val intent = findLaunchIntent(name)
            if (intent != null) launch(intent, "حسنًا، فتحت $name.") else CommandResult("لم أجد تطبيقًا باسم $name.", true)
        }
        "lock_screen" -> lockScreen()
        "wake_screen" -> wakeScreen()
        "torch_on" -> setTorch(true)
        "torch_off" -> setTorch(false)
        else -> CommandResult("الأداة المطلوبة غير متاحة على هذا الإصدار.", true)
    }

    private fun dial(number: String): CommandResult {
        if (number.isBlank()) return CommandResult("لم أجد رقمًا صالحًا للاتصال.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult("أحتاج إذن المكالمات لأتصل بهذا الرقم تلقائيًا.", true, requestCallPermission = true)
        }
        return CommandResult("حسنًا، سأتصل الآن.", true, Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
    }

    private fun normalize(value: String): String = HamouriWakePhrase.strip(value).lowercase(Locale("ar"))

    private fun launch(intent: Intent, message: String): CommandResult = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CommandResult(message, true)
    } catch (_: Exception) { CommandResult("تعذر تنفيذ هذا الإجراء على جهازك.", true) }

    private fun findLaunchIntent(requested: String): Intent? {
        val pm = context.packageManager
        val normalized = requested.lowercase(Locale("ar")).replace(" ", "")
        val aliases = mapOf("واتس" to "واتساب", "واتساب" to "whatsapp", "يوتيوب" to "youtube", "فيسبوك" to "facebook")
        val candidates = listOf(normalized) + (aliases[normalized]?.let { listOf(it.lowercase(Locale("ar"))) } ?: emptyList())
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase(Locale("ar")).replace(" ", "")
            candidates.any { it == label || label.contains(it) || it.contains(label) }
        } ?: return null
        return pm.getLaunchIntentForPackage(match.packageName)
    }
}

data class CommandResult(
    val response: String,
    val actionPerformed: Boolean = false,
    val pendingIntent: Intent? = null,
    val requestContactsPermission: Boolean = false,
    val requestCallPermission: Boolean = false,
    val requestCameraPermission: Boolean = false
)

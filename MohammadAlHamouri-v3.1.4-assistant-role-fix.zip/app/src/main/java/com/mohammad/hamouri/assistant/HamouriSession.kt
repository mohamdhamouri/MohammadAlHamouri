package com.mohammad.hamouri.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.service.voice.VoiceInteractionSession

/** Lightweight assistant-button session. Android owns the session; recognition is
 * supplied by the RecognitionService declared in voice_interaction_service.xml. */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        // Ask the system voice-interaction pipeline to start listening. The actual
        // recognition engine is declared separately as HamouriRecognitionService.
        try {
            val listenIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            // showSession is already active; no SpeechRecognizer is created here
            // to avoid competing for the microphone with the system pipeline.
        } catch (_: Exception) { }
    }
}

package com.mohammad.hamouri

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HamouriApp(this) }
    }
}

@Composable
private fun HamouriApp(context: Context) {
    val prefs = remember { HamouriPreferences(context) }
    var messages by remember { mutableStateOf(listOf("محمد الحموري: مرحبًا! أنا محمد الحموري، مساعدك الرقمي الخاص. يمكنك سؤالي أو إنشاء صورة أو تعديل صورة.")) }
    var listening by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var imagePrompt by remember { mutableStateOf("") }
    var editPrompt by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf(prefs.aiEndpoint) }
    var showSettings by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }
    var generatedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var selectedImage by remember { mutableStateOf<ByteArray?>(null) }
    var selectedMime by remember { mutableStateOf("image/png") }

    val tts = remember { TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }.also { it.language = Locale("ar") } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listening = true }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { selectedImage = it.readBytes() }
            selectedMime = context.contentResolver.getType(uri) ?: "image/png"
            messages = messages + "محمد الحموري: تم اختيار الصورة. اكتب كيف تريد تعديلها."
        }
    }

    fun speak(text: String) { if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hamouri") }

    fun answer(text: String) {
        val clean = HamouriWakePhrase.strip(text)
        if (clean.isBlank()) return
        messages = messages + "أنت: $text"
        val router = CommandRouter(context)
        val response = router.execute(clean)
        if (response.actionPerformed) {
            messages = messages + "محمد الحموري: ${response.response}"; speak(response.response)
            response.pendingIntent?.let { context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            return
        }
        if (prefs.aiEndpoint.isBlank()) {
            val r = "لإجابات الذكاء الاصطناعي، افتح ⚙ الإعدادات وأضف رابط خادم الذكاء الاصطناعي."
            messages = messages + "محمد الحموري: $r"; speak(r); return
        }
        busy = true
        HamouriAiClient(prefs.aiEndpoint).ask(clean) { result ->
            busy = false
            result.onSuccess { ai ->
                var textResponse = ai.text.ifBlank { "سأنفذ الطلب." }
                for (tool in ai.toolCalls) {
                    val action = router.executeTool(tool)
                    if (action.response.isNotBlank()) textResponse = action.response
                    action.pendingIntent?.let { pending -> try { context.startActivity(pending.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
                }
                messages = messages + "محمد الحموري: $textResponse"; speak(textResponse)
            }.onFailure { error ->
                val r = "تعذر الاتصال بخادم الذكاء الاصطناعي: ${error.message ?: "خطأ غير معروف"}"
                messages = messages + "محمد الحموري: $r"; speak(r)
            }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { answer(it) }
        listening = false
    }
    fun listen() {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO); return }
        speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث إلى محمد الحموري")
        })
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("محمد الحموري") }, actions = { TextButton(onClick = { showSettings = true }) { Text("⚙") } }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("مساعدك الرقمي الخاص", style = MaterialTheme.typography.headlineSmall)
                Text(if (busy) "محمد الحموري يعمل…" else "اسألني، أعطني أمرًا صوتيًا، أو أنشئ صورة.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    val roleManager = context.getSystemService(RoleManager::class.java)
                    if (roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT) && !roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)) context.startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT))
                }, modifier = Modifier.fillMaxWidth()) { Text("اجعل محمد الحموري المساعد الافتراضي") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) { items(messages) { Text(it, Modifier.fillMaxWidth().padding(6.dp)) } }

                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), placeholder = { Text("اكتب لمحمد الحموري…") }, singleLine = true)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(enabled = input.isNotBlank() && !busy, onClick = { val x=input; input=""; answer(x) }, Modifier.weight(1f)) { Text("إرسال") }
                    Button(onClick = ::listen, Modifier.weight(1f), enabled = !busy) { Text(if (listening) "🎙 يستمع…" else "🎙 صوت") }
                }
                Spacer(Modifier.height(10.dp))

                Text("🖼️ إنشاء صورة", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(imagePrompt, { imagePrompt = it }, Modifier.fillMaxWidth(), placeholder = { Text("مثال: مدينة عربية مستقبلية عند الغروب") }, singleLine = true)
                Button(enabled = imagePrompt.isNotBlank() && !busy && prefs.aiEndpoint.isNotBlank(), onClick = {
                    busy = true
                    HamouriImageClient(prefs.aiEndpoint).generate(imagePrompt) { result ->
                        busy = false
                        result.onSuccess { generatedBitmap = BitmapFactory.decodeByteArray(it.bytes, 0, it.bytes.size); messages = messages + "محمد الحموري: تم إنشاء الصورة."; speak("تم إنشاء الصورة") }
                            .onFailure { messages = messages + "محمد الحموري: تعذر إنشاء الصورة: ${it.message}" }
                    }
                }, Modifier.fillMaxWidth()) { Text("إنشاء") }

                if (generatedBitmap != null) { Spacer(Modifier.height(8.dp)); Image(generatedBitmap!!.asImageBitmap(), "الصورة الناتجة", Modifier.fillMaxWidth().heightIn(max = 280.dp)) }

                Spacer(Modifier.height(10.dp))
                Text("✏️ تعديل صورة", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { imagePicker.launch("image/*") }, Modifier.fillMaxWidth()) { Text(if (selectedImage == null) "اختيار صورة" else "تم اختيار صورة — اختر أخرى") }
                OutlinedTextField(editPrompt, { editPrompt = it }, Modifier.fillMaxWidth(), placeholder = { Text("مثال: أزل الخلفية واجعلها بيضاء") }, singleLine = true)
                Button(enabled = selectedImage != null && editPrompt.isNotBlank() && !busy && prefs.aiEndpoint.isNotBlank(), onClick = {
                    busy = true
                    HamouriImageClient(prefs.aiEndpoint).edit(editPrompt, selectedImage!!, selectedMime) { result ->
                        busy = false
                        result.onSuccess { generatedBitmap = BitmapFactory.decodeByteArray(it.bytes, 0, it.bytes.size); messages = messages + "محمد الحموري: تم تعديل الصورة."; speak("تم تعديل الصورة") }
                            .onFailure { messages = messages + "محمد الحموري: تعذر تعديل الصورة: ${it.message}" }
                    }
                }, Modifier.fillMaxWidth()) { Text("تعديل") }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات الذكاء الاصطناعي") },
            text = { Column { Text("رابط خادم AI Gateway") ; Spacer(Modifier.height(8.dp)); OutlinedTextField(endpoint, { endpoint=it }, Modifier.fillMaxWidth(), placeholder={Text("https://example.com")}, singleLine=true); Spacer(Modifier.height(8.dp)); Text("لا تضع مفتاح API داخل تطبيق Android.", style=MaterialTheme.typography.bodySmall) } },
            confirmButton = { TextButton(onClick={prefs.aiEndpoint=endpoint; showSettings=false}){Text("حفظ")} },
            dismissButton = { TextButton(onClick={showSettings=false}){Text("إلغاء")} }
        )
    }
}

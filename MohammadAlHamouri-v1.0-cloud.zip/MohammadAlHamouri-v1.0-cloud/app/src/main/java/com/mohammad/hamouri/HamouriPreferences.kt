package com.mohammad.hamouri

import android.content.Context

class HamouriPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hamouri", Context.MODE_PRIVATE)

    var aiEndpoint: String
        get() = prefs.getString("ai_endpoint", "") ?: ""
        set(value) { prefs.edit().putString("ai_endpoint", value.trim()).apply() }
}

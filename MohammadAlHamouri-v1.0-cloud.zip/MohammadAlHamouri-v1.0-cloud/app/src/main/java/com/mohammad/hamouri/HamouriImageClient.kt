package com.mohammad.hamouri

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.Executors

class HamouriImageClient(private val baseEndpoint: String) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun post(path: String, body: JSONObject, callback: (Result<ImageResult>) -> Unit) {
        executor.execute {
            try {
                val endpoint = baseEndpoint.trimEnd('/') + path
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 180_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
                connection.disconnect()
                if (status !in 200..299) throw IllegalStateException("خادم الصور أعاد HTTP $status: $response")
                val json = JSONObject(response)
                val b64 = json.optString("image_base64")
                if (b64.isBlank()) throw IllegalStateException("لم تصل صورة من الخادم")
                main.post { callback(Result.success(ImageResult(Base64.getDecoder().decode(b64), json.optString("mime_type", "image/png")))) }
            } catch (t: Throwable) {
                main.post { callback(Result.failure(t)) }
            }
        }
    }

    fun generate(prompt: String, callback: (Result<ImageResult>) -> Unit) =
        post("/v1/images/generate", JSONObject().put("prompt", prompt), callback)

    fun edit(prompt: String, imageBytes: ByteArray, mimeType: String, callback: (Result<ImageResult>) -> Unit) =
        post("/v1/images/edit", JSONObject()
            .put("prompt", prompt)
            .put("image_base64", Base64.getEncoder().encodeToString(imageBytes))
            .put("mime_type", mimeType), callback)
}

data class ImageResult(val bytes: ByteArray, val mimeType: String)

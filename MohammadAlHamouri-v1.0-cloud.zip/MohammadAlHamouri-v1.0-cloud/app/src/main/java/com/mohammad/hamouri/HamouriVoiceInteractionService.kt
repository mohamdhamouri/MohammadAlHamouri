package com.mohammad.hamouri

import android.os.Bundle
import android.service.voice.VoiceInteractionService

/** Lightweight system assistant service. Heavy UI/work belongs to the session. */
class HamouriVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        // Keep the service lightweight; Android starts the session when the assistant is invoked.
        setInvocationEffectEnabled(true)
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}

package com.mohammad.hamouri

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity:ComponentActivity(){
    private val incomingVoiceText = mutableStateOf<String?>(null)
    private val incomingContactsPermission = mutableStateOf(false)
    private val incomingCallsPermission = mutableStateOf(false)

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        handleIncomingIntent(intent)
        setContent{HamouriApp(this, incomingVoiceText, incomingContactsPermission, incomingCallsPermission)}
    }

    override fun onNewIntent(intent:Intent){
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent:Intent?){
        incomingVoiceText.value = intent?.getStringExtra(EXTRA_VOICE_TEXT)
        incomingContactsPermission.value = intent?.getBooleanExtra(EXTRA_PERMISSION_CONTACTS, false) == true
        incomingCallsPermission.value = intent?.getBooleanExtra(EXTRA_PERMISSION_CALLS, false) == true
    }

    companion object {
        const val EXTRA_VOICE_TEXT = "hamouri_voice_text"
        const val EXTRA_PERMISSION_CONTACTS = "hamouri_permission_contacts"
        const val EXTRA_PERMISSION_CALLS = "hamouri_permission_calls"
    }
}
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable private fun HamouriApp(context:Context, incomingVoiceText: androidx.compose.runtime.MutableState<String?>, incomingContactsPermission: androidx.compose.runtime.MutableState<Boolean>, incomingCallsPermission: androidx.compose.runtime.MutableState<Boolean>){
 val prefs=remember{HamouriPreferences(context)}; val router=remember{CommandRouter(context)}; var key by remember{mutableStateOf(prefs.apiKey)}; var show by remember{mutableStateOf(false)}; var input by remember{mutableStateOf("")}; var ip by remember{mutableStateOf("")}; var ep by remember{mutableStateOf("")}; var busy by remember{mutableStateOf(false)}; var img by remember{mutableStateOf<android.graphics.Bitmap?>(null)}; var selected by remember{mutableStateOf<ByteArray?>(null)}; var mime by remember{mutableStateOf("image/png")}; var messages by remember{mutableStateOf(listOf("محمد الحموري: مرحبًا! أدخل مفتاح Gemini من ⚙ ثم ابدأ بالسؤال."))}; var ttsReady by remember{mutableStateOf(false)}
 val tts=remember{TextToSpeech(context){s->ttsReady=s==TextToSpeech.SUCCESS}}; DisposableEffect(Unit){onDispose{tts.shutdown()}}
 fun speak(s:String){if(ttsReady){tts.language=Locale("ar");tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"hamouri")}}
 fun startHotwordService(){
  if(ContextCompat.checkSelfPermission(context,android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){
    try{ContextCompat.startForegroundService(context,Intent(context,HamouriHotwordService::class.java))}catch(_:Exception){}
  }
}
val perm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->
  if(granted){
    startHotwordService()
    messages=messages+"محمد الحموري: تم تفعيل الاستماع لعبارة «يا حموري»."
  }
}
val contactPerm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->
  if(granted) messages=messages+"محمد الحموري: تم السماح بجهات الاتصال. أعد قول الأمر."
  else messages=messages+"محمد الحموري: لم يتم منح إذن جهات الاتصال."
}
val callPerm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->
  if(granted) messages=messages+"محمد الحموري: تم السماح بالمكالمات. أعد قول الأمر لأتصل تلقائيًا."
  else messages=messages+"محمد الحموري: لم يتم منح إذن المكالمات."
}
 fun ask(s:String){
  if(s.isBlank()||busy)return
  messages=messages+"أنت: $s"
  val command=router.execute(s)
  if(command.response.isNotBlank()||command.pendingIntent!=null){
   command.pendingIntent?.let{try{context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}catch(_:Exception){}}
   messages=messages+"محمد الحموري: ${command.response}"
   speak(command.response)
   if(command.requestContactsPermission) contactPerm.launch(android.Manifest.permission.READ_CONTACTS)
   if(command.requestCallPermission) callPerm.launch(android.Manifest.permission.CALL_PHONE)
   return
  }
  if(prefs.apiKey.isBlank()){show=true;return}
  busy=true
  HamouriGeminiClient(prefs.apiKey).ask(s){r->busy=false;r.onSuccess{messages=messages+"محمد الحموري: $it";speak(it)}.onFailure{messages=messages+"محمد الحموري: خطأ — ${it.message}"}}}
 LaunchedEffect(incomingVoiceText.value){
  val text=incomingVoiceText.value
  if(text!=null){
    incomingVoiceText.value=null
    when {
      incomingContactsPermission.value && ContextCompat.checkSelfPermission(context,android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED -> contactPerm.launch(android.Manifest.permission.READ_CONTACTS)
      incomingCallsPermission.value && ContextCompat.checkSelfPermission(context,android.Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED -> callPerm.launch(android.Manifest.permission.CALL_PHONE)
      else -> ask(text)
    }
  }
}
 val speech=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{ask(it)}}; val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u:Uri?->if(u!=null){context.contentResolver.openInputStream(u)?.use{selected=it.readBytes()};mime=context.contentResolver.getType(u) ?: "image/png";messages=messages+"محمد الحموري: تم اختيار الصورة."}}

 fun listen(){if(ContextCompat.checkSelfPermission(context,android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){perm.launch(android.Manifest.permission.RECORD_AUDIO);return};speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-JO");putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_PROMPT,"تحدث إلى محمد الحموري")})}
 MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("محمد الحموري")},actions={TextButton(onClick={show=true}){Text("⚙")}})}){pad->Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("مساعدك الرقمي الخاص",style=MaterialTheme.typography.headlineSmall);Text(if(busy)"محمد الحموري يعمل…" else "دردشة • صوت • إنشاء وتعديل الصور");Spacer(Modifier.height(7.dp));Button({val rm=context.getSystemService(RoleManager::class.java);if(rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT))context.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT))else messages=messages+"محمد الحموري: دور المساعد غير متاح على هذا الجهاز."},Modifier.fillMaxWidth()){Text("اجعل محمد الحموري المساعد الافتراضي")};LazyColumn(Modifier.weight(1f)){items(messages){Text(it,Modifier.padding(5.dp))}};OutlinedTextField(input,{input=it},Modifier.fillMaxWidth(),placeholder={Text("اكتب سؤالك…")},singleLine=true);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){Button({val s=input;input="";ask(s)},Modifier.weight(1f),enabled=input.isNotBlank()&&!busy){Text("إرسال")};Button(::listen,Modifier.weight(1f),enabled=!busy){Text("🎙 صوت")}};Spacer(Modifier.height(7.dp));Text("🖼️ إنشاء صورة",style=MaterialTheme.typography.titleMedium);OutlinedTextField(ip,{ip=it},Modifier.fillMaxWidth(),placeholder={Text("مثال: مدينة عربية مستقبلية عند الغروب")},singleLine=true);Button({busy=true;HamouriImageClient(prefs.apiKey).generate(ip){r->busy=false;r.onSuccess{img=BitmapFactory.decodeByteArray(it.bytes,0,it.bytes.size);messages=messages+"محمد الحموري: تم إنشاء الصورة."}.onFailure{messages=messages+"محمد الحموري: تعذر إنشاء الصورة — ${it.message}"}}},Modifier.fillMaxWidth(),enabled=ip.isNotBlank()&&!busy&&prefs.apiKey.isNotBlank()){Text("إنشاء")};img?.let{Image(it.asImageBitmap(),"الناتجة",Modifier.fillMaxWidth().heightIn(max=280.dp))};Spacer(Modifier.height(7.dp));Text("✏️ تعديل صورة",style=MaterialTheme.typography.titleMedium);Button({picker.launch("image/*")},Modifier.fillMaxWidth()){Text("اختيار صورة")};OutlinedTextField(ep,{ep=it},Modifier.fillMaxWidth(),placeholder={Text("مثال: غيّر الخلفية إلى شاطئ")},singleLine=true);Button({busy=true;HamouriImageClient(prefs.apiKey).edit(ep,selected!!,mime){r->busy=false;r.onSuccess{img=BitmapFactory.decodeByteArray(it.bytes,0,it.bytes.size);messages=messages+"محمد الحموري: تم تعديل الصورة."}.onFailure{messages=messages+"محمد الحموري: تعذر تعديل الصورة — ${it.message}"}}},Modifier.fillMaxWidth(),enabled=selected!=null&&ep.isNotBlank()&&!busy&&prefs.apiKey.isNotBlank()){Text("تعديل")}}};if(show)AlertDialog(onDismissRequest={show=false},title={Text("إعدادات Gemini")},text={Column{Text("Gemini API Key");OutlinedTextField(value=key,onValueChange={key=it},modifier=Modifier.fillMaxWidth(),singleLine=true);Spacer(Modifier.height(6.dp));Text("احفظ المفتاح على هاتفك فقط ولا تنشره في GitHub.")}},confirmButton={TextButton(onClick={prefs.apiKey=key;show=false}){Text("حفظ")}},dismissButton={TextButton(onClick={show=false}){Text("إلغاء")}})}}

package com.mohammad.hamouri

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.service.voice.VoiceInteractionService
import androidx.core.content.ContextCompat

class HamouriVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        startHotwordListenerIfAllowed()
    }

    override fun onShutdown() {
        stopService(Intent(this, HamouriHotwordService::class.java))
        super.onShutdown()
    }

    private fun startHotwordListenerIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, HamouriHotwordService::class.java))
        } catch (_: Exception) {
            // The visible app can start it again after the user grants microphone permission.
        }
    }
}

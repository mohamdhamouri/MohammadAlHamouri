# بناء محمد الحموري 3.0.5 من الهاتف

1. ارفع محتويات المشروع إلى GitHub.
2. افتح Actions ثم Build APKs ثم Run workflow.
3. بعد نجاح البناء افتح Artifacts.
4. حمّل `MohammadAlHamouri-v3.0.5-APKs`.
5. داخل الملف المضغوط ستجد ملفين واضحين:
   - `MohammadAlHamouri-App.apk` — التطبيق الظاهر.
   - `MohammadAlHamouri-Core.apk` — نواة المساعد، ويجب تثبيتها أيضًا.
6. ثبّت Core أولًا ثم App.

package com.mohammad.hamouri

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.service.voice.VoiceInteractionSession
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Native Android assistant session.
 * When the system invokes Hamouri as the default assistant, this session
 * captures the spoken request and sends it through the same CommandRouter
 * used by the wake-phrase service and the app UI.
 */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var handled = false

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (!handled) finishWithMessage("لم أسمع الأمر بوضوح.")
        }
        override fun onResults(results: Bundle?) {
            if (handled) return
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            handleCommand(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        handled = false
        handler.postDelayed({ startListening() }, 250)
    }

    private fun startListening() {
        if (handled) return
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            openMainForPermission()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            finishWithMessage("التعرف على الصوت غير متاح على هذا الجهاز.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(listener) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            finishWithMessage("تعذر تشغيل الاستماع الصوتي.")
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) {
            finishWithMessage("نعم، أنا حموري. تفضل.")
            return
        }
        handled = true
        recognizer?.cancel()
        val result = CommandRouter(context).execute(command)
        result.pendingIntent?.let { pending ->
            try { context.startActivity(pending.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
        if (result.requestContactsPermission || result.requestCallPermission || result.requestCameraPermission) {
            openMainForPermission(
                result.requestContactsPermission,
                result.requestCallPermission,
                result.requestCameraPermission,
                command
            )
            hide()
            return
        }
        if (!result.actionPerformed && result.response.isBlank()) {
            openMainForText(command)
            hide()
            return
        }
        speakThenHide(if (result.response.isBlank()) "تم." else result.response)
    }

    private fun openMainForPermission(
        contacts: Boolean = false,
        calls: Boolean = false,
        camera: Boolean = false,
        command: String? = null
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_PERMISSION_CONTACTS, contacts)
            putExtra(MainActivity.EXTRA_PERMISSION_CALLS, calls)
            putExtra(MainActivity.EXTRA_PERMISSION_CAMERA, camera)
            if (!command.isNullOrBlank()) putExtra(MainActivity.EXTRA_VOICE_TEXT, command)
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
    }

    private fun openMainForText(text: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_VOICE_TEXT, text)
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
    }

    private fun speakThenHide(text: String) {
        val tts = TextToSpeech(context) { status ->
            if (status != TextToSpeech.SUCCESS) {
                hide()
                return@TextToSpeech
            }
            tts.language = Locale("ar")
            tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    tts.shutdown()
                    handler.post { hide() }
                }
                override fun onError(utteranceId: String?) {
                    tts.shutdown()
                    handler.post { hide() }
                }
            })
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hamouri-session")
        }
    }

    private fun finishWithMessage(message: String) {
        handled = true
        speakThenHide(message)
    }

    override fun onHide() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        handler.removeCallbacksAndMessages(null)
        super.onHide()
    }
}

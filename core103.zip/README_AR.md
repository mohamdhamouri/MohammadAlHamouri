# محمد الحموري Core — مشروع مستقل

هذا المشروع يحتوي **على تطبيق Core واحد فقط**:
`com.mohammad.hamouri.core`

وظيفته:
- Android VoiceInteractionService كمساعد رقمي.
- SessionService للمساعد.
- RecognitionService.
- نواة الاستماع البرمجي لعبارة «يا حموري» كحل برمجي، وليس DSP/SoundTrigger حقيقيًا بعد.
- Device Admin لقفل الشاشة.
- تهيئة الأذونات.

## التثبيت
1. شغّل GitHub Actions.
2. نزّل Artifact: `MohammadAlHamouri-Core-APK`.
3. داخله يوجد ملف واحد فقط: `MohammadAlHamouri-Core.apk`.
4. ثبّته.
5. افتح التطبيق مرة واحدة واسمح بالميكروفون.
6. اذهب إلى إعدادات تطبيق المساعد الرقمي واختر **محمد الحموري**.

> هذه النسخة مستقلة عن التطبيق الرئيسي. لا تحتاج إلى APK آخر لكي نختبر ظهورها كمساعد رقمي ومشرف جهاز.

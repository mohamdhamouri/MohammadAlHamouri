# بنية Core المستقل

هذه النسخة تفصل نواة المساعد في APK مستقل تمامًا عن واجهة محمد الحموري.

Application ID:
`com.mohammad.hamouri.core`

المرحلة الحالية تستخدم واجهات Android العامة:
VoiceInteractionService + SpeechRecognizer.

**ليست System/Privileged App حقيقية بعد**، ولا تحتوي حتى الآن على DSP SoundTrigger/AlwaysOnHotwordDetector الحقيقي؛ هذا سيكون مشروع المرحلة التالية بعد التأكد من أن Android يتعرف على Core كمساعد رقمي مستقل.

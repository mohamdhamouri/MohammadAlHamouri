# اختبار مؤقت — بدون جلسة «يا حموري»

هذا الإصدار يعطّل `HamouriHotwordService` مؤقتًا بالكامل، ولا يشغّل مستمع «يا حموري».

الهدف: اختبار زر المساعد/VoiceInteractionSession والميكروفون وحدهما.

بعد الاختبار يمكن إعادة تفعيل خدمة wake word. تعطيلها لا يلغي VoiceInteractionService ولا جلسة المساعد ولا CommandRouter.

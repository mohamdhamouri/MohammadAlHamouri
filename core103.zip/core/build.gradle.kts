plugins {
    id("com.android.application")
}

android {
    namespace = "com.mohammad.hamouri"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mohammad.hamouri.core"
        minSdk = 26
        targetSdk = 36
        versionCode = 6
        versionName = "1.0.9-session-diagnostic"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
}

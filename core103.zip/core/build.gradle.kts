plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mohammad.hamouri"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mohammad.hamouri.core"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0-core"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
}

package com.mohammad.hamouri

import android.content.Intent
import android.service.voice.VoiceInteractionService

/**
 * Global Android assistant entry point.
 *
 * Important: Android's AlwaysOnHotwordDetector and the corresponding
 * createAlwaysOnHotwordDetector() API are @SystemApi/hidden APIs and require
 * MANAGE_HOTWORD_DETECTION on current Android releases. They are not available
 * to an ordinary third-party APK, so referencing them directly makes a normal
 * Gradle build fail with "Unresolved reference".
 *
 * We therefore keep the supported public VoiceInteractionService path here and
 * use HamouriHotwordService as the software fallback for "يا حموري".
 */
class HamouriVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        // Temporary test build: software wake-word listener is disabled.
        // The assistant button/session is tested independently.
        super.onReady()
    }

    override fun onShutdown() {
        super.onShutdown()
    }

    override fun onLaunchVoiceAssistFromKeyguard() {
        // Let the normal VoiceInteractionSession handle the assistant invocation.
        super.onLaunchVoiceAssistFromKeyguard()
    }

}

package com.mohammad.hamouri

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.service.voice.VoiceInteractionService
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.lang.reflect.Modifier

/**
 * DSP / SoundTrigger experiment screen.
 *
 * This build deliberately does NOT pretend that an ordinary APK has the
 * privileged hotword APIs. It probes what the device exposes at runtime and
 * reports the exact result. The existing software hotword service is stopped
 * while this experiment is active to avoid microphone contention.
 */
class HamouriCoreSetupActivity : ComponentActivity() {
    private var pendingContacts = false
    private var pendingCalls = false
    private var pendingCamera = false
    private var pendingMicrophone = false
    private var pendingCommand: String = ""
    private lateinit var report: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { requestNext() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stopSoftwareHotword()

        report = TextView(this).apply {
            textSize = 16f
            setPadding(32, 24, 32, 24)
        }
        val title = TextView(this).apply {
            text = "محمد الحموري — اختبار DSP / SoundTrigger\n\nهذه نسخة تجريبية لمعرفة ما إذا كان الهاتف يوفّر واجهات الـ Hotword الحقيقية."
            textSize = 20f
            setPadding(32, 40, 32, 24)
        }
        val button = Button(this).apply {
            text = "فحص SoundTrigger و Hotword"
            setOnClickListener { runDspProbe() }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(button)
            addView(report)
        }
        setContentView(ScrollView(this).apply { addView(layout) })

        pendingContacts = intent.getBooleanExtra(EXTRA_CONTACTS, false)
        pendingCalls = intent.getBooleanExtra(EXTRA_CALLS, false)
        pendingCamera = intent.getBooleanExtra(EXTRA_CAMERA, false)
        pendingMicrophone = intent.getBooleanExtra(EXTRA_MICROPHONE, false)
        pendingCommand = intent.getStringExtra(EXTRA_COMMAND).orEmpty()
        requestNext()
    }

    private fun requestNext() {
        when {
            pendingMicrophone && !granted(Manifest.permission.RECORD_AUDIO) -> request(Manifest.permission.RECORD_AUDIO)
            pendingContacts && !granted(Manifest.permission.READ_CONTACTS) -> request(Manifest.permission.READ_CONTACTS)
            pendingCalls && !granted(Manifest.permission.CALL_PHONE) -> request(Manifest.permission.CALL_PHONE)
            pendingCamera && !granted(Manifest.permission.CAMERA) -> request(Manifest.permission.CAMERA)
            else -> {
                // Do not start the software hotword listener in the DSP test build.
                runDspProbe()
                if (pendingCommand.isNotBlank()) openUserAppWithCommand(pendingCommand)
            }
        }
    }

    private fun request(permission: String) {
        when (permission) {
            Manifest.permission.RECORD_AUDIO -> pendingMicrophone = false
            Manifest.permission.READ_CONTACTS -> pendingContacts = false
            Manifest.permission.CALL_PHONE -> pendingCalls = false
            Manifest.permission.CAMERA -> pendingCamera = false
        }
        permissionLauncher.launch(permission)
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun stopSoftwareHotword() {
        try { stopService(Intent(this, HamouriHotwordService::class.java)) } catch (_: Exception) {}
    }

    private fun runDspProbe() {
        val lines = mutableListOf<String>()
        lines += "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        lines += "\n[1] VoiceInteractionService"
        lines += "المساعد الحالي: ${VoiceInteractionService.isActiveService(this, android.content.ComponentName(this, HamouriVoiceInteractionService::class.java))}"

        lines += "\n[2] AlwaysOnHotwordDetector API"
        try {
            val methods = VoiceInteractionService::class.java.methods.filter {
                it.name == "createAlwaysOnHotwordDetector"
            }
            if (methods.isEmpty()) {
                lines += "❌ غير ظاهر في SDK/runtime الحالي."
            } else {
                lines += "✅ الدالة موجودة في runtime (${methods.size} overloads)."
                methods.forEach { m ->
                    lines += "   ${m.toGenericString()}"
                }
            }
        } catch (e: Throwable) {
            lines += "⚠️ فشل فحص API: ${e.javaClass.simpleName}: ${e.message}"
        }

        lines += "\n[3] SoundTrigger service"
        try {
            val st = getSystemService("soundtrigger")
            if (st == null) {
                lines += "❌ لا توجد خدمة SoundTrigger متاحة للتطبيق."
            } else {
                lines += "✅ خدمة SoundTrigger موجودة: ${st.javaClass.name}"
                val method = st.javaClass.methods.firstOrNull {
                    it.name == "getModuleProperties" && it.parameterTypes.isEmpty()
                }
                if (method == null) {
                    lines += "❌ getModuleProperties غير متاحة عبر هذا الكائن."
                } else {
                    try {
                        val props = method.invoke(st)
                        if (props == null) {
                            lines += "⚠️ getModuleProperties() = null → لا توجد وحدة ST مدعومة/محملة للتطبيق."
                        } else {
                            lines += "✅ ModuleProperties متاحة: ${props}"
                            lines += "   هذا مؤشر قوي على وجود وحدة SoundTrigger."
                        }
                    } catch (e: Throwable) {
                        val cause = e.cause ?: e
                        lines += "⚠️ getModuleProperties رفض الوصول: ${cause.javaClass.simpleName}: ${cause.message}"
                        lines += "   قد تكون الوحدة موجودة لكن محمية بصلاحيات نظام."
                    }
                }
            }
        } catch (e: Throwable) {
            lines += "❌ فشل الوصول إلى SoundTrigger: ${e.javaClass.simpleName}: ${e.message}"
        }

        lines += "\n[4] صلاحية النظام MANAGE_HOTWORD_DETECTION"
        try {
            val info = packageManager.getPermissionInfo("android.permission.MANAGE_HOTWORD_DETECTION", 0)
            lines += "موجودة في النظام. protectionLevel=0x${info.protectionLevel.toString(16)}"
        } catch (e: Throwable) {
            lines += "غير متاحة/غير معروفة لهذا النظام."
        }

        lines += "\n[5] النتيجة"
        lines += "هذه النسخة لا تفعل استماع SpeechRecognizer حتى لا يختلط اختبار DSP معه."
        lines += "إذا ظهر ModuleProperties أو نجح AlwaysOnHotwordDetector لاحقًا، ننتقل إلى محاولة hotword حقيقية."

        report.text = lines.joinToString("\n")
    }

    private fun openUserAppWithCommand(command: String) {
        val ui = Intent().setClassName(USER_APP_PACKAGE, USER_APP_ACTIVITY).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_VOICE_TEXT, command)
        }
        try { startActivity(ui) } catch (_: Exception) {}
    }

    companion object {
        const val EXTRA_CONTACTS = "core_permission_contacts"
        const val EXTRA_CALLS = "core_permission_calls"
        const val EXTRA_CAMERA = "core_permission_camera"
        const val EXTRA_MICROPHONE = "core_permission_microphone"
        const val EXTRA_COMMAND = "core_pending_command"
        const val EXTRA_VOICE_TEXT = "hamouri_voice_text"
        const val USER_APP_PACKAGE = "com.mohammad.hamouri"
        const val USER_APP_ACTIVITY = "com.mohammad.hamouri.MainActivity"
    }
}

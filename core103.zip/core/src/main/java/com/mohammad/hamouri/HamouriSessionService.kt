package com.mohammad.hamouri

import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class HamouriSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: android.os.Bundle?): VoiceInteractionSession {
        // Temporary test build: the software wake-word service is disabled,
        // so this session owns the microphone without any competing service.
        return HamouriSession(this)
    }
}

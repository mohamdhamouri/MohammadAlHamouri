package com.mohammad.hamouri

import android.content.Intent
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class HamouriSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: android.os.Bundle?): VoiceInteractionSession {
        // Android 11/API 30 does not expose onPrepareToShowSession().
        // Pause the software hotword recognizer here, immediately before the
        // active assistant session creates its own SpeechRecognizer.
        try {
            startService(
                Intent(this, HamouriHotwordService::class.java)
                    .setAction(HamouriHotwordService.ACTION_PAUSE)
            )
        } catch (_: Exception) {}

        return HamouriSession(this)
    }
}

package com.mohammad.hamouri

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.service.voice.VoiceInteractionSession
import java.util.Locale

/**
 * Native Android assistant session.
 * The session delegates microphone capture to the app's already-running
 * foreground hotword service. This avoids competing SpeechRecognizer
 * instances and avoids false microphone-permission failures when the system
 * invokes the assistant UI.
 */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var handled = false

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        handled = false
        handler.removeCallbacksAndMessages(null)
        requestOneShotCommand()
    }

    private fun requestOneShotCommand() {
        try {
            context.startService(
                android.content.Intent(context, HamouriHotwordService::class.java)
                    .setAction(HamouriHotwordService.ACTION_LISTEN_COMMAND)
            )
            // The foreground service owns the microphone and will execute the
            // command (or open the chat UI) after recognition completes.
            handler.postDelayed({ if (!handled) {
                // Give the speech recognizer enough time to initialize and capture the user's command.
                // The previous 1.6s timeout hid the assistant before recognition could finish.
                hide()
            } }, 15000)
        } catch (_: Exception) {
            openMainForMicrophonePermission()
        }
    }

    private fun openMainForMicrophonePermission() {
        val intent = android.content.Intent(context, HamouriCoreSetupActivity::class.java).apply {
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(HamouriCoreSetupActivity.EXTRA_MICROPHONE, true)
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
        hide()
    }

    override fun onHide() {
        handler.removeCallbacksAndMessages(null)
        super.onHide()
    }
}

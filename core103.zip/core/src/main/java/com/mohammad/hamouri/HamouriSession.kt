package com.mohammad.hamouri

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.service.voice.VoiceInteractionSession
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * VoiceInteractionSession for the Android assistant button.
 *
 * IMPORTANT: this session owns the one-shot microphone while the assistant UI
 * is open. The background HotwordService is paused by
 * HamouriVoiceInteractionService.onPrepareToShowSession() so the two
 * SpeechRecognizer instances never compete for the microphone.
 */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var finished = false
    private var attempts = 0

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            listening = true
        }
        override fun onBeginningOfSpeech() { listening = true }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }

        override fun onError(error: Int) {
            listening = false
            if (finished) return
            // Do not speak "لم أسمع الأمر" immediately. Give the recognizer
            // a few real listening attempts first.
            if (attempts < 2) {
                attempts++
                handler.postDelayed({ startListeningNow() }, 450)
            } else {
                finishWithMessage("لم أسمع الأمر. تفضل.")
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            if (finished) return
            val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (command.isBlank()) {
                if (attempts < 2) {
                    attempts++
                    handler.postDelayed({ startListeningNow() }, 450)
                } else {
                    finishWithMessage("لم أسمع الأمر. تفضل.")
                }
                return
            }
            executeCommand(command)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        finished = false
        attempts = 0
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            finishWithMessage("يجب السماح للميكروفون أولًا.")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            finishWithMessage("التعرف على الكلام غير متاح على هذا الهاتف.")
            return
        }

        // The hotword service was paused before this session was shown.
        // Start our one-shot recognizer only after the system has presented
        // the assistant session.
        handler.postDelayed({ startListeningNow() }, 250)
    }

    private fun startListeningNow() {
        if (finished || listening) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            finishWithMessage("يجب السماح للميكروفون أولًا.")
            return
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
                it.setRecognitionListener(listener)
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }

        try {
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            if (attempts < 2) {
                attempts++
                handler.postDelayed({ startListeningNow() }, 600)
            } else {
                finishWithMessage("تعذر تشغيل الميكروفون.")
            }
        }
    }

    private fun executeCommand(command: String) {
        finished = true
        val router = CommandRouter(context)
        val result = router.execute(command)

        result.pendingIntent?.let { pending ->
            try { context.startActivity(pending.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }

        if (result.requestContactsPermission || result.requestCallPermission || result.requestCameraPermission) {
            val intent = Intent(context, HamouriCoreSetupActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(HamouriCoreSetupActivity.EXTRA_CONTACTS, result.requestContactsPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_CALLS, result.requestCallPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_CAMERA, result.requestCameraPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_COMMAND, command)
            }
            try { context.startActivity(intent) } catch (_: Exception) {}
        } else if (!result.actionPerformed) {
            val intent = Intent().setClassName(
                HamouriCoreSetupActivity.USER_APP_PACKAGE,
                HamouriCoreSetupActivity.USER_APP_ACTIVITY
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(HamouriCoreSetupActivity.EXTRA_VOICE_TEXT, command)
            }
            try { context.startActivity(intent) } catch (_: Exception) {}
        }
        hide()
    }

    private fun finishWithMessage(message: String) {
        if (finished) return
        finished = true
        speak(message)
        handler.postDelayed({ hide() }, 1400)
    }

    private fun speak(message: String) {
        lateinit var tts: TextToSpeech
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("ar")
                tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hamouri-assistant")
                handler.postDelayed({ tts.shutdown() }, 2200)
            }
        }
    }

    override fun onHide() {
        finished = true
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        // Temporary test build: wake-word service is disabled.
        super.onHide()
    }

    private fun destroyRecognizer() {
        listening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }
}

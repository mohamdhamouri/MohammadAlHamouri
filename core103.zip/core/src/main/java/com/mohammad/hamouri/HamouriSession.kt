package com.mohammad.hamouri

import android.Manifest
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.service.voice.VoiceInteractionSession
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * VoiceInteractionSession for the Android assistant button.
 *
 * IMPORTANT: this session owns the one-shot microphone while the assistant UI
 * is open. The background HotwordService is paused by
 * HamouriVoiceInteractionService.onPrepareToShowSession() so the two
 * SpeechRecognizer instances never compete for the microphone.
 */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var finished = false
    private var attempts = 0
    private val diagChannel = "hamouri_diag"

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            listening = true
            diag("8/12 onReadyForSpeech", "بدأ محرك التعرف الاستماع فعليًا")
        }
        override fun onBeginningOfSpeech() {
            listening = true
            diag("9/12 onBeginningOfSpeech", "اكتشف بداية الكلام")
        }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            listening = false
            diag("10/12 onEndOfSpeech", "انتهى التقاط الكلام")
        }

        override fun onError(error: Int) {
            listening = false
            diag("11/12 onError($error)", errorName(error))
            if (finished) return
            // Do not speak "لم أسمع الأمر" immediately. Give the recognizer
            // a few real listening attempts first.
            if (attempts < 2) {
                attempts++
                handler.postDelayed({ startListeningNow() }, 450)
            } else {
                finishWithMessage("لم أسمع الأمر. تفضل.")
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val all = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            diag("11/12 onResults", if (all.isEmpty()) "لا توجد نتائج" else all.joinToString(" | "))
            if (finished) return
            val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (command.isBlank()) {
                if (attempts < 2) {
                    attempts++
                    handler.postDelayed({ startListeningNow() }, 450)
                } else {
                    finishWithMessage("لم أسمع الأمر. تفضل.")
                }
                return
            }
            executeCommand(command)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        diag("1/12 onShow", "جلسة المساعد ظهرت. flags=$showFlags")
        finished = false
        attempts = 0
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            diag("2/12 microphone permission", "مرفوضة")
            finishWithMessage("يجب السماح للميكروفون أولًا.")
            return
        }
        diag("2/12 microphone permission", "مسموح")

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            diag("3/12 recognition availability", "غير متاح")
            finishWithMessage("التعرف على الكلام غير متاح على هذا الهاتف.")
            return
        }
        diag("3/12 recognition availability", "متاح")

        // The hotword service was paused before this session was shown.
        // Start our one-shot recognizer only after the system has presented
        // the assistant session.
        diag("4/12 scheduling", "سيبدأ SpeechRecognizer بعد 250ms")
        handler.postDelayed({ startListeningNow() }, 250)
    }

    private fun startListeningNow() {
        if (finished || listening) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            finishWithMessage("يجب السماح للميكروفون أولًا.")
            return
        }

        if (recognizer == null) {
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
                    it.setRecognitionListener(listener)
                }
                diag("5/12 createSpeechRecognizer", "تم الإنشاء: ${recognizer!!::class.java.name}")
            } catch (e: Exception) {
                diag("5/12 createSpeechRecognizer", "فشل: ${e.javaClass.simpleName}: ${e.message}")
                finishWithMessage("تعذر إنشاء محرك التعرف.")
                return
            }
        } else {
            diag("5/12 createSpeechRecognizer", "المحرك موجود مسبقًا")
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }

        try {
            diag("6/12 startListening", "استدعاء startListening الآن")
            listening = true
            recognizer?.startListening(intent)
            diag("7/12 startListening", "تم استدعاء startListening بدون استثناء")
        } catch (e: Exception) {
            diag("7/12 startListening", "استثناء: ${e.javaClass.simpleName}: ${e.message}")
            listening = false
            if (attempts < 2) {
                attempts++
                handler.postDelayed({ startListeningNow() }, 600)
            } else {
                finishWithMessage("تعذر تشغيل الميكروفون.")
            }
        }
    }

    private fun executeCommand(command: String) {
        finished = true
        val router = CommandRouter(context)
        val result = router.execute(command)

        result.pendingIntent?.let { pending ->
            try { context.startActivity(pending.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }

        if (result.requestContactsPermission || result.requestCallPermission || result.requestCameraPermission) {
            val intent = Intent(context, HamouriCoreSetupActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(HamouriCoreSetupActivity.EXTRA_CONTACTS, result.requestContactsPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_CALLS, result.requestCallPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_CAMERA, result.requestCameraPermission)
                putExtra(HamouriCoreSetupActivity.EXTRA_COMMAND, command)
            }
            try { context.startActivity(intent) } catch (_: Exception) {}
        } else if (!result.actionPerformed) {
            val intent = Intent().setClassName(
                HamouriCoreSetupActivity.USER_APP_PACKAGE,
                HamouriCoreSetupActivity.USER_APP_ACTIVITY
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(HamouriCoreSetupActivity.EXTRA_VOICE_TEXT, command)
            }
            try { context.startActivity(intent) } catch (_: Exception) {}
        }
        hide()
    }

    private fun finishWithMessage(message: String) {
        if (finished) return
        finished = true
        diag("12/12 finish", message)
        speak(message)
        handler.postDelayed({ hide() }, 1400)
    }

    private fun errorName(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "ERROR_AUDIO: مشكلة في الصوت/الميكروفون"
        SpeechRecognizer.ERROR_CLIENT -> "ERROR_CLIENT: خطأ من العميل"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ERROR_INSUFFICIENT_PERMISSIONS: صلاحية الميكروفون غير كافية"
        SpeechRecognizer.ERROR_NETWORK -> "ERROR_NETWORK: خطأ شبكة"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ERROR_NETWORK_TIMEOUT: انتهت مهلة الشبكة"
        SpeechRecognizer.ERROR_NO_MATCH -> "ERROR_NO_MATCH: لم يجد تطابقًا صوتيًا"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "ERROR_RECOGNIZER_BUSY: محرك التعرف مشغول"
        SpeechRecognizer.ERROR_SERVER -> "ERROR_SERVER: خطأ من خادم التعرف"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ERROR_SPEECH_TIMEOUT: لم يبدأ الكلام قبل انتهاء المهلة"
        else -> "خطأ غير معروف: $error"
    }

    private fun diag(stage: String, detail: String) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    NotificationChannel(diagChannel, "تشخيص مساعد حموري", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val n = androidx.core.app.NotificationCompat.Builder(context, diagChannel)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("تشخيص جلسة مساعد محمد الحموري")
                .setContentText(stage)
                .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText("$stage\n$detail"))
                .setOngoing(false)
                .setAutoCancel(false)
                .build()
            nm.notify(9090, n)
        } catch (_: Exception) {}
    }

    private fun speak(message: String) {
        lateinit var tts: TextToSpeech
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("ar")
                tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hamouri-assistant")
                handler.postDelayed({ tts.shutdown() }, 2200)
            }
        }
    }

    override fun onHide() {
        finished = true
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        // Temporary test build: wake-word service is disabled.
        super.onHide()
    }

    private fun destroyRecognizer() {
        listening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }
}

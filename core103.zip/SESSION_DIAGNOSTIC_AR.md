# تشخيص جلسة المساعد 1.0.9

هذا الإصدار لا يشغل Wake Word. عند ضغط زر المساعد، يظهر إشعار متدرج يحدد أين يتوقف المسار.

المراحل: onShow، صلاحية الميكروفون، توفر التعرف، جدولة التشغيل، إنشاء SpeechRecognizer، استدعاء startListening، onReadyForSpeech، onBeginningOfSpeech، onEndOfSpeech، onResults/onError، ثم النتيجة النهائية.

لا نستخدم هذا الإصدار للحكم على Wake Word؛ الهدف فقط تشخيص مسار VoiceInteractionSession -> SpeechRecognizer على Android 11.

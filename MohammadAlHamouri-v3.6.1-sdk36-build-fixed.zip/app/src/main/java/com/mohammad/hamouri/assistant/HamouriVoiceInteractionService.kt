package com.mohammad.hamouri.assistant

import android.service.voice.VoiceInteractionService
import android.os.Bundle
import android.util.Log

class HamouriVoiceInteractionService : VoiceInteractionService() {
    companion object {
        @Volatile private var activeInstance: HamouriVoiceInteractionService? = null
        fun showWakeSession() {
            try { activeInstance?.showSession(Bundle(), 0) }
            catch (e: Exception) { Log.e("HamouriAssistant", "Unable to show wake session", e) }
        }
    }
    override fun onCreate() { super.onCreate(); activeInstance = this }

    override fun onReady() {
        super.onReady()
        Log.i("HamouriAssistant", "Voice interaction service ready")
    }

    override fun onShutdown() {
        activeInstance = null
        Log.i("HamouriAssistant", "Voice interaction service shutting down")
        super.onShutdown()
    }
}

package com.mohammad.hamouri.assistant

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.util.Log

class HamouriSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        Log.i("HamouriAssistant", "Creating assistant session")
        return HamouriSession(this)
    }
}

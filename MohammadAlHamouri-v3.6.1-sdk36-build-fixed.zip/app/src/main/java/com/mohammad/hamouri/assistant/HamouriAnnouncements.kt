package com.mohammad.hamouri.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.telephony.SmsMessage
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

internal object HamouriAnnouncement {
    fun enabled(context: Context) = context.getSharedPreferences("hamouri", Context.MODE_PRIVATE).getBoolean("announce_calls_messages", true)
    fun speak(context: Context, text: String) {
        if (!enabled(context)) return
        try {
            lateinit var engine: TextToSpeech
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        engine.language = Locale("ar", "JO")
                        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hamouri_announcement")
                    } catch (e: Exception) { Log.e("HamouriAnnouncements", "TTS failed", e) }
                } else {
                    try { engine.shutdown() } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) { Log.e("HamouriAnnouncements", "Could not initialize TTS", e) }
    }
    fun contactName(context: Context, number: String?): String? {
        if (number.isNullOrBlank()) return null
        return try {
            context.contentResolver.query(
                android.net.Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }
}

class HamouriCallAnnouncementReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED || !HamouriAnnouncement.enabled(context)) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val name = HamouriAnnouncement.contactName(context, number)
        val announcement = if (!name.isNullOrBlank()) "أنا مساعدك الرقمي حموري، لديك اتصال من $name" else "أنا مساعدك الرقمي حموري، لديك اتصال من رقم غريب"
        HamouriAnnouncement.speak(context, announcement)
    }
}

class HamouriSmsAnnouncementReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED" || !HamouriAnnouncement.enabled(context)) return
        HamouriAnnouncement.speak(context, "أنا مساعدك الرقمي حموري، لديك رسالة عادية")
    }
}

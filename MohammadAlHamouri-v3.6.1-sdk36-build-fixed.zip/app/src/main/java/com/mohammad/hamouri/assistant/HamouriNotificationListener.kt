package com.mohammad.hamouri.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class HamouriNotificationListener : NotificationListenerService() {
    private val recent = LinkedHashMap<String, Long>()
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" || !HamouriAnnouncement.enabled(this)) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() || title.equals("WhatsApp", true) || text.isBlank()) return
        val key = sbn.key
        val now = System.currentTimeMillis()
        synchronized(recent) {
            if (recent[key]?.let { now - it < 30_000 } == true) return
            recent[key] = now
            recent.entries.removeAll { now - it.value > 120_000 }
        }
        HamouriAnnouncement.speak(this, "أنا مساعدك الرقمي حموري، لديك رسالة واتساب من $title")
    }
}

package com.mohammad.hamouri.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat

/** Best-effort restart after device boot; Android may restrict microphone foreground services. */
class HamouriWakeRecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED && intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.i("HamouriWakeRecovery", "Not restarting: microphone permission is not granted")
            return
        }
        try {
            val serviceIntent = Intent(context, HamouriWakeWordService::class.java).setAction(HamouriWakeWordService.ACTION_START)
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (e: Exception) {
            Log.e("HamouriWakeRecovery", "Automatic wake service restart was blocked", e)
        }
    }
}

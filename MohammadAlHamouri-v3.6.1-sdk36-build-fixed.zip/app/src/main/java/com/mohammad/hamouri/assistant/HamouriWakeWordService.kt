package com.mohammad.hamouri.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.AlarmManager
import android.app.PendingIntent.FLAG_IMMUTABLE
import android.content.Context
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.mohammad.hamouri.R
import java.util.Locale

/**
 * Experimental always-listening wake phrase detector. It uses the device's ordinary
 * speech recognizer, not a low-power hardware hotword engine; availability depends on
 * the device/provider and Android background microphone rules.
 */
class HamouriWakeWordService : Service() {
    companion object {
        const val ACTION_START = "com.mohammad.hamouri.action.START_WAKE_WORD"
        const val ACTION_STOP = "com.mohammad.hamouri.action.STOP_WAKE_WORD"
        const val ACTION_RESUME = "com.mohammad.hamouri.action.RESUME_WAKE_WORD"
        private const val TAG = "HamouriWakeWord"
        private const val CHANNEL_ID = "hamouri_wake_word"
        private const val NOTIFICATION_ID = 3501
        private const val RECOGNIZER_TIMEOUT_MS = 18000L
        private const val RESTART_DELAY_MS = 1500L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var triggered = false
    private var serviceStarted = false
    private var recognizerGeneration = 0
    private var consecutiveErrors = 0
    private var lastStatus = "تهيئة خدمة الاستماع…"
    private val recognizerWatchdog = Runnable {
        if (serviceStarted && !triggered) {
            Log.w(TAG, "Recognizer watchdog expired; rebuilding recognizer")
            listening = false
            updateNotification("انتهت مهلة الاستماع؛ جارٍ إعادة المحاولة")
            stopRecognition()
            scheduleRestart(RESTART_DELAY_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            startForeground(NOTIFICATION_ID, buildNotification("الخدمة بدأت؛ جارٍ تجهيز التعرف الصوتي"))
            serviceStarted = true
            lastStatus = "الخدمة بدأت؛ جارٍ تجهيز التعرف الصوتي"
            Log.i(TAG, "Foreground notification posted")
        } catch (e: Exception) {
            serviceStarted = false
            Log.e(TAG, "startForeground failed; service cannot continue", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_RESUME) {
            triggered = false
            updateNotification("انتهى تفاعل المساعد؛ استئناف الاستماع")
            handler.removeCallbacks(restartRunnable)
            handler.postDelayed({ beginListening() }, 1200L)
            return START_STICKY
        }
        if (intent?.action == ACTION_STOP) {
            serviceStarted = false
            handler.removeCallbacksAndMessages(null)
            stopRecognition()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Microphone permission is not granted; stopping wake-word service")
            stopSelf()
            return START_NOT_STICKY
        }
        serviceStarted = true
        updateNotification("الخدمة تعمل؛ جارٍ بدء الاستماع")
        beginListening()
        return START_STICKY
    }

    private fun beginListening() {
        if (!serviceStarted || listening || triggered) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "No speech recognition provider available")
            updateNotification("لا يوجد مزوّد تعرّف صوتي؛ سأعيد المحاولة تلقائيًا")
            scheduleRestart(5000L)
            return
        }
        try {
            recognizer?.destroy()
            val generation = ++recognizerGeneration
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {
                        if (generation != recognizerGeneration) return
                        listening = true
                        consecutiveErrors = 0
                        lastStatus = "جاهز للاستماع؛ قل حموري أو يا حموري"
                        updateNotification(lastStatus)
                        handler.removeCallbacks(recognizerWatchdog)
                        handler.postDelayed(recognizerWatchdog, RECOGNIZER_TIMEOUT_MS)
                    }
                    override fun onBeginningOfSpeech() {
                        if (generation != recognizerGeneration) return
                        lastStatus = "أسمعك الآن…"
                        updateNotification(lastStatus)
                        handler.removeCallbacks(recognizerWatchdog)
                        handler.postDelayed(recognizerWatchdog, RECOGNIZER_TIMEOUT_MS)
                    }
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        if (generation != recognizerGeneration) return
                        listening = false
                        handler.removeCallbacks(recognizerWatchdog)
                        updateNotification("انتهى الكلام؛ أنتظر نتيجة التعرف")
                        handler.postDelayed(recognizerWatchdog, 8000L)
                    }
                    override fun onError(error: Int) {
                        if (generation != recognizerGeneration) return
                        listening = false
                        handler.removeCallbacks(recognizerWatchdog)
                        consecutiveErrors++
                        Log.w(TAG, "Recognizer error=$error; failures=$consecutiveErrors; scheduling controlled recovery")
                        val delay = when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 15000L
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 8000L
                            else -> (5000L * consecutiveErrors.coerceAtMost(6)).coerceAtMost(30000L)
                        }
                        updateNotification(if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                            "تعذر الوصول إلى خدمة التعرف (رمز 9)؛ سأنتظر قبل إعادة المحاولة لتجنب تكرار تشغيل الميكروفون"
                        else "تعذر التعرف الصوتي (رمز $error)؛ إعادة المحاولة بعد ${delay / 1000} ثوانٍ")
                        stopRecognition()
                        scheduleRestart(delay)
                    }
                    override fun onResults(results: android.os.Bundle?) {
                        if (generation != recognizerGeneration) return
                        handler.removeCallbacks(recognizerWatchdog)
                        listening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        Log.i(TAG, "Final recognition candidates: ${matches.joinToString(" | ")}")
                        if (matches.any { containsWakePhrase(it) }) {
                            triggerWake("final: ${matches.joinToString(" | ")}")
                        } else {
                            updateNotification("سمعت: ${matches.firstOrNull().orEmpty().take(55)} — قل حموري")
                            scheduleRestart(RESTART_DELAY_MS)
                        }
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        if (generation != recognizerGeneration) return
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        Log.d(TAG, "Partial recognition candidates: ${matches.joinToString(" | ")}")
                        if (matches.isNotEmpty()) updateNotification("أسمع: ${matches.first().take(55)}")
                        if (matches.any { containsWakePhrase(it) }) {
                            triggerWake("partial: ${matches.joinToString(" | ")}")
                        }
                    }
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                sr.startListening(speechIntent)
                listening = true
                updateNotification("تم طلب بدء الاستماع؛ أنتظر الميكروفون")
                handler.removeCallbacks(recognizerWatchdog)
                handler.postDelayed(recognizerWatchdog, RECOGNIZER_TIMEOUT_MS)
            }
        } catch (e: Exception) {
            listening = false
            handler.removeCallbacks(recognizerWatchdog)
            Log.e(TAG, "Could not start recognizer", e)
            updateNotification("تعذّر بدء التعرف الصوتي؛ إعادة المحاولة")
            stopRecognition()
            scheduleRestart(RESTART_DELAY_MS)
        }
    }

    private fun normalizeArabic(text: String): String {
        return text.lowercase(Locale.forLanguageTag("ar-JO"))
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ى", "ي").replace("ـ", " ")
            .replace(Regex("[\u064B-\u065F\u0670]"), "")
            .replace(Regex("[،,.!?؛:؟\\-]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }

    private fun containsWakePhrase(text: String): Boolean {
        val normalized = normalizeArabic(text)
        val tokens = normalized.split(' ').filter { it.isNotBlank() }
        // Arabic speech recognition sometimes drops or changes a vowel/consonant.
        // Match whole tokens only to reduce accidental activations.
        val variants = setOf("حموري", "حاموري", "هموري")
        return tokens.any { it in variants || it == "ياحموري" || it == "ياحاموري" } ||
            tokens.windowed(2).any { it[0] == "يا" && it[1] in variants }
    }

    private fun triggerWake(reason: String) {
        if (triggered) return
        triggered = true
        Log.i(TAG, "Wake phrase detected; attempting to show assistant. $reason")
        updateNotification("تم اكتشاف كلمة الاستدعاء؛ جارٍ فتح المساعد")
        stopRecognition()
        try {
            val wake = Intent(this, com.mohammad.hamouri.WakeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(wake)
            HamouriVoiceInteractionService.showWakeSession()
        } catch (e: Exception) {
            Log.e(TAG, "Wake phrase detected but showing assistant failed", e)
            updateNotification("تم سماع كلمة الاستدعاء لكن تعذّر فتح الواجهة")
        }
        // Do not restart the background recognizer while the foreground assistant
        // UI may be using the microphone. MainActivity explicitly resumes this
        // service when its one-shot command recognition finishes.
        updateNotification("تم استدعاء المساعد؛ أوقفت الاستماع الخلفي مؤقتًا لتجنب تعارض الميكروفون")
    }

    private fun updateNotification(status: String?) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun scheduleRestart(delayMs: Long = RESTART_DELAY_MS) {
        handler.removeCallbacks(recognizerWatchdog)
        handler.removeCallbacks(restartRunnable)
        if (!serviceStarted) return
        handler.postDelayed(restartRunnable, delayMs)
    }

    private val restartRunnable = Runnable {
        if (serviceStarted && !triggered) beginListening()
    }

    private fun stopRecognition() {
        handler.removeCallbacks(recognizerWatchdog)
        listening = false
        recognizerGeneration++
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "استماع كلمة حموري", NotificationManager.IMPORTANCE_LOW)
            channel.description = "إشعار دائم عند تفعيل الاستماع لكلمة حموري"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String? = null): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, com.mohammad.hamouri.MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID).setContentTitle("محمد الحموري يستمع لكلمة الاستدعاء")
                .setContentText(status ?: "قل: حموري أو يا حموري").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("محمد الحموري يستمع لكلمة الاستدعاء")
                .setContentText(status ?: "قل: حموري أو يا حموري").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending).setOngoing(true).build()
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Best-effort recovery only; Android/OEM background restrictions may still prevent it.
        scheduleRestart(RESTART_DELAY_MS)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        serviceStarted = false
        handler.removeCallbacksAndMessages(null)
        stopRecognition()
        Log.w(TAG, "Wake-word foreground service destroyed")
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

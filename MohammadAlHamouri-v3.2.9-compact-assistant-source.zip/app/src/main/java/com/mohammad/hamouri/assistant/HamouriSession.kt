package com.mohammad.hamouri.assistant

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.mohammad.hamouri.MainActivity

/**
 * Compact assistant plate shown by Android when the default digital assistant is invoked.
 * The full conversation is opened only after the user taps the microphone or chat action.
 */
class HamouriSession(context: android.content.Context) : VoiceInteractionSession(context) {
    companion object {
        private const val TAG = "HamouriAssistant"
    }

    private var root: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        setUiEnabled(true)
        Log.i(TAG, "Compact voice session created")
    }

    override fun onCreateContentView(): View {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(16))
            background = rounded(Color.WHITE, dp(24).toFloat())
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }

        val title = TextView(context).apply {
            text = "محمد الحموري"
            textSize = 20f
            setTextColor(Color.rgb(32, 33, 36))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(context).apply {
            text = "مساعدك الرقمي الخاص"
            textSize = 13f
            setTextColor(Color.rgb(95, 99, 104))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(12))
        }

        val mic = Button(context).apply {
            text = "🎙️  تحدث إلى حموري"
            isAllCaps = false
            setOnClickListener { openMainActivity(listen = true) }
        }
        val chat = Button(context).apply {
            text = "اسأل محمد الحموري"
            isAllCaps = false
            setOnClickListener { openMainActivity(listen = false) }
        }
        val close = TextView(context).apply {
            text = "إغلاق"
            textSize = 14f
            setTextColor(Color.rgb(80, 80, 90))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(2))
            setOnClickListener { hide() }
        }

        panel.addView(title, LinearLayout.LayoutParams(-1, -2))
        panel.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        panel.addView(mic, LinearLayout.LayoutParams(-1, -2))
        panel.addView(chat, LinearLayout.LayoutParams(-1, -2))
        panel.addView(close, LinearLayout.LayoutParams(-1, -2))
        root = panel
        return panel
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i(TAG, "Compact assistant panel shown; flags=$showFlags")
        root?.visibility = View.VISIBLE
    }

    override fun onHide() {
        root?.visibility = View.GONE
        super.onHide()
    }

    private fun openMainActivity(listen: Boolean) {
        val assistantIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, listen)
        }
        try {
            startAssistantActivity(assistantIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start assistant activity", e)
            try {
                context.startActivity(assistantIntent)
            } catch (second: Exception) {
                Log.e(TAG, "Fallback activity launch failed", second)
            }
        }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(225, 227, 230))
    }
}

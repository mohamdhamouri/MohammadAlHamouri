package com.mohammad.hamouri

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS))
        setContent { HamouriTheme { HamouriHome() } }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun HamouriHome() {
        val prefs = remember { getSharedPreferences("hamouri", Context.MODE_PRIVATE) }
        var input by remember { mutableStateOf("") }
        var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
        var showSettings by remember { mutableStateOf(false) }
        var messages by remember {
            mutableStateOf(loadMessages(prefs))
        }
        var listening by remember { mutableStateOf(false) }

        fun save() {
            val encoded = messages.joinToString("\n") { (if (it.fromUser) "U" else "A") + "|" + it.text.replace("\n", " ") }
            prefs.edit().putString("chat", encoded).apply()
        }
        fun add(text: String, user: Boolean) {
            messages = messages + ChatMessage(text, user)
            save()
        }
        fun send(text: String) {
            val q = text.trim()
            if (q.isEmpty()) return
            add(q, true)
            input = ""
            val answer = if (apiKey.isBlank()) {
                "وصلني أمرك. افتح الإعدادات وأدخل مفتاح Gemini لتفعيل الردود الذكية."
            } else {
                "تم استلام رسالتك. اتصال Gemini جاهز للربط في الخطوة التالية."
            }
            add(answer, false)
        }

        fun listen() {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                return
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                add("التعرف الصوتي غير متاح على هذا الهاتف.", false)
                return
            }
            val r = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            r.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() { listening = true }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) { listening = false; r.destroy() }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    r.destroy()
                    if (text.isNotBlank()) { input = text; send(text) }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = android.content.Intent(
                RecognizerIntent.ACTION_RECOGNIZE_SPEECH
            ).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            r.startListening(intent)
        }

        Scaffold(
            containerColor = Color(0xFFF8F8FC),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("محمد الحموري", fontWeight = FontWeight.Bold)
                            Text("مساعدك الرقمي الخاص", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = { IconButton(onClick = { showSettings = true }) { Text("⚙️") } }
                )
            },
            bottomBar = {
                Surface(shadowElevation = 8.dp) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("اسأل محمد الحموري...") },
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true
                        )
                        IconButton(onClick = { listen() }) { Text(if (listening) "🔴" else "🎙️") }
                        IconButton(onClick = { send(input) }) { Text("➤", fontSize = 22.sp) }
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 20.dp)
            ) {
                item {
                    Text("ماذا تريد أن أفعل لك؟", fontSize = 28.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("💡", "اسألني", Modifier.weight(1f))
                        QuickAction("📷", "صورة", Modifier.weight(1f))
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("✨", "إنشاء", Modifier.weight(1f))
                        QuickAction("📄", "ملف", Modifier.weight(1f))
                    }
                }
                items(messages) { MessageBubble(it) }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("إعدادات محمد الحموري") },
                text = {
                    Column {
                        Text("مفتاح Gemini API")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = { apiKey = it },
                            singleLine = true,
                            placeholder = { Text("المفتاح يبقى على الهاتف") }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("لا تضع المفتاح داخل GitHub أو داخل الكود.", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("gemini_key", apiKey.trim()).apply()
                        showSettings = false
                    }) { Text("حفظ") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } }
            )
        }
    }

    private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
        val raw = prefs.getString("chat", "") ?: ""
        if (raw.isBlank()) return listOf(ChatMessage("مرحبًا، أنا محمد الحموري 👋\nكيف يمكنني مساعدتك اليوم؟", false))
        return raw.lines().mapNotNull { line ->
            val i = line.indexOf('|')
            if (i <= 0) null else ChatMessage(line.substring(i + 1), line.substring(0, i) == "U")
        }
    }
}

@Composable
private fun HamouriTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF4F46E5),
            secondary = Color(0xFF7C3AED),
            surface = Color(0xFFF8F8FC)
        ), content = content
    )
}

@Composable
private fun QuickAction(icon: String, title: String, modifier: Modifier) {
    ElevatedCard(modifier.height(90.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(icon, fontSize = 25.sp)
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (message.fromUser) Color(0xFFE9E7FF) else Color.White
        ) { Text(message.text, Modifier.padding(14.dp), fontSize = 16.sp) }
    }
}

package com.mohammad.hamouri

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.app.role.RoleManager
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.provider.OpenableColumns
import android.provider.MediaStore
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executors

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_ASSISTANT_INVOCATION = "hamouri_assistant_invocation"
    }

    private var activeRecognizer: SpeechRecognizer? = null
    private var pendingVoiceCommand by mutableStateOf<String?>(null)
    private var pendingContactCommand by mutableStateOf<String?>(null)
    private val geminiExecutor = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        // Re-check the system permission after the dialog has closed. On some Android 11
        // builds the callback value can race the permission state update by a short moment.
        window.decorView.postDelayed({
            val actuallyGranted = granted || ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (actuallyGranted) {
                assistantListenRequested = true
                startWakeWordService()
            } else {
                permissionStatusMessage = "ما زال Android يمنع الميكروفون. افتح إعدادات التطبيق > الأذونات > الميكروفون، واختر السماح أثناء استخدام التطبيق. وتأكد أيضًا من تشغيل مفتاح «الوصول إلى الميكروفون» في إعدادات الخصوصية السريعة."
            }
        }, 250L)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ar", "JO")
            }
        }

        // Start the wake-word listener only after microphone permission is granted.
        startWakeWordService()

        // Permissions are requested only when their feature is used. This avoids a stale
        // permission state being captured before Android finishes the permission dialog.
        pendingVoiceCommand = intent.getStringExtra("hamouri_voice_command")
        setContent { HamouriTheme { HamouriHome() } }

        if (intent.getBooleanExtra(EXTRA_ASSISTANT_INVOCATION, false)) {
            window.decorView.postDelayed({ startListeningFromAssistant() }, 350L)
        }
    }

    private fun startWakeWordService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            android.util.Log.i("HamouriAssistant", "Wake service not started: microphone permission missing")
            return
        }
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, com.mohammad.hamouri.assistant.HamouriWakeWordService::class.java)
                    .setAction(com.mohammad.hamouri.assistant.HamouriWakeWordService.ACTION_START)
            )
            android.util.Log.i("HamouriAssistant", "Requested wake-word foreground service start")
        } catch (e: Exception) {
            android.util.Log.e("HamouriAssistant", "Could not start wake phrase listener", e)
            android.widget.Toast.makeText(this, "تعذّر تشغيل خدمة الاستماع: ${e.javaClass.simpleName}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun startListeningFromAssistant() {
        // The Activity microphone button and the system assistant now share exactly one path.
        // Compose's listen() is invoked by a small bridge state below.
        assistantListenRequested = true
    }

    private var assistantListenRequested by mutableStateOf(false)
    private var permissionStatusMessage by mutableStateOf<String?>(null)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingVoiceCommand = intent.getStringExtra("hamouri_voice_command")
        if (intent.getBooleanExtra(EXTRA_ASSISTANT_INVOCATION, false)) {
            window.decorView.post { assistantListenRequested = true }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun HamouriHome() {
        val prefs = remember { getSharedPreferences("hamouri", Context.MODE_PRIVATE) }
        var input by remember { mutableStateOf("") }
        var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
        var showSettings by remember { mutableStateOf(false) }
        var messages by remember {
            mutableStateOf(loadMessages(prefs))
        }
        var listening by remember { mutableStateOf(false) }
        var showHistory by remember { mutableStateOf(false) }
        var showAttachMenu by remember { mutableStateOf(false) }
        var attachmentUri by remember { mutableStateOf<Uri?>(null) }
        var attachmentName by remember { mutableStateOf<String?>(null) }
        var attachmentMime by remember { mutableStateOf<String?>(null) }
        var modeHint by remember { mutableStateOf<String?>(null) }
        var suppressNextUserEcho by remember { mutableStateOf(false) }
        val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                attachmentUri = uri
                attachmentMime = contentResolver.getType(uri) ?: "image/*"
                attachmentName = "صورة مرفقة"
            }
        }
        val contactCallPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { grants ->
            val command = pendingContactCommand
            pendingContactCommand = null
            if (grants[Manifest.permission.READ_CONTACTS] == true && grants[Manifest.permission.CALL_PHONE] == true && command != null) {
                suppressNextUserEcho = true
                pendingVoiceCommand = command
            } else {
                permissionStatusMessage = "للاتصال باسم شخص، أحتاج إذني جهات الاتصال والاتصال من إعدادات Android."
            }
        }
        val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                attachmentUri = uri
                attachmentMime = contentResolver.getType(uri) ?: "application/octet-stream"
                attachmentName = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                } ?: "ملف مرفق"
            }
        }

        fun save() {
            val encoded = messages.joinToString("\n") { (if (it.fromUser) "U" else "A") + "|" + it.text.replace("\n", " ") }
            prefs.edit().putString("chat", encoded).apply()
        }
        fun add(text: String, user: Boolean) {
            messages = messages + ChatMessage(text, user)
            save()
        }
        fun send(text: String) {
            val q = text.trim()
            if (q.isEmpty()) return

            val activeUri = attachmentUri
            val activeMime = attachmentMime ?: "application/octet-stream"
            val activeName = attachmentName
            val displayQuestion = if (activeUri != null) "$q\n[مرفق: ${activeName ?: "ملف"}]" else q
            if (suppressNextUserEcho) {
                suppressNextUserEcho = false
            } else {
                messages = messages + ChatMessage(displayQuestion, true)
                save()
            }
            input = ""

            val identity = CommandRouter.identityResponse(q)
            if (identity != null) {
                messages = messages + ChatMessage(identity, false)
                save()
                tts?.speak(identity, TextToSpeech.QUEUE_FLUSH, null, "hamouri_identity")
                return
            }

            val isCallCommand = q.startsWith("اتصل ") || q.startsWith("اتصل ب") || q.startsWith("اتصل على")
            if (isCallCommand && (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)) {
                pendingContactCommand = q
                contactCallPermissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
                return
            }

            val local = CommandRouter.handle(this@MainActivity, q)
            if (local.handled) {
                messages = messages + ChatMessage(local.message, false)
                save()
                tts?.speak(local.message, TextToSpeech.QUEUE_FLUSH, null, "hamouri_local")
                return
            }

            if (apiKey.isBlank()) {
                val answer =
                    "أدخل مفتاح Gemini API من الإعدادات أولًا، ثم أرسل رسالتك."
                messages = messages + ChatMessage(answer, false)
                save()
                tts?.speak(
                    answer,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "hamouri_reply"
                )
                return
            }

            val history = messages.map {
                GeminiApi.Turn(it.text, it.fromUser)
            }.takeLast(20)
            val attachmentBytes = if (activeUri != null) try {
                contentResolver.openInputStream(activeUri)?.use { stream -> stream.readBytes().takeIf { it.size <= 15 * 1024 * 1024 } }
            } catch (_: Exception) { null } else null
            val attachment = if (attachmentBytes != null && activeUri != null) {
                GeminiApi.Attachment(activeMime, attachmentBytes, activeName ?: "attachment")
            } else null
            if (activeUri != null && attachment == null) {
                messages = messages + ChatMessage("تعذر قراءة المرفق أو تجاوز حجمه 15 ميغابايت. جرّب ملفًا أصغر.", false)
                save()
                return
            }
            attachmentUri = null
            attachmentName = null
            attachmentMime = null

            val createImage = modeHint == "إنشاء صورة" || (attachment != null && activeMime.startsWith("image/") && listOf("عدل", "عدّل", "تعديل", "غيّر", "غير", "اجعل", "حوّل", "حول").any { q.contains(it) })
            modeHint = null
            if (createImage) {
                messages = messages + ChatMessage("جارٍ إنشاء الصورة أو تعديلها…", false)
                save()
                geminiExecutor.execute {
                    val result = GeminiApi.generateImage(apiKey, q, attachment)
                    runOnUiThread {
                        messages = messages.dropLast(1)
                        val imageBytes = result.getOrNull()
                        val resultMessage = if (imageBytes != null) {
                            try {
                                val values = android.content.ContentValues().apply {
                                    put(MediaStore.Images.Media.DISPLAY_NAME, "Hamouri-${System.currentTimeMillis()}.png")
                                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                                    if (android.os.Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MohammadAlHamouri")
                                }
                                val imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                                if (imageUri != null) contentResolver.openOutputStream(imageUri)?.use { it.write(imageBytes) }
                                if (imageUri != null) "تم حفظ الصورة في المعرض: Pictures/MohammadAlHamouri" else "تم إنشاء الصورة لكن تعذر حفظها في المعرض."
                            } catch (e: Exception) { "تم استلام الصورة لكن تعذر حفظها: ${e.message ?: "خطأ"}" }
                        } else "تعذر إنشاء الصورة: ${result.exceptionOrNull()?.message ?: "خطأ غير معروف"}"
                        messages = messages + ChatMessage(resultMessage, false)
                        save()
                        tts?.speak(resultMessage, TextToSpeech.QUEUE_FLUSH, null, "hamouri_image")
                    }
                }
                return
            }

            val loading = "جارٍ التفكير…"
            messages = messages + ChatMessage(loading, false)
            save()

            geminiExecutor.execute {
                val result = GeminiApi.generate(apiKey, history, attachment)

                runOnUiThread {
                    messages = messages.dropLast(1)

                    val answer = result.getOrElse {
                        "تعذر الحصول على رد من Gemini:\n${it.message ?: "خطأ غير معروف"}"
                    }

                    messages = messages + ChatMessage(answer, false)
                    save()

                    tts?.speak(
                        answer,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        "hamouri_reply"
                    )
                }
            }
        }

        LaunchedEffect(pendingVoiceCommand) {
            val command = pendingVoiceCommand
            if (!command.isNullOrBlank()) {
                pendingVoiceCommand = null
                send(command)
            }
        }

        fun listen() {
            if (listening) {
                try { activeRecognizer?.cancel() } catch (_: Exception) {}
                activeRecognizer?.destroy()
                activeRecognizer = null
                listening = false
                return
            }

            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionStatusMessage = "أحتاج إذن الميكروفون. اختر «السماح أثناء استخدام التطبيق» في نافذة Android."
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                return
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                val providers = try {
                    packageManager.queryIntentServices(
                        Intent("android.speech.RecognitionService"),
                        PackageManager.MATCH_DEFAULT_ONLY
                    ).mapNotNull { it.serviceInfo?.let { info -> "${info.packageName}/${info.name}" } }
                } catch (e: Exception) { emptyList() }
                val detail = if (providers.isEmpty()) {
                    "لم يعثر Android على أي خدمة RecognitionService ظاهرة للتطبيق. افتح إعدادات التعرف الصوتي وثبّت/فعّل خدمة مثل Google Speech Services إن كانت متاحة."
                } else {
                    "عثر Android على خدمات: ${providers.joinToString()} لكن SpeechRecognizer لا يعتبرها متاحة. راجع إعدادات الإدخال الصوتي."
                }
                add("خدمة تحويل الكلام إلى نص غير متاحة.\n$detail", false)
                return
            }

            try { activeRecognizer?.cancel() } catch (_: Exception) {}
            try { activeRecognizer?.destroy() } catch (_: Exception) {}

            // Do not let Android implicitly bind to the selected assistant's own
            // RecognitionService. On some Android 11 devices this resolves to
            // ChatGPT or our compatibility service and fails before listening.
            // Prefer an installed external speech provider (Google when present).
            val speechProvider = try {
                packageManager.queryIntentServices(
                    Intent("android.speech.RecognitionService"),
                    PackageManager.MATCH_DEFAULT_ONLY
                ).mapNotNull { it.serviceInfo }
                    .filter { it.packageName != packageName }
                    .sortedWith(compareBy<android.content.pm.ServiceInfo> {
                        if (it.packageName == "com.google.android.googlequicksearchbox" ||
                            it.packageName == "com.google.android.tts") 0 else 1
                    })
                    .firstOrNull()
            } catch (_: Exception) { null }

            val r = if (speechProvider != null) {
                SpeechRecognizer.createSpeechRecognizer(
                    this@MainActivity,
                    ComponentName(speechProvider.packageName, speechProvider.name)
                )
            } else {
                // Keep Android's normal fallback if no external provider is visible.
                SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            }
            activeRecognizer = r
            listening = true
            add("🎙️ أستمع إليك الآن…", false)

            r.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() { listening = true }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    listening = false
                    if (activeRecognizer === r) activeRecognizer = null
                    r.destroy()
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "تعذر الوصول إلى الميكروفون."
                        SpeechRecognizer.ERROR_CLIENT -> "تعذر بدء التعرف الصوتي. اضغط المايك وحاول مرة أخرى."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "رفض نظام التعرف الصوتي الوصول إلى الميكروفون رغم فحص الإذن. تحقق من إذن التطبيق ومن مفتاح الوصول إلى الميكروفون في إعدادات الخصوصية في Android."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "خدمة التعرف الصوتي تحتاج إلى اتصال بالإنترنت على هذا الهاتف."
                        SpeechRecognizer.ERROR_NO_MATCH -> "لم أسمع كلامًا واضحًا. حاول مرة أخرى."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة التعرف الصوتي مشغولة. انتظر لحظة ثم حاول."
                        SpeechRecognizer.ERROR_SERVER -> "خدمة التعرف الصوتي لم تستجب."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم يبدأ الكلام. اضغط المايك وتحدث مباشرة."
                        else -> "تعذر تشغيل الميكروفون (رمز الخطأ $error)."
                    }
                    add(message, false)
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    if (activeRecognizer === r) activeRecognizer = null
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    r.destroy()
                    if (text.isNotBlank()) {
                        input = text
                        send(text)
                    } else {
                        add("لم أسمع الكلام. حاول مرة أخرى.", false)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) input = partial
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث إلى محمد الحموري")
            }

            try {
                r.startListening(intent)
            } catch (e: Exception) {
                listening = false
                if (activeRecognizer === r) activeRecognizer = null
                r.destroy()
                add("تعذر تشغيل الميكروفون: ${e.message ?: "خطأ غير معروف"}", false)
            }
        }

        LaunchedEffect(assistantListenRequested) {
            if (assistantListenRequested) {
                assistantListenRequested = false
                listen()
            }
        }

        Scaffold(
            containerColor = Color(0xFFF8F8FC),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("محمد الحموري", fontWeight = FontWeight.Bold)
                            Text("مساعدك الرقمي الخاص", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        TextButton(onClick = { showHistory = true }) { Text("المحادثات", fontSize = 12.sp) }
                        TextButton(onClick = {
                            val current = prefs.getString("chat", "").orEmpty()
                            if (current.isNotBlank()) {
                                val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date())
                                prefs.edit().putString("conversation_$stamp", current).apply()
                            }
                            val greeting = "A|مرحبًا، أنا محمد الحموري 👋\nكيف يمكنني مساعدتك اليوم؟"
                            prefs.edit().putString("chat", greeting).apply()
                            messages = listOf(ChatMessage("مرحبًا، أنا محمد الحموري 👋\nكيف يمكنني مساعدتك اليوم؟", false))
                            input = ""
                            attachmentUri = null; attachmentName = null; attachmentMime = null
                            try { tts?.stop() } catch (_: Exception) {}
                        }) { Text("＋ محادثة جديدة", fontSize = 12.sp) }
                        IconButton(onClick = { showSettings = true }) { Text("⚙️") }
                    }
                )
            },
            bottomBar = {
                Surface(shadowElevation = 8.dp) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showAttachMenu = true }) { Text("＋", fontSize = 26.sp) }
                        Column(Modifier.weight(1f)) {
                        if (attachmentName != null) Text("📎 $attachmentName", fontSize = 11.sp, color = Color(0xFF4F46E5), maxLines = 1)
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("اسأل محمد الحموري...") },
                            shape = RoundedCornerShape(24.dp),
                            singleLine = false,
                            maxLines = 3
                        )
                        }
                        FilledIconButton(
                            onClick = { listen() },
                            modifier = Modifier.size(52.dp),
                            enabled = true
                        ) {
                            Text(if (listening) "■" else "🎙️", fontSize = 22.sp)
                        }
                        IconButton(onClick = { send(input) }) { Text("➤", fontSize = 22.sp) }
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 20.dp)
            ) {
                if (permissionStatusMessage != null) {
                    item {
                        ElevatedCard {
                            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Text(permissionStatusMessage!!, color = Color(0xFFB42318))
                                TextButton(onClick = {
                                    permissionStatusMessage = null
                                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                                }) { Text("فتح إعدادات التطبيق") }
                            }
                        }
                    }
                }
                item {
                    Text("ماذا تريد أن أفعل لك؟", fontSize = 28.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("💡", "اسألني", Modifier.weight(1f), onClick = { modeHint = "اسألني"; input = "" })
                        QuickAction("📷", "صورة", Modifier.weight(1f), onClick = { imagePicker.launch("image/*") })
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("✨", "إنشاء", Modifier.weight(1f), onClick = { modeHint = "إنشاء صورة"; input = "أنشئ صورة لـ " })
                        QuickAction("📄", "ملف", Modifier.weight(1f), onClick = { filePicker.launch(arrayOf("*/*")) })
                    }
                }
                items(messages) { MessageBubble(it) }
            }
        }

        if (showAttachMenu) {
            AlertDialog(
                onDismissRequest = { showAttachMenu = false },
                title = { Text("إضافة مرفق") },
                text = { Column {
                    TextButton(onClick = { showAttachMenu = false; imagePicker.launch("image/*") }) { Text("اختيار صورة") }
                    TextButton(onClick = { showAttachMenu = false; filePicker.launch(arrayOf("image/*", "application/pdf", "text/plain", "text/*")) }) { Text("اختيار صورة أو ملف") }
                    if (attachmentName != null) TextButton(onClick = { attachmentUri = null; attachmentName = null; attachmentMime = null; showAttachMenu = false }) { Text("إزالة المرفق الحالي") }
                } },
                confirmButton = { TextButton(onClick = { showAttachMenu = false }) { Text("إغلاق") } }
            )
        }

        if (showHistory) {
            val archived = prefs.all.keys.filter { it.startsWith("conversation_") }.sortedDescending()
            AlertDialog(
                onDismissRequest = { showHistory = false },
                title = { Text("المحادثات السابقة") },
                text = {
                    if (archived.isEmpty()) Text("لا توجد محادثات محفوظة بعد. ستُحفظ المحادثة الحالية عند بدء محادثة جديدة.")
                    else LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        items(archived) { key ->
                            TextButton(onClick = {
                                val current = prefs.getString("chat", "").orEmpty()
                                if (current.isNotBlank()) {
                                    val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date())
                                    prefs.edit().putString("conversation_$stamp", current).apply()
                                }
                                val saved = prefs.getString(key, "").orEmpty()
                                prefs.edit().putString("chat", saved).apply()
                                messages = saved.lines().mapNotNull { line ->
                                    val ix = line.indexOf('|'); if (ix <= 0) null else ChatMessage(line.substring(ix + 1), line.substring(0, ix) == "U")
                                }
                                showHistory = false
                            }, modifier = Modifier.fillMaxWidth()) { Text(key.removePrefix("conversation_")) }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showHistory = false }) { Text("إغلاق") } }
            )
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("إعدادات محمد الحموري") },
                text = {
                    Column {
                        Text("مفتاح Gemini API")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = { apiKey = it },
                            singleLine = true,
                            placeholder = { Text("المفتاح يبقى على الهاتف") }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("لا تضع المفتاح داخل GitHub أو داخل الكود.", fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(14.dp))
                        Text("حساب Google / Gmail", fontWeight = FontWeight.Bold)
                        Text("يتطلب تسجيل الدخول الحقيقي إعداد OAuth Client ID من Google Cloud Console؛ لم تتم إضافة بيانات اعتماد مزيفة داخل التطبيق.", fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(10.dp))
                        Text("تكاملات الهاتف", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        TextButton(onClick = {
                            try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                            catch (_: Exception) {
                                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
                            }
                        }) { Text("فحص/اختيار خدمة التعرف الصوتي") }
                        TextButton(onClick = { requestAssistantRole() }) { Text("اختيار محمد الحموري كمساعد رقمي") }
                        TextButton(onClick = { requestOverlayPermission() }) { Text("السماح بالظهور فوق التطبيقات") }
                        TextButton(onClick = { requestDeviceAdmin() }) { Text("تفعيل التحكم بقفل الشاشة") }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("gemini_key", apiKey.trim()).apply()
                        showSettings = false
                    }) { Text("حفظ") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } }
            )
        }
    }

    override fun onDestroy() {
        try { activeRecognizer?.cancel() } catch (_: Exception) {}
        try { activeRecognizer?.destroy() } catch (_: Exception) {}
        activeRecognizer = null
        tts?.shutdown()
        geminiExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun requestAssistantRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q &&
            roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
            startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT))
        } else {
            startActivity(Intent("android.settings.VOICE_INPUT_SETTINGS"))
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun requestDeviceAdmin() {
        val component = ComponentName(this, HamouriDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "السماح لمحمد الحموري بقفل الشاشة عند طلبك.")
        }
        startActivity(intent)
    }

    private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
        val raw = prefs.getString("chat", "") ?: ""
        if (raw.isBlank()) return listOf(ChatMessage("مرحبًا، أنا محمد الحموري 👋\nكيف يمكنني مساعدتك اليوم؟", false))
        return raw.lines().mapNotNull { line ->
            val i = line.indexOf('|')
            if (i <= 0) null else ChatMessage(line.substring(i + 1), line.substring(0, i) == "U")
        }
    }
}

@Composable
private fun HamouriTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF4F46E5),
            secondary = Color(0xFF7C3AED),
            surface = Color(0xFFF8F8FC)
        ), content = content
    )
}

@Composable
private fun QuickAction(icon: String, title: String, modifier: Modifier, onClick: () -> Unit = {}) {
    ElevatedCard(onClick = onClick, modifier = modifier.height(90.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(icon, fontSize = 25.sp)
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (message.fromUser) Color(0xFFE9E7FF) else Color.White
        ) { Text(message.text, Modifier.padding(14.dp), fontSize = 16.sp) }
    }
}

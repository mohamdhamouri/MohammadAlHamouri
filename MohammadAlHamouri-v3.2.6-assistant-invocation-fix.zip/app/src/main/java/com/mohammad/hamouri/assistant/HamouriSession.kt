package com.mohammad.hamouri.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.util.Log
import android.view.Gravity
import android.widget.TextView
import com.mohammad.hamouri.MainActivity

/** Session created by Android when the user invokes the selected digital assistant. */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    companion object {
        private const val TAG = "HamouriAssistant"
    }

    private var launchAttempted = false

    override fun onCreate() {
        super.onCreate()
        // Keep a small fallback UI available if Android refuses to start the Activity.
        // The real assistant interface remains MainActivity.
        setUiEnabled(true)
        Log.i(TAG, "VoiceInteractionSession created")
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i(TAG, "onShow received; flags=$showFlags")
        if (launchAttempted) {
            Log.i(TAG, "Activity launch already attempted for this session")
            return
        }
        launchAttempted = true

        val fallback = TextView(context).apply {
            text = "محمد الحموري\nجارٍ فتح المساعد…"
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        setContentView(fallback)

        val assistantIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, true)
        }

        try {
            Log.i(TAG, "Calling startAssistantActivity")
            startAssistantActivity(assistantIntent)
            Log.i(TAG, "startAssistantActivity call returned")
        } catch (first: Exception) {
            Log.e(TAG, "startAssistantActivity failed", first)
            try {
                assistantIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                context.startActivity(assistantIntent)
                Log.i(TAG, "Fallback context.startActivity succeeded")
            } catch (second: Exception) {
                Log.e(TAG, "Fallback activity launch failed", second)
                fallback.text = "تعذر فتح واجهة محمد الحموري.\n" +
                    (second.localizedMessage ?: second.javaClass.simpleName)
            }
        }
    }

    override fun onHide() {
        Log.i(TAG, "onHide received")
        launchAttempted = false
        super.onHide()
    }
}

import base64
import json
import os
import uuid
from typing import Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Muhammad Al-Hamouri AI Gateway", version="0.8.0")

SYSTEM = """أنت محمد الحموري، مساعد رقمي عربي.
إذا سأل المستخدم عن اسمك فقل: أنا محمد الحموري، مساعدك الرقمي الخاص وأنا هنا لخدمتك.
أجب بوضوح وبالعربية عند الإمكان. لا تدّع تنفيذ إجراء على الهاتف لم ينفذه التطبيق فعلياً.
"""

TOOLS = [
    {"type": "function", "name": "open_app", "description": "فتح تطبيق مثبت على هاتف Android بالاسم.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"], "additionalProperties": False}},
    {"type": "function", "name": "open_settings", "description": "فتح إعدادات Android.", "parameters": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"type": "function", "name": "open_camera", "description": "فتح كاميرا Android.", "parameters": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"type": "function", "name": "open_dialer", "description": "فتح تطبيق الهاتف/لوحة الاتصال.", "parameters": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"type": "function", "name": "dial_number", "description": "فتح شاشة الاتصال برقم محدد دون إجراء المكالمة تلقائياً.", "parameters": {"type": "object", "properties": {"number": {"type": "string"}}, "required": ["number"], "additionalProperties": False}},
]

class ChatRequest(BaseModel):
    message: str
    conversation_id: str = "default"
    system: Optional[str] = None

class ChatResponse(BaseModel):
    text: str
    conversation_id: str
    tool_calls: List[dict] = []

class ImageRequest(BaseModel):
    prompt: str
    size: str = "1024x1024"
    quality: str = "auto"

class ImageEditRequest(BaseModel):
    prompt: str
    image_base64: str
    mime_type: str = "image/png"

history: Dict[str, List[dict]] = {}

@app.get("/health")
def health():
    return {"ok": True, "service": "hamouri-gateway", "version": "0.8.0", "web_search": os.getenv("ENABLE_WEB_SEARCH", "true").lower() in {"1", "true", "yes", "on"}}

def api_key():
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key or key == "put_your_key_here":
        raise HTTPException(503, "OPENAI_API_KEY is not configured on the server")
    return key

async def call_openai(messages, instructions):
    tools = list(TOOLS)
    if os.getenv("ENABLE_WEB_SEARCH", "true").lower() in {"1", "true", "yes", "on"}:
        tools.append({"type": "web_search"})
    payload = {
        "model": os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
        "instructions": instructions,
        "tools": tools,
        "input": messages,
    }
    headers = {"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post("https://api.openai.com/v1/responses", headers=headers, json=payload)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text[:1000])
    return r.json()

def extract_text(data):
    text = (data.get("output_text") or "").strip()
    if text:
        return text
    parts = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") == "output_text":
                parts.append(content.get("text", ""))
    return "\n".join(parts).strip()

def extract_tool_calls(data):
    calls = []
    for item in data.get("output", []):
        if item.get("type") == "function_call":
            raw = item.get("arguments") or "{}"
            try:
                args = json.loads(raw)
            except json.JSONDecodeError:
                args = {}
            calls.append({"call_id": item.get("call_id", str(uuid.uuid4())), "name": item.get("name", ""), "arguments": args})
    return calls

async def image_request(prompt: str, size: str, quality: str):
    payload = {"model": os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2"), "prompt": prompt, "size": size, "quality": quality, "n": 1}
    headers = {"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post("https://api.openai.com/v1/images/generations", headers=headers, json=payload)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text[:1500])
    data = r.json()
    item = (data.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise HTTPException(502, "Image API did not return b64_json")
    return {"image_base64": b64, "mime_type": "image/png"}

async def image_edit(prompt: str, image_base64: str, mime_type: str):
    try:
        raw = base64.b64decode(image_base64)
    except Exception:
        raise HTTPException(400, "image_base64 is invalid")
    ext = "png" if "png" in mime_type else "jpg"
    files = {"image": (f"input.{ext}", raw, mime_type)}
    data = {"model": os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2"), "prompt": prompt, "n": "1"}
    headers = {"Authorization": f"Bearer {api_key()}"}
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post("https://api.openai.com/v1/images/edits", headers=headers, data=data, files=files)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text[:1500])
    result = r.json()
    item = (result.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise HTTPException(502, "Image edit API did not return b64_json")
    return {"image_base64": b64, "mime_type": "image/png"}

@app.post("/v1/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(400, "message is required")
    cid = req.conversation_id or "default"
    messages = history.setdefault(cid, [])
    messages.append({"role": "user", "content": req.message.strip()})
    messages[:] = messages[-20:]
    data = await call_openai(messages, req.system or SYSTEM)
    calls = extract_tool_calls(data)
    text = extract_text(data)
    if calls:
        return ChatResponse(text=text or "سأنفذ الإجراء المطلوب.", conversation_id=cid, tool_calls=calls)
    if not text:
        raise HTTPException(502, "The model returned no text")
    messages.append({"role": "assistant", "content": text})
    messages[:] = messages[-20:]
    return ChatResponse(text=text, conversation_id=cid, tool_calls=[])


class VisionRequest(BaseModel):
    prompt: str
    image_base64: str
    mime_type: str = "image/jpeg"

async def vision_request(prompt: str, image_base64: str, mime_type: str):
    try:
        # Validate and normalize the incoming base64 before sending it upstream.
        base64.b64decode(image_base64, validate=True)
    except Exception:
        raise HTTPException(400, "image_base64 is invalid")
    data_url = f"data:{mime_type};base64,{image_base64}"
    payload = {
        "model": os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
        "instructions": "حلل الصورة بدقة وأجب بالعربية عند الإمكان. لا تدّع رؤية شيء غير واضح في الصورة.",
        "input": [{"role": "user", "content": [
            {"type": "input_text", "text": prompt},
            {"type": "input_image", "image_url": data_url}
        ]}]
    }
    headers = {"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post("https://api.openai.com/v1/responses", headers=headers, json=payload)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text[:1500])
    result = r.json()
    text = extract_text(result)
    if not text:
        raise HTTPException(502, "Vision API did not return text")
    return {"text": text}

@app.post("/v1/vision")
async def generate_image(req: ImageRequest):
    if not req.prompt.strip():
        raise HTTPException(400, "prompt is required")
    return await image_request(req.prompt.strip(), req.size, req.quality)

@app.post("/v1/images/edit")
async def edit_image(req: ImageEditRequest):
    if not req.prompt.strip() or not req.image_base64.strip():
        raise HTTPException(400, "prompt and image_base64 are required")
    return await image_edit(req.prompt.strip(), req.image_base64.strip(), req.mime_type)

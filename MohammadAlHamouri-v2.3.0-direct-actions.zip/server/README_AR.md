# خادم محمد الحموري v0.8

يشغل FastAPI كوسيط آمن بين تطبيق Android وخدمات الذكاء الاصطناعي.

## التشغيل

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --host 0.0.0.0 --port 8000
```

ضع `OPENAI_API_KEY` في `.env` فقط. لا تضع المفتاح داخل تطبيق Android.

## المسارات

- `POST /v1/chat` — محادثة وفهم أدوات الهاتف.
- `POST /v1/images/generate` — إنشاء صورة وإرجاعها بصيغة base64.
- `POST /v1/images/edit` — تعديل صورة مرسلة بصيغة base64.
- `GET /health` — فحص الخادم.

يستخدم مسار الصور نموذج `gpt-image-2` افتراضيًا، ويمكن تغييره من `OPENAI_IMAGE_MODEL`.


### البحث وفهم الصور
- البحث على الويب مفعّل افتراضيًا عبر أداة Web Search في Responses API، ويمكن تعطيله بـ `ENABLE_WEB_SEARCH=false`.
- نقطة `POST /v1/vision` لتحليل صورة مع سؤال عنها.
- يبقى مفتاح OpenAI على الخادم فقط.

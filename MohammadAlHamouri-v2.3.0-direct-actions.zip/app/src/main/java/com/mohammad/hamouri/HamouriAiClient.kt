package com.mohammad.hamouri

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors

class HamouriAiClient(private val endpoint: String) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val conversationId = UUID.randomUUID().toString()

    fun ask(message: String, callback: (Result<AiResult>) -> Unit) {
        if (endpoint.isBlank()) {
            callback(Result.failure(IllegalStateException("لم يتم إعداد خادم الذكاء الاصطناعي بعد.")))
            return
        }
        executor.execute {
            try {
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 90_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val body = JSONObject().apply {
                    put("message", message)
                    put("conversation_id", conversationId)
                }.toString()
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
                connection.disconnect()
                if (status !in 200..299) throw IllegalStateException("خادم الذكاء الاصطناعي أعاد HTTP $status")
                val json = JSONObject(response)
                val text = json.optString("text").trim()
                val calls = mutableListOf<AiToolCall>()
                val array = json.optJSONArray("tool_calls") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    calls += AiToolCall(
                        item.optString("name"),
                        item.optJSONObject("arguments") ?: JSONObject()
                    )
                }
                main.post { callback(Result.success(AiResult(text, calls))) }
            } catch (t: Throwable) {
                main.post { callback(Result.failure(t)) }
            }
        }
    }
    fun analyzeImage(imageBase64: String, mimeType: String = "image/jpeg", prompt: String = "ماذا ترى في هذه الصورة؟ اشرح لي بالتفصيل.", callback: (Result<String>) -> Unit) {
        if (endpoint.isBlank()) {
            callback(Result.failure(IllegalStateException("لم يتم إعداد خادم الذكاء الاصطناعي بعد.")))
            return
        }
        executor.execute {
            try {
                val base = endpoint.removeSuffix("/v1/chat")
                val connection = (URL("$base/v1/vision").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 120_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val body = JSONObject().apply {
                    put("prompt", prompt)
                    put("image_base64", imageBase64)
                    put("mime_type", mimeType)
                }.toString()
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
                connection.disconnect()
                if (status !in 200..299) throw IllegalStateException("خادم الرؤية أعاد HTTP $status")
                val text = JSONObject(response).optString("text").trim()
                if (text.isBlank()) throw IllegalStateException("لم تصل إجابة تحليل الصورة")
                main.post { callback(Result.success(text)) }
            } catch (t: Throwable) {
                main.post { callback(Result.failure(t)) }
            }
        }
    }

}

data class AiToolCall(val name: String, val arguments: JSONObject)
data class AiResult(val text: String, val toolCalls: List<AiToolCall>)

package com.mohammad.hamouri
import android.content.Context
import android.content.Intent
import android.service.voice.VoiceInteractionSession
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: android.os.Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        hide()
    }
}

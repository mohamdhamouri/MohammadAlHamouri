package com.mohammad.hamouri

import android.content.Context

class HamouriPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hamouri", Context.MODE_PRIVATE)
    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(value) { prefs.edit().putString("api_key", value.trim()).apply() }
}

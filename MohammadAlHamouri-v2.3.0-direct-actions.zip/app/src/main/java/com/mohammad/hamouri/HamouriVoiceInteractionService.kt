package com.mohammad.hamouri
import android.service.voice.VoiceInteractionService
class HamouriVoiceInteractionService : VoiceInteractionService()

package com.mohammad.hamouri

import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class HamouriImageClient(private val apiKey: String) {
    private val main = Handler(Looper.getMainLooper())
    private val model = "gemini-3.1-flash-image"
    fun generate(prompt: String, callback: (Result<ImageResult>) -> Unit) = request(JSONArray().put(JSONObject().put("type","text").put("text",prompt)), callback)
    fun edit(prompt: String, bytes: ByteArray, mime: String, callback: (Result<ImageResult>) -> Unit) = request(JSONArray().put(JSONObject().put("type","image").put("mime_type",mime).put("data",Base64.encodeToString(bytes,Base64.NO_WRAP))).put(JSONObject().put("type","text").put("text",prompt)), callback)
    private fun request(input: JSONArray, callback: (Result<ImageResult>) -> Unit) {
        Thread {
            try {
                if (apiKey.isBlank()) error("لم يتم إدخال مفتاح Gemini API.")
                val body = JSONObject().put("model",model).put("input",input).put("response_format",JSONObject().put("type","image").put("image_size","1K"))
                val c=(URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection() as HttpURLConnection).apply { requestMethod="POST"; connectTimeout=30000; readTimeout=180000; doOutput=true; setRequestProperty("Content-Type","application/json"); setRequestProperty("x-goog-api-key",apiKey) }
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream; val response=stream.bufferedReader(Charsets.UTF_8).use{it.readText()}; if(code !in 200..299) error(friendlyError(code, response))
                val j=JSONObject(response); var data=j.optJSONObject("output_image")?.optString("data"); var mime=j.optJSONObject("output_image")?.optString("mime_type","image/png")?:"image/png"
                if(data.isNullOrBlank()){ val steps=j.optJSONArray("steps"); if(steps!=null) for(i in 0 until steps.length()){ val content=steps.optJSONObject(i)?.optJSONArray("content")?:continue; for(k in 0 until content.length()){ val b=content.optJSONObject(k); if(b?.optString("type")=="image"){data=b.optString("data",null); mime=b.optString("mime_type",mime)}}}}
                if(data.isNullOrBlank()) error("لم تُرجع خدمة الصور صورة.")
                main.post{callback(Result.success(ImageResult(Base64.decode(data,Base64.DEFAULT),mime)))}
            } catch(e:Exception){main.post{callback(Result.failure(e))}}
        }.start()
    }
    private fun friendlyError(code: Int, s: String): String {
        val raw = try { JSONObject(s).optJSONObject("error")?.optString("message") ?: s } catch (_: Exception) { s }
        val lower = raw.lowercase()
        return when {
            code == 429 || lower.contains("rate limit") || lower.contains("limit: 0") ->
                "إنشاء وتعديل الصور عبر Gemini API يحتاج إلى خطة مدفوعة في حساب API الحالي. الدردشة النصية ما زالت تعمل عبر الخطة المجانية إذا كان حسابك ضمن حدودها."
            code == 403 -> "لا يملك مفتاح Gemini صلاحية استخدام نموذج الصور. تحقق من إعدادات حساب Gemini API والفوترة."
            else -> raw.take(400)
        }
    }
}
data class ImageResult(val bytes:ByteArray,val mimeType:String)

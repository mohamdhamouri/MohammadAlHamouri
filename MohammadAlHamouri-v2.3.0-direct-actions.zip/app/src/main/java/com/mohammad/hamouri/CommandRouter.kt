package com.mohammad.hamouri

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Locale

class CommandRouter(private val context: Context) {
    fun execute(raw: String): CommandResult {
        val clean = normalize(raw)
        if (clean.isBlank()) return CommandResult("لم أسمع أمرًا واضحًا.", true)
        when {
            clean.contains("افتح الاعدادات") || clean.contains("افتح الإعدادات") ->
                return launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
            clean.contains("افتح الكاميرا") || clean.contains("شغل الكاميرا") || clean.contains("شغّل الكاميرا") ->
                return launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
            clean.contains("افتح الهاتف") || clean.contains("افتح الاتصال") || clean.contains("افتح الاتصالات") ->
                return launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        }

        val callMatch = Regex("(?:اتصل|اتصلي)\\s*(?:بـ|ب|بالرقم)?\\s*(.+)").find(raw)
        if (callMatch != null) {
            val target = callMatch.groupValues[1].trim().trim('.', '،', ',')
            val number = Regex("[+0-9][+0-9()\\- ]{4,}").find(target)?.value?.trim()
            if (!number.isNullOrBlank()) return dial(number)
            return dialContact(target)
        }

        val appName = Regex("(?:افتح|شغل|شغّل)\\s+(.+)").find(raw)?.groupValues?.get(1)?.trim()
        if (!appName.isNullOrBlank()) {
            val intent = findLaunchIntent(appName)
            if (intent != null) return launch(intent, "حسنًا، فتحت $appName.")
        }
        return CommandResult("", false)
    }

    private fun dialContact(target: String): CommandResult {
        if (target.isBlank()) return CommandResult("اذكر اسم جهة الاتصال التي تريد الاتصال بها.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult("أحتاج إذن جهات الاتصال لأبحث عن \"$target\" وأفتح رقمها.", true, requestContactsPermission = true)
        }
        val number = findContactNumber(target)
        return if (number != null) {
            dial(number)
        } else {
            CommandResult("لم أجد جهة اتصال باسم $target. تأكد من اسمها في جهات الاتصال.", true)
        }
    }

    private fun findContactNumber(target: String): String? {
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$target%")
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            args,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        val aliases = when (normalize(target).replace(" ", "")) {
            "ماما", "امي", "أمي", "الوالدة" -> listOf("ماما", "أمي", "امي", "الوالدة", "والدتي")
            else -> emptyList()
        }
        for (alias in aliases) {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                arrayOf("%$alias%"),
                null
            )?.use { cursor -> if (cursor.moveToFirst()) return cursor.getString(0) }
        }
        return null
    }

    fun executeTool(call: AiToolCall): CommandResult = when (call.name) {
        "open_settings" -> launch(Intent(Settings.ACTION_SETTINGS), "فتحت الإعدادات.")
        "open_camera" -> launch(Intent("android.media.action.IMAGE_CAPTURE"), "فتحت الكاميرا.")
        "open_dialer" -> launch(Intent(Intent.ACTION_DIAL), "فتحت تطبيق الهاتف.")
        "dial_number" -> dial(call.arguments.optString("number"))
        "open_app" -> {
            val name = call.arguments.optString("name").trim()
            val intent = findLaunchIntent(name)
            if (intent != null) launch(intent, "حسنًا، فتحت $name.") else CommandResult("لم أجد تطبيقًا باسم $name.", true)
        }
        else -> CommandResult("الأداة المطلوبة غير متاحة على هذا الإصدار.", true)
    }

    private fun dial(number: String): CommandResult {
        if (number.isBlank()) return CommandResult("لم أجد رقمًا صالحًا للاتصال.", true)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return CommandResult(
                "أحتاج إذن المكالمات لأتصل بهذا الرقم تلقائيًا.",
                true,
                requestCallPermission = true
            )
        }
        return CommandResult(
            "حسنًا، سأتصل الآن.",
            true,
            Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))
        )
    }

    private fun normalize(value: String): String = HamouriWakePhrase.strip(value).lowercase(Locale("ar"))

    private fun launch(intent: Intent, message: String): CommandResult = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CommandResult(message, true)
    } catch (_: Exception) { CommandResult("تعذر تنفيذ هذا الإجراء على جهازك.", true) }

    private fun findLaunchIntent(requested: String): Intent? {
        val pm = context.packageManager
        val normalized = requested.lowercase(Locale("ar")).replace(" ", "")
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase(Locale("ar")).replace(" ", "")
            label == normalized || label.contains(normalized) || normalized.contains(label)
        } ?: return null
        return pm.getLaunchIntentForPackage(match.packageName)
    }
}

data class CommandResult(
    val response: String,
    val actionPerformed: Boolean = false,
    val pendingIntent: Intent? = null,
    val requestContactsPermission: Boolean = false,
    val requestCallPermission: Boolean = false
)

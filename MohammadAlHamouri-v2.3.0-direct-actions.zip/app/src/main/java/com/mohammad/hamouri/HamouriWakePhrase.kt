package com.mohammad.hamouri

object HamouriWakePhrase {
    private val phrases = listOf("يا حموري", "حموري")

    fun strip(text: String): String {
        var value = text.trim()
        for (phrase in phrases) {
            if (value.startsWith(phrase, ignoreCase = true)) {
                value = value.removePrefix(phrase).trim()
                break
            }
        }
        return value
    }

    fun isInvocation(text: String): Boolean =
        phrases.any { text.trim().startsWith(it, ignoreCase = true) }
}

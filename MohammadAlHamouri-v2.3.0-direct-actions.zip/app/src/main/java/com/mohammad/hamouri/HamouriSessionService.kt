package com.mohammad.hamouri

import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class HamouriSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: android.os.Bundle?): VoiceInteractionSession = HamouriSession(this)
}

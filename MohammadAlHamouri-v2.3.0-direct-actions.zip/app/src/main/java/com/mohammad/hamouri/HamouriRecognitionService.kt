package com.mohammad.hamouri

import android.content.Intent
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/** Minimal recognizer component required for VoiceInteractionService qualification.
 * The app's visible microphone button continues to use the device's normal recognizer.
 */
class HamouriRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onStopListening(listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }
}


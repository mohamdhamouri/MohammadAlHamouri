# محمد الحموري 3.2.2 — فحص خدمة التعرف الصوتي

- إضافة `<queries>` لخدمة `android.speech.RecognitionService` لمعالجة قيود ظهور الحزم في Android 11 وما بعده.
- إذا تعذر بدء SpeechRecognizer، يعرض التطبيق هل يستطيع Android اكتشاف مزود خدمة التعرف الصوتي.
- إضافة اختصار إلى إعدادات خدمة/إدخال الصوت.
- الإبقاء على مسار VoiceInteractionService الحالي دون استخدام واجهات نظام مخفية.

ارفع محتويات هذا المشروع إلى مستودع GitHub وشغّل Actions لبناء APK.


Version 3.2.3 adds the RecognitionService component referenced by the VoiceInteractionService metadata. Android 11 and earlier may reset a selected assistant when that metadata is missing or invalid. The in-app microphone still uses the device's configured recognition provider.

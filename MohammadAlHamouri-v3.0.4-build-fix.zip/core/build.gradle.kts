plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mohammad.hamouri"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.mohammad.hamouri.core"
        minSdk = 26
        targetSdk = 37
        versionCode = 43
        versionName = "3.0.3-core"
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.activity:activity:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
}

# محمد الحموري 3.2.2 — فحص خدمة التعرف الصوتي

- إضافة `<queries>` لخدمة `android.speech.RecognitionService` لمعالجة قيود ظهور الحزم في Android 11 وما بعده.
- إذا تعذر بدء SpeechRecognizer، يعرض التطبيق هل يستطيع Android اكتشاف مزود خدمة التعرف الصوتي.
- إضافة اختصار إلى إعدادات خدمة/إدخال الصوت.
- الإبقاء على مسار VoiceInteractionService الحالي دون استخدام واجهات نظام مخفية.

ارفع محتويات هذا المشروع إلى مستودع GitHub وشغّل Actions لبناء APK.


## 3.2.4 assistant registration-only patch
This release adds the Android RecognitionService declaration and voice-interaction XML reference to improve visibility in Android assistant selection. MainActivity.kt and all internal microphone UI/recognition code are preserved byte-for-byte from 3.2.2. The added RecognitionService does not acquire or use the microphone.

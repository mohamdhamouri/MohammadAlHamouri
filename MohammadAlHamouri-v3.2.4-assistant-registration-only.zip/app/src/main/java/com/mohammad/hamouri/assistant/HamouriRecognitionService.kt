package com.mohammad.hamouri.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Required by Android 11 and earlier for a VoiceInteractionService to remain
 * registered as an assistant. Actual in-app dictation continues to use the
 * device's configured speech recognizer. This minimal provider fails explicitly
 * rather than hanging if another component directly selects it for recognition.
 */
class HamouriRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, callback: Callback?) {
        callback?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onStopListening(callback: Callback?) {
        callback?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(callback: Callback?) {
        // Nothing to cancel: this compatibility provider does not own a microphone.
    }
}

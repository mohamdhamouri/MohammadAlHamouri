# محمد الحموري — Core 1.0.2

هذه نسخة مستقلة من نواة مساعد محمد الحموري.

## مهم
- هذا المشروع يحتوي على تطبيق Core واحد فقط.
- يوجد Workflow واحد فقط داخل `.github/workflows/build-core.yml`.
- الـ Workflow يبني `:core:assembleDebug` ثم يبحث عن APK الحقيقي داخل `core/build/outputs/apk/debug/` ويرفعه كـ Artifact باسم `MohammadAlHamouri-Core-APK`.
- لا يوجد مسار `extracted/app/...` في هذا المشروع.

## البناء من الهاتف
1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. افتح Actions.
3. اختر `Build محمد الحموري Core APK`.
4. اضغط `Run workflow`.
5. بعد نجاح البناء يجب أن يظهر `Artifacts: 1` باسم `MohammadAlHamouri-Core-APK`.

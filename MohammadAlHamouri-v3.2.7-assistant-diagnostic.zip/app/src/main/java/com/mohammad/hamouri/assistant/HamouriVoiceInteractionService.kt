package com.mohammad.hamouri.assistant

import android.service.voice.VoiceInteractionService
import android.util.Log
import android.widget.Toast

class HamouriVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.i("HamouriAssistant", "VoiceInteractionService is ready")
        Toast.makeText(this, "محمد الحموري: خدمة المساعد جاهزة", Toast.LENGTH_SHORT).show()
    }

    override fun onShutdown() {
        Log.i("HamouriAssistant", "VoiceInteractionService is shutting down")
        super.onShutdown()
    }
}

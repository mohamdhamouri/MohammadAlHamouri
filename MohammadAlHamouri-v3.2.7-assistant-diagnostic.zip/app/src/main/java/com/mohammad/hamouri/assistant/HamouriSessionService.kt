package com.mohammad.hamouri.assistant

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.util.Log
import android.widget.Toast

class HamouriSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        Log.i("HamouriAssistant", "SessionService received a new session request")
        Toast.makeText(this, "محمد الحموري: وصل طلب إنشاء جلسة المساعد", Toast.LENGTH_SHORT).show()
        return HamouriSession(this)
    }
}

package com.mohammad.hamouri.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import com.mohammad.hamouri.MainActivity

/**
 * Android assistant bridge.
 *
 * The system assistant gesture opens the real Muhammad Al-Hamouri Activity,
 * where the normal microphone pipeline is used. This avoids having two
 * independent SpeechRecognizer owners competing for the microphone.
 */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    private var launched = false

    override fun onCreate() {
        super.onCreate()
        // The actual UI is the assistant Activity.
        setUiEnabled(false)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        if (launched) return
        launched = true

        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_ASSISTANT_INVOCATION, true)
        }

        try {
            // API 26+: designed for an Activity launched as the assistant UI.
            startAssistantActivity(intent)
        } catch (_: Exception) {
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                // Keep the system session alive rather than failing silently.
            }
        }
    }

    override fun onHide() {
        launched = false
        super.onHide()
    }
}

# محمد الحموري 3.1.2

نسخة موحدة من تطبيق محمد الحموري.

## ما الجديد
- تسجيل VoiceInteractionService مع Android بشكل كامل، مع SessionService وRecognitionService.
- يمكن للنظام عرض محمد الحموري ضمن تطبيقات المساعد الرقمي المتوافقة.
- تكامل الظهور فوق التطبيقات الأخرى.
- Device Admin لقفل الشاشة.
- أوامر الهاتف المحلية قبل Gemini: فتح التطبيقات، الهاتف، الاتصال، المصباح، قفل الشاشة وإيقاظها ضمن قيود Android.
- Gemini 3.8 Flash مع fallback تلقائي إلى Gemini 3.1 Flash-Lite عند الضغط/الأخطاء المؤقتة.
- تنظيف تنسيق Markdown البسيط من ردود Gemini.

مفتاح Gemini يبقى على الجهاز ولا يوضع داخل GitHub أو الكود.

## 3.1.5 assistant-button fix
- The Android assistant session now owns one SpeechRecognizer directly on Android 11/API 30.
- Removed the empty/no-op session behavior that could immediately end the assistant interaction.
- No 1.6-second auto-hide timer; the session waits for speech up to 12 seconds.
- Local identity replies and phone commands are handled before Gemini.
- General voice commands are handed to the main محمد الحموري app.

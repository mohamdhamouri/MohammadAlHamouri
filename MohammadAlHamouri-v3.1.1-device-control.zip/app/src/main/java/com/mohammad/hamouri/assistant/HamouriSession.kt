package com.mohammad.hamouri.assistant
import android.content.Context
import android.service.voice.VoiceInteractionSession

class HamouriSession(context: Context) : VoiceInteractionSession(context)

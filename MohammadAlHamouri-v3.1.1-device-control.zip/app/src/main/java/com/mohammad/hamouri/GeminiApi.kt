package com.mohammad.hamouri

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object GeminiApi {
    private const val MODEL = "gemini-3.6-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    data class Turn(val text: String, val fromUser: Boolean)

    fun generate(apiKey: String, history: List<Turn>): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(Exception("لم يتم إدخال مفتاح Gemini API."))
        }

        return try {
            val contents = JSONArray()

            history.takeLast(20).forEach { turn ->
                contents.put(
                    JSONObject()
                        .put("role", if (turn.fromUser) "user" else "model")
                        .put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", turn.text))
                        )
                )
            }

            val body = JSONObject()
                .put("contents", contents)
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.7)
                        .put("maxOutputTokens", 2048)
                )

            val connection =
                URL(ENDPOINT).openConnection() as HttpURLConnection

            connection.requestMethod = "POST"
            connection.connectTimeout = 20000
            connection.readTimeout = 60000
            connection.doOutput = true
            connection.setRequestProperty(
                "Content-Type",
                "application/json; charset=UTF-8"
            )
            connection.setRequestProperty("x-goog-api-key", apiKey)

            connection.outputStream.use { output ->
                output.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode

            val stream =
                if (code in 200..299) connection.inputStream
                else connection.errorStream

            val raw = stream?.use {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText()
            }.orEmpty()

            connection.disconnect()

            if (code !in 200..299) {
                val message = try {
                    JSONObject(raw)
                        .optJSONObject("error")
                        ?.optString("message")
                } catch (_: Exception) {
                    null
                }

                return Result.failure(
                    Exception(
                        message?.takeIf { it.isNotBlank() }
                            ?: "تعذر الاتصال بـ Gemini. رمز الخطأ: $code"
                    )
                )
            }

            val candidates =
                JSONObject(raw).optJSONArray("candidates")
                    ?: return Result.failure(
                        Exception("لم يُرجع Gemini إجابة.")
                    )

            for (i in 0 until candidates.length()) {
                val parts = candidates
                    .optJSONObject(i)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?: continue

                val answer = buildString {
                    for (j in 0 until parts.length()) {
                        val text =
                            parts.optJSONObject(j)
                                ?.optString("text")
                                .orEmpty()

                        if (text.isNotBlank()) {
                            if (isNotEmpty()) append("\n")
                            append(text)
                        }
                    }
                }.trim()

                if (answer.isNotBlank()) {
                    return Result.success(answer)
                }
            }

            Result.failure(Exception("لم يتم العثور على نص في رد Gemini."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

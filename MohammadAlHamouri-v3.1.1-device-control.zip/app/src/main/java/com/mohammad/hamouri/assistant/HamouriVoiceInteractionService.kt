package com.mohammad.hamouri.assistant
import android.service.voice.VoiceInteractionService

class HamouriVoiceInteractionService : VoiceInteractionService()

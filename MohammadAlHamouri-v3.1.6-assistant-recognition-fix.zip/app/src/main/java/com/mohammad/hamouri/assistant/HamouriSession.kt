package com.mohammad.hamouri.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.service.voice.VoiceInteractionSession
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.mohammad.hamouri.CommandRouter
import java.util.Locale

/**
 * Real microphone path for the Android assistant button.
 * It intentionally does not use the custom RecognitionService or the hotword
 * service, so pressing the assistant button gets one clean microphone owner.
 */
class HamouriSession(context: Context) : VoiceInteractionSession(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var retryCount = 0
    private var finished = false
    private var statusView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        setUiEnabled(true)
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ar", "JO")
            }
        }
    }

    override fun onCreateContentView(): View {
        return TextView(context).apply {
            statusView = this
            text = "محمد الحموري\nأستمع إليك…"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(40, 28, 40, 28)
            setBackgroundColor(0xCC202124.toInt())
        }
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        finished = false
        retryCount = 0
        updateUi("محمد الحموري\nأستمع إليك…")
        startListening()
    }

    private fun startListening() {
        if (finished) return
        handler.removeCallbacksAndMessages(null)

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            updateUi("محمد الحموري\nإذن الميكروفون غير ممنوح.")
            finishWithMessage("يحتاج محمد الحموري إلى إذن الميكروفون أولًا.")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            updateUi("محمد الحموري\nخدمة التعرف الصوتي غير متاحة.")
            finishWithMessage("التعرف الصوتي غير متاح على هذا الهاتف.")
            return
        }

        destroyRecognizer()
        val externalService = findExternalRecognitionService()
        updateUi(if (externalService != null) {
            "محمد الحموري\nتم العثور على خدمة التعرف: ${externalService.packageName}\nجارٍ الاستماع…"
        } else {
            "محمد الحموري\nلم أجد خدمة تعرف خارجية، سأستخدم الخدمة الافتراضية…"
        })
        recognizer = if (externalService != null) {
            SpeechRecognizer.createSpeechRecognizer(context, externalService)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                updateUi("محمد الحموري\n🎙️ جاهز للاستماع… تحدث الآن")
                scheduleTimeout()
            }

            override fun onBeginningOfSpeech() {
                updateUi("محمد الحموري\n🎙️ أستمع إليك…")
                handler.removeCallbacksAndMessages(null)
            }

            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                updateUi("محمد الحموري\nجارٍ تحويل كلامك إلى نص…")
                scheduleTimeout(2500L)
            }

            override fun onError(error: Int) {
                if (finished) return
                updateUi("محمد الحموري\nخطأ التعرف الصوتي: $error\n${errorMessage(error)}")
                if (retryCount < 2 && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    retryCount++
                    handler.postDelayed({ startListening() }, 450L)
                } else {
                    finishWithMessage(errorMessage(error))
                }
            }

            override fun onResults(results: Bundle?) {
                if (finished) return
                updateUi("محمد الحموري\nوصلت النتيجة…")
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isBlank()) {
                    if (retryCount < 2) {
                        retryCount++
                        handler.postDelayed({ startListening() }, 650L)
                    } else {
                        finishWithMessage("لم أسمع الأمر. تفضل مرة أخرى.")
                    }
                    return
                }
                handleCommand(text)
            }

            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
        }

        try {
            recognizer?.startListening(intent)
            scheduleTimeout()
        } catch (e: Exception) {
            updateUi("محمد الحموري\nتعذر بدء الاستماع: ${e.javaClass.simpleName}")
            if (retryCount < 2) {
                retryCount++
                handler.postDelayed({ startListening() }, 650L)
            } else {
                finishWithMessage("تعذر بدء الميكروفون. حاول مرة أخرى.")
            }
        }
    }

    private fun scheduleTimeout(delay: Long = 12000L) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!finished) {
                try { recognizer?.cancel() } catch (_: Exception) { }
                finishWithMessage("انتهى وقت الاستماع. اضغط زر المساعد وتحدث إلى محمد الحموري.")
            }
        }, delay)
    }

    private fun handleCommand(text: String) {
        handler.removeCallbacksAndMessages(null)
        val q = text.trim()
        val identity = CommandRouter.identityResponse(q)
        if (identity != null) {
            finishWithMessage(identity)
            return
        }

        val local = CommandRouter.handle(context, q)
        if (local.handled) {
            finishWithMessage(local.message)
            return
        }

        val intent = Intent(context, com.mohammad.hamouri.MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("hamouri_voice_command", q)
        }
        try {
            context.startActivity(intent)
            finishSessionOnly()
        } catch (_: Exception) {
            finishWithMessage("تعذر فتح محمد الحموري لتنفيذ الأمر.")
        }
    }

    private fun finishWithMessage(message: String) {
        if (finished) return
        finished = true
        destroyRecognizer()
        handler.removeCallbacksAndMessages(null)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hamouri_session")
        handler.postDelayed({ finishSessionOnly() }, 900L)
    }

    private fun finishSessionOnly() {
        if (!finished) finished = true
        destroyRecognizer()
        handler.removeCallbacksAndMessages(null)
        try { hide() } catch (_: Exception) { }
    }

    private fun updateUi(message: String) {
        try { statusView?.text = message } catch (_: Exception) { }
    }

    private fun findExternalRecognitionService(): android.content.ComponentName? {
        val intent = Intent("android.speech.RecognitionService")
        val services = context.packageManager.queryIntentServices(
            intent,
            PackageManager.MATCH_ALL
        )
        return services
            .map { it.serviceInfo }
            .firstOrNull { it.packageName != context.packageName }
            ?.let { android.content.ComponentName(it.packageName, it.name) }
    }

    private fun destroyRecognizer() {
        try { recognizer?.cancel() } catch (_: Exception) { }
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
    }

    override fun onHide() {
        super.onHide()
        finished = true
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
    }

    override fun onDestroy() {
        finished = true
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "تعذر الوصول إلى الميكروفون."
        SpeechRecognizer.ERROR_CLIENT -> "تعذر بدء الاستماع من المساعد. حاول مرة أخرى."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "يحتاج محمد الحموري إلى إذن الميكروفون."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تعذر الاتصال بخدمة التعرف الصوتي."
        SpeechRecognizer.ERROR_NO_MATCH -> "لم أسمع الأمر. تفضل مرة أخرى."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "الميكروفون مشغول. حاول مرة أخرى بعد لحظة."
        SpeechRecognizer.ERROR_SERVER -> "خدمة التعرف الصوتي لم تستجب."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم أسمع كلامًا. تفضل مرة أخرى."
        else -> "تعذر فهم الأمر الصوتي. حاول مرة أخرى."
    }
}

package com.mohammad.hamouri.assistant

import android.os.Bundle
import android.service.voice.VoiceInteractionService

class HamouriVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }

    override fun onShowSessionFailed(args: Bundle) {
        super.onShowSessionFailed(args)
    }
}
